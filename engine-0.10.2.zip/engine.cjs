"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key2) && key2 !== except)
        __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// src/config.ts
var import_node_path, import_node_crypto, config;
var init_config = __esm({
  "src/config.ts"() {
    "use strict";
    import_node_path = __toESM(require("node:path"), 1);
    import_node_crypto = require("node:crypto");
    config = {
      version: "0.10.2",
      apkVersion: process.env.MAUSDROID_APK_VERSION ?? "dev",
      dataDir: process.env.MAUSDROID_DATA_DIR ?? import_node_path.default.resolve(".mausdroid-data"),
      uiDir: process.env.MAUSDROID_UI_DIR ?? import_node_path.default.resolve("../ui/dist"),
      port: Number(process.env.MAUSDROID_PORT ?? 8737),
      /** Secret the on-phone UI uses; the shell passes it in the WebView URL. */
      localToken: process.env.MAUSDROID_TOKEN ?? (0, import_node_crypto.randomBytes)(24).toString("hex"),
      bridgeUrl: process.env.MAUSDROID_BRIDGE_URL ?? "",
      bridgeToken: process.env.MAUSDROID_BRIDGE_TOKEN ?? "",
      /** Local HTTP proxy (from tsbridge) that reaches devices on your tailnet. */
      tailnetProxy: process.env.MAUSDROID_TAILNET_PROXY ?? "127.0.0.1:8739",
      platform: process.env.MAUSDROID_PLATFORM ?? "desktop-dev"
    };
  }
});

// src/bridge.ts
var bridge_exports = {};
__export(bridge_exports, {
  bridge: () => bridge,
  bridgeAvailable: () => bridgeAvailable
});
async function bridge(path13, body, timeoutMs = 6e4) {
  if (!config.bridgeUrl) throw new Error("This feature needs the Android app (no native bridge in this run).");
  const res = await fetch(`${config.bridgeUrl}${path13}`, {
    method: body === void 0 ? "GET" : "POST",
    headers: { "content-type": "application/json", "x-bridge-token": config.bridgeToken },
    body: body === void 0 ? void 0 : JSON.stringify(body),
    signal: AbortSignal.timeout(timeoutMs)
  });
  const text = await res.text();
  let data;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }
  if (!res.ok) throw new Error(data?.error ?? `Native bridge ${path13}: HTTP ${res.status}`);
  return data;
}
var bridgeAvailable;
var init_bridge = __esm({
  "src/bridge.ts"() {
    "use strict";
    init_config();
    bridgeAvailable = () => Boolean(config.bridgeUrl);
  }
});

// src/store.ts
var store_exports = {};
__export(store_exports, {
  JsonFile: () => JsonFile,
  collection: () => collection,
  dataPath: () => dataPath,
  flushAll: () => flushAll
});
function collection(name, initial) {
  let f = files.get(name);
  if (!f) {
    f = new JsonFile(import_node_path2.default.join(config.dataDir, `${name}.json`), initial);
    files.set(name, f);
  }
  return f;
}
function flushAll() {
  for (const f of files.values()) {
    try {
      f.flush();
    } catch {
    }
  }
}
function dataPath(...parts) {
  const p = import_node_path2.default.join(config.dataDir, ...parts);
  import_node_fs.default.mkdirSync(import_node_path2.default.dirname(p), { recursive: true });
  return p;
}
var import_node_fs, import_node_path2, JsonFile, files;
var init_store = __esm({
  "src/store.ts"() {
    "use strict";
    import_node_fs = __toESM(require("node:fs"), 1);
    import_node_path2 = __toESM(require("node:path"), 1);
    init_config();
    JsonFile = class {
      constructor(file4, initial) {
        this.file = file4;
        import_node_fs.default.mkdirSync(import_node_path2.default.dirname(file4), { recursive: true });
        try {
          this.value = JSON.parse(import_node_fs.default.readFileSync(file4, "utf8"));
        } catch {
          this.value = initial;
        }
      }
      value;
      timer = null;
      get() {
        return this.value;
      }
      set(next2) {
        this.value = next2;
        this.schedule();
      }
      update(fn) {
        fn(this.value);
        this.schedule();
        return this.value;
      }
      flush() {
        if (this.timer) clearTimeout(this.timer);
        this.timer = null;
        const tmp = `${this.file}.tmp`;
        import_node_fs.default.writeFileSync(tmp, JSON.stringify(this.value));
        import_node_fs.default.renameSync(tmp, this.file);
      }
      schedule() {
        if (this.timer) return;
        this.timer = setTimeout(() => this.flush(), 150);
      }
    };
    files = /* @__PURE__ */ new Map();
  }
});

// src/secrets.ts
var secrets_exports = {};
__export(secrets_exports, {
  getSecret: () => getSecret,
  hasSecret: () => hasSecret,
  initSecrets: () => initSecrets,
  setSecret: () => setSecret
});
async function load() {
  if (loaded) return;
  for (const [name, stored] of Object.entries(file.get())) {
    try {
      if (stored.startsWith("ks:")) {
        const { plain } = await bridge("/secret/decrypt", { cipher: stored.slice(3) });
        cache.set(name, plain);
      } else if (stored.startsWith("dev:")) {
        cache.set(name, Buffer.from(stored.slice(4), "base64").toString("utf8"));
      }
    } catch {
    }
  }
  loaded = true;
}
async function initSecrets() {
  await load();
}
function getSecret(name) {
  return cache.get(name);
}
function hasSecret(name) {
  return Boolean(cache.get(name));
}
async function setSecret(name, value) {
  await load();
  if (!value) {
    cache.delete(name);
    file.update((f) => {
      delete f[name];
    });
    return;
  }
  let stored;
  if (bridgeAvailable()) {
    const { cipher } = await bridge("/secret/encrypt", { plain: value });
    stored = `ks:${cipher}`;
  } else {
    stored = `dev:${Buffer.from(value, "utf8").toString("base64")}`;
  }
  cache.set(name, value);
  file.update((f) => {
    f[name] = stored;
  });
}
var file, cache, loaded;
var init_secrets = __esm({
  "src/secrets.ts"() {
    "use strict";
    init_bridge();
    init_store();
    file = collection("secrets", {});
    cache = /* @__PURE__ */ new Map();
    loaded = false;
  }
});

// src/util.ts
function errorText(e) {
  return e instanceof Error ? e.message : String(e);
}
function clip(text, max = 24e3) {
  if (text.length <= max) return text;
  return `${text.slice(0, max)}

[\u2026 ${text.length - max} more characters cut]`;
}
function htmlToText(html) {
  return html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<noscript[\s\S]*?<\/noscript>/gi, " ").replace(/<(br|\/p|\/div|\/h[1-6]|\/li|\/tr)[^>]*>/gi, "\n").replace(/<a [^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi, "$2 ($1)").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/[ \t]+/g, " ").replace(/\n\s*\n\s*/g, "\n\n").trim();
}
var import_node_crypto2, id, now, sleep, terminalText;
var init_util = __esm({
  "src/util.ts"() {
    "use strict";
    import_node_crypto2 = require("node:crypto");
    id = (prefix) => `${prefix}_${(0, import_node_crypto2.randomUUID)().replace(/-/g, "").slice(0, 16)}`;
    now = () => (/* @__PURE__ */ new Date()).toISOString();
    sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    terminalText = (s) => s.replace(/\x1b\][^\x07\x1b]*(\x07|\x1b\\)/g, "").replace(/\x1b\[[0-9;]*[GCHfd]/g, " ").replace(/\x1b\[[0-9;?]*[ -/]*[@-~]/g, "").replace(/\r/g, "");
  }
});

// src/bots.ts
var bots_exports = {};
__export(bots_exports, {
  DEFAULT_BOTS: () => DEFAULT_BOTS,
  addMessage: () => addMessage,
  clearChat: () => clearChat,
  createBot: () => createBot,
  deleteBot: () => deleteBot,
  ensureDefaultBots: () => ensureDefaultBots,
  getBot: () => getBot,
  history: () => history,
  lastMessage: () => lastMessage,
  listBots: () => listBots,
  messages: () => messages,
  patchMessage: () => patchMessage,
  setHistory: () => setHistory,
  updateBot: () => updateBot
});
function listBots() {
  return botsFile.get();
}
function getBot(botId) {
  return botsFile.get().find((b) => b.id === botId);
}
function createBot(input) {
  const bot = {
    id: id("bot"),
    name: input.name?.trim() || "New bot",
    emoji: input.emoji || "\u{1F916}",
    color: input.color || "#6c757d",
    persona: input.persona ?? "",
    providerId: input.providerId ?? null,
    model: input.model ?? null,
    approvalMode: input.approvalMode ?? "ask-risky",
    tools: { web: true, browser: true, apps: true, phone: false, ...input.tools ?? {} },
    skills: input.skills ?? [],
    pinned: input.pinned ?? false,
    hidden: false,
    createdAt: now(),
    unread: 0,
    alwaysAllow: []
  };
  botsFile.update((b) => void b.push(bot));
  return bot;
}
function updateBot(botId, patch3) {
  let found;
  botsFile.update((all) => {
    found = all.find((b) => b.id === botId);
    if (found) Object.assign(found, patch3, { id: found.id, createdAt: found.createdAt });
  });
  if (!found) throw new Error("No such bot");
  return found;
}
function deleteBot(botId) {
  botsFile.update((all) => {
    const i = all.findIndex((b) => b.id === botId);
    if (i >= 0) all.splice(i, 1);
  });
  for (const f of [`messages-${botId}`, `history-${botId}`]) import_node_fs2.default.rmSync(dataPath("chats", `${f}.json`), { force: true });
}
function ensureDefaultBots() {
  if (botsFile.get().length) return;
  DEFAULT_BOTS.forEach((b, i) => createBot({ ...b, pinned: i === 0 }));
}
function messages(botId, before, limit = 60) {
  const all = msgs(botId).get();
  let end = all.length;
  if (before) {
    const i = all.findIndex((m) => m.id === before);
    if (i >= 0) end = i;
  }
  return all.slice(Math.max(0, end - limit), end);
}
function addMessage(botId, m) {
  const full = { id: m.id ?? id("msg"), at: now(), ...m };
  msgs(botId).update((a) => void a.push(full));
  return full;
}
function patchMessage(botId, msgId, patch3) {
  let found;
  msgs(botId).update((a) => {
    found = a.find((x) => x.id === msgId);
    if (found) Object.assign(found, patch3);
  });
  return found;
}
function history(botId) {
  return hist(botId).get();
}
function setHistory(botId, h) {
  hist(botId).set(h);
}
function clearChat(botId) {
  msgs(botId).set([]);
  hist(botId).set([]);
  updateBot(botId, { cliSession: void 0 });
}
function lastMessage(botId) {
  const a = msgs(botId).get();
  for (let i = a.length - 1; i >= 0; i--) if (a[i].role === "user" || a[i].role === "assistant") return a[i];
  return void 0;
}
var import_node_fs2, botsFile, DEFAULT_BOTS, msgs, hist;
var init_bots = __esm({
  "src/bots.ts"() {
    "use strict";
    import_node_fs2 = __toESM(require("node:fs"), 1);
    init_store();
    init_util();
    botsFile = collection("bots", []);
    DEFAULT_BOTS = [
      { name: "Maus", emoji: "\u{1F42D}", color: "#1084fe", persona: "You are Maus, the user's main personal assistant. You are warm, brief and practical. You plan, delegate to tools, and check in before anything risky." },
      { name: "Researcher", emoji: "\u{1F50E}", color: "#2a9d8f", persona: "You research topics thoroughly using web search and the browser, cite your sources with links, and summarise clearly for a non-technical reader." },
      { name: "Inbox", emoji: "\u{1F4EC}", color: "#e76f51", persona: "You look after the user's email, calendar and messages through connected apps. You summarise what matters, draft replies for approval, and never send without approval." }
    ];
    msgs = (botId) => collection(`chats/messages-${botId}`, []);
    hist = (botId) => collection(`chats/history-${botId}`, []);
  }
});

// src/events.ts
function emit(type, data = {}) {
  const e = { ...data, seq: ++seq, type, at: (/* @__PURE__ */ new Date()).toISOString() };
  backlog.push(e);
  if (backlog.length > 2e3) backlog.splice(0, backlog.length - 2e3);
  for (const l of listeners) {
    try {
      l(e);
    } catch {
    }
  }
  return e;
}
function subscribe(l) {
  listeners.add(l);
  return () => listeners.delete(l);
}
function eventsSince(since2) {
  return backlog.filter((e) => e.seq > since2);
}
function waitForEvents(since2, ms) {
  const ready = eventsSince(since2);
  if (ready.length) return Promise.resolve(ready);
  return new Promise((resolve) => {
    const t = setTimeout(() => {
      off();
      resolve([]);
    }, ms);
    const off = subscribe(() => {
      clearTimeout(t);
      off();
      resolve(eventsSince(since2));
    });
  });
}
var listeners, backlog, seq, currentSeq;
var init_events = __esm({
  "src/events.ts"() {
    "use strict";
    listeners = /* @__PURE__ */ new Set();
    backlog = [];
    seq = 0;
    currentSeq = () => seq;
  }
});

// src/time.ts
function localParts(d) {
  return { hm: `${pad(d.getHours())}:${pad(d.getMinutes())}`, wd: d.getDay(), ymd: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` };
}
function fmtLong(d) {
  const h = d.getHours();
  const off = -d.getTimezoneOffset();
  const sign = off >= 0 ? "+" : "-";
  const tz = `UTC${sign}${pad(Math.floor(Math.abs(off) / 60))}:${pad(Math.abs(off) % 60)}`;
  return `${DAYS[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}, ${h % 12 || 12}:${pad(d.getMinutes())} ${h < 12 ? "am" : "pm"} (${tz})`;
}
function deviceTimeZone() {
  try {
    const I = globalThis.Intl;
    const z = I?.DateTimeFormat?.().resolvedOptions?.().timeZone;
    if (z) return z;
  } catch {
  }
  if (process.env.TZ) return process.env.TZ;
  const off = -(/* @__PURE__ */ new Date()).getTimezoneOffset();
  return `UTC${off >= 0 ? "+" : "-"}${pad(Math.floor(Math.abs(off) / 60))}:${pad(Math.abs(off) % 60)}`;
}
var DAYS, MONTHS, pad;
var init_time = __esm({
  "src/time.ts"() {
    "use strict";
    DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    pad = (n) => String(n).padStart(2, "0");
  }
});

// src/settings.ts
var settings_exports = {};
__export(settings_exports, {
  PROVIDER_PRESETS: () => PROVIDER_PRESETS,
  provider: () => provider,
  publicSettings: () => publicSettings,
  renamedProvider: () => renamedProvider,
  settings: () => settings,
  updateSettings: () => updateSettings
});
function provider(id2) {
  return settings().providers.find((p) => p.id === id2);
}
function publicSettings() {
  const s = settings();
  return {
    ...s,
    providers: s.providers.map((p) => ({ ...p, hasKey: hasSecret(`provider:${p.id}`) })),
    composio: { connected: hasSecret("composio"), userId: s.composio.userId },
    website: { ...s.website, passwordSet: hasSecret("website:password") },
    tailscale: { ...s.tailscale, hasAuthKey: hasSecret("tailscale:authkey") },
    github: { hasToken: hasSecret("github") }
  };
}
var PROVIDER_PRESETS, RENAMED, settingsFile, renamedProvider, settings, updateSettings;
var init_settings = __esm({
  "src/settings.ts"() {
    "use strict";
    init_store();
    init_secrets();
    init_time();
    PROVIDER_PRESETS = [
      // Your subscriptions: sign in with your account (no API keys). Each runs the company's official program.
      { id: "claude", label: "Claude", kind: "subscription", subId: "claude", defaultModel: "default", models: ["default", "opus", "sonnet", "haiku", "fable"], runOn: "phone", enabled: false, needsKey: false, note: "Sign in with your Claude account (Pro or Max). Uses Anthropic's official Claude Code." },
      { id: "chatgpt", label: "ChatGPT", kind: "subscription", subId: "chatgpt", defaultModel: "default", models: ["default"], runOn: "phone", enabled: false, needsKey: false, note: "Sign in with your ChatGPT account (Plus, Pro, Business or Edu). Uses OpenAI's official Codex." },
      // Other models: API keys, free services, and local models.
      { id: "openrouter", label: "OpenRouter (many models, some free)", kind: "openai", baseUrl: "https://openrouter.ai/api/v1", defaultModel: "openrouter/auto", models: ["openrouter/auto"], enabled: false, needsKey: true, free: true, note: "Models ending in :free cost nothing." },
      { id: "groq", label: "Groq (free tier)", kind: "openai", baseUrl: "https://api.groq.com/openai/v1", defaultModel: "llama-3.3-70b-versatile", models: ["llama-3.3-70b-versatile"], enabled: false, needsKey: true, free: true },
      { id: "local", label: "Local / custom model (phone, PC or any device)", kind: "openai", baseUrl: "http://127.0.0.1:11434/v1", defaultModel: "llama3.2", models: [], enabled: false, needsKey: false, free: true, note: "Any OpenAI-compatible server: on this phone, your PC over Tailscale, or another device." }
    ];
    RENAMED = { anthropic: "claude", openai: "chatgpt", "claude-code": "claude", codex: "chatgpt" };
    settingsFile = collection("settings", {
      providers: PROVIDER_PRESETS,
      defaultProvider: null,
      composio: {},
      website: { enabled: false },
      tailscale: { enabled: false, hostname: "mausdroid" },
      onboardingDone: false,
      timeZone: deviceTimeZone(),
      quietHours: null,
      voice: { engine: "phone", readReplies: "voice", rate: 1 },
      assistant: { botId: null, speak: true }
    });
    settingsFile.update((s) => {
      s.voice ??= { engine: "phone", readReplies: "voice", rate: 1 };
      s.assistant ??= { botId: null, speak: true };
    });
    settingsFile.update((s) => {
      s.providers = s.providers.filter((p) => !RENAMED[p.id] && p.id !== "gemini");
      for (const p of PROVIDER_PRESETS) {
        const have = s.providers.find((x) => x.id === p.id);
        if (!have) s.providers.push(p);
        else if (p.kind === "subscription") Object.assign(have, { label: p.label, note: p.note, kind: p.kind, subId: p.subId, needsKey: false, baseUrl: void 0, models: p.models });
      }
      const order = (id2) => {
        const i = PROVIDER_PRESETS.findIndex((p) => p.id === id2);
        return i < 0 ? 1e3 : i;
      };
      s.providers.sort((a, b) => order(a.id) - order(b.id));
      if (s.defaultProvider && RENAMED[s.defaultProvider]) s.defaultProvider = RENAMED[s.defaultProvider];
      if (s.defaultProvider === "gemini") s.defaultProvider = null;
      if (s.defaultProvider && !s.providers.find((p) => p.id === s.defaultProvider)) s.defaultProvider = null;
    });
    renamedProvider = (id2) => id2 && RENAMED[id2] || id2;
    settings = () => settingsFile.get();
    updateSettings = (fn) => settingsFile.update(fn);
  }
});

// src/sse.ts
async function* readSSE(res) {
  if (!res.body) return;
  const reader = res.body.getReader();
  const decoder = new import_node_string_decoder.StringDecoder("utf8");
  let buf = "";
  let event = "message";
  let data = [];
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.write(Buffer.from(value));
    let nl;
    while ((nl = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, nl).replace(/\r$/, "");
      buf = buf.slice(nl + 1);
      if (line === "") {
        if (data.length) yield { event, data: data.join("\n") };
        event = "message";
        data = [];
      } else if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) data.push(line.slice(5).replace(/^ /, ""));
    }
  }
  if (data.length) yield { event, data: data.join("\n") };
}
var import_node_string_decoder;
var init_sse = __esm({
  "src/sse.ts"() {
    "use strict";
    import_node_string_decoder = require("node:string_decoder");
  }
});

// src/providers/anthropic.ts
function toAnthropic(messages2) {
  return messages2.map((m) => ({
    role: m.role,
    content: m.content.map((b) => {
      switch (b.type) {
        case "text":
          return { type: "text", text: b.text };
        case "image":
          return { type: "image", source: { type: "base64", media_type: b.mediaType, data: b.data } };
        case "tool_use":
          return { type: "tool_use", id: b.id, name: b.name, input: b.input };
        case "tool_result":
          return {
            type: "tool_result",
            tool_use_id: b.toolUseId,
            is_error: b.isError || void 0,
            content: [
              { type: "text", text: b.content || "(no output)" },
              ...(b.images ?? []).map((i) => ({ type: "image", source: { type: "base64", media_type: i.mediaType, data: i.data } }))
            ]
          };
      }
    })
  }));
}
async function anthropicTurn(req, apiKey) {
  const res = await fetch(`${API}/messages`, {
    method: "POST",
    signal: req.signal,
    headers: { "content-type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({
      model: req.model,
      max_tokens: 16e3,
      stream: true,
      system: req.system,
      messages: toAnthropic(req.messages),
      tools: req.tools.map((t) => ({ name: t.name, description: t.description, input_schema: t.inputSchema }))
    })
  });
  if (!res.ok) throw new Error(`Claude API: HTTP ${res.status} ${(await res.text()).slice(0, 400)}`);
  const blocks = [];
  let stop = "end";
  const usage = {};
  for await (const { data } of readSSE(res)) {
    const ev = JSON.parse(data);
    switch (ev.type) {
      case "message_start":
        usage.input = ev.message?.usage?.input_tokens;
        break;
      case "content_block_start":
        if (ev.content_block.type === "text") blocks[ev.index] = { type: "text", text: "" };
        else if (ev.content_block.type === "tool_use")
          blocks[ev.index] = { type: "tool_use", id: ev.content_block.id, name: ev.content_block.name, input: {}, _json: "" };
        break;
      case "content_block_delta": {
        const b = blocks[ev.index];
        if (ev.delta.type === "text_delta" && b?.type === "text") {
          b.text += ev.delta.text;
          req.onText(ev.delta.text);
        } else if (ev.delta.type === "input_json_delta" && b?.type === "tool_use") b._json += ev.delta.partial_json;
        break;
      }
      case "content_block_stop": {
        const b = blocks[ev.index];
        if (b?.type === "tool_use") {
          b.input = b._json ? JSON.parse(b._json) : {};
          delete b._json;
        }
        break;
      }
      case "message_delta":
        if (ev.delta?.stop_reason === "tool_use") stop = "tool_use";
        else if (ev.delta?.stop_reason === "max_tokens") stop = "max_tokens";
        usage.output = ev.usage?.output_tokens;
        break;
      case "error":
        throw new Error(`Claude API: ${ev.error?.message ?? "stream error"}`);
    }
  }
  return { blocks: blocks.filter(Boolean), stopReason: stop, usage };
}
async function anthropicModels(apiKey) {
  const res = await fetch(`${API}/models?limit=100`, { headers: { "x-api-key": apiKey, "anthropic-version": "2023-06-01" } });
  if (!res.ok) throw new Error(`Claude API: HTTP ${res.status}`);
  const j = await res.json();
  return j.data.map((m) => m.id);
}
var API;
var init_anthropic = __esm({
  "src/providers/anthropic.ts"() {
    "use strict";
    init_sse();
    API = "https://api.anthropic.com/v1";
  }
});

// src/providers/openai.ts
function toOpenAI(system, messages2) {
  const out = [{ role: "system", content: system }];
  for (const m of messages2) {
    if (m.role === "assistant") {
      const text = m.content.filter((b) => b.type === "text").map((b) => b.text).join("");
      const calls = m.content.filter((b) => b.type === "tool_use");
      out.push({
        role: "assistant",
        content: text || null,
        tool_calls: calls.length ? calls.map((c) => ({ id: c.id, type: "function", function: { name: c.name, arguments: JSON.stringify(c.input) } })) : void 0
      });
      continue;
    }
    const parts = [];
    for (const b of m.content) {
      if (b.type === "tool_result") {
        out.push({ role: "tool", tool_call_id: b.toolUseId, content: (b.isError ? "ERROR: " : "") + (b.content || "(no output)") });
        for (const img of b.images ?? []) parts.push({ type: "image_url", image_url: { url: `data:${img.mediaType};base64,${img.data}` } });
      } else if (b.type === "text") parts.push({ type: "text", text: b.text });
      else if (b.type === "image") parts.push({ type: "image_url", image_url: { url: `data:${b.mediaType};base64,${b.data}` } });
    }
    if (parts.length) out.push({ role: "user", content: parts.length === 1 && parts[0].type === "text" ? parts[0].text : parts });
  }
  return out;
}
async function openaiTurn(req, baseUrl, apiKey) {
  const headers2 = { "content-type": "application/json" };
  if (apiKey) headers2.authorization = `Bearer ${apiKey}`;
  if (baseUrl.includes("openrouter.ai")) {
    headers2["HTTP-Referer"] = "https://github.com/DanGeo13/MausDroid";
    headers2["X-Title"] = "MausDroid";
  }
  const res = await fetch(`${baseUrl.replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    signal: req.signal,
    headers: headers2,
    body: JSON.stringify({
      model: req.model,
      stream: true,
      messages: toOpenAI(req.system, req.messages),
      tools: req.tools.length ? req.tools.map((t) => ({ type: "function", function: { name: t.name, description: t.description, parameters: t.inputSchema } })) : void 0
    })
  });
  if (!res.ok) throw new Error(`Model endpoint: HTTP ${res.status} ${(await res.text()).slice(0, 400)}`);
  let text = "";
  const calls = [];
  let finish3 = "";
  const usage = {};
  for await (const { data } of readSSE(res)) {
    if (data === "[DONE]") break;
    const ev = JSON.parse(data);
    if (ev.error) throw new Error(`Model endpoint: ${ev.error.message ?? JSON.stringify(ev.error)}`);
    if (ev.usage) {
      usage.input = ev.usage.prompt_tokens;
      usage.output = ev.usage.completion_tokens;
    }
    const choice = ev.choices?.[0];
    if (!choice) continue;
    const d = choice.delta ?? {};
    if (d.content) {
      text += d.content;
      req.onText(d.content);
    }
    for (const tc of d.tool_calls ?? []) {
      const i = tc.index ?? calls.length;
      calls[i] ??= { id: tc.id ?? `call_${i}`, name: "", args: "" };
      if (tc.id) calls[i].id = tc.id;
      if (tc.function?.name) calls[i].name += tc.function.name;
      if (tc.function?.arguments) calls[i].args += tc.function.arguments;
    }
    if (choice.finish_reason) finish3 = choice.finish_reason;
  }
  const blocks = [];
  if (text) blocks.push({ type: "text", text });
  for (const c of calls.filter(Boolean)) {
    let input = {};
    try {
      input = c.args ? JSON.parse(c.args) : {};
    } catch {
      input = { _unparsed: c.args };
    }
    blocks.push({ type: "tool_use", id: c.id, name: c.name, input });
  }
  const stopReason = calls.length ? "tool_use" : finish3 === "length" ? "max_tokens" : "end";
  return { blocks, stopReason, usage };
}
async function openaiModels(baseUrl, apiKey) {
  const res = await fetch(`${baseUrl.replace(/\/$/, "")}/models`, { headers: apiKey ? { authorization: `Bearer ${apiKey}` } : {} });
  if (!res.ok) throw new Error(`Model list: HTTP ${res.status}`);
  const j = await res.json();
  return (j.data?.map((m) => m.id) ?? j.models?.map((m) => m.name) ?? []).map((m) => m.replace(/^models\//, "")).sort();
}
var init_openai = __esm({
  "src/providers/openai.ts"() {
    "use strict";
    init_sse();
  }
});

// src/files.ts
function kindOf(name, mime) {
  if (mime.startsWith("image/") && !mime.includes("svg")) return "image";
  if (mime.startsWith("audio/")) return "audio";
  if (mime.startsWith("video/")) return "video";
  if (mime.startsWith("text/") || /json|xml|javascript|yaml|csv|svg/.test(mime) || TEXT_EXT.test(name)) return "text";
  if (/pdf|word|officedocument|opendocument|msword|powerpoint|excel|epub/.test(mime) || /\.(pdf|docx?|pptx?|xlsx?|odt|ods|odp|epub|pages|key|numbers)$/i.test(name)) return "document";
  return "other";
}
function guessMime(name) {
  const ext = import_node_path3.default.extname(name).toLowerCase().slice(1);
  const m = {
    png: "image/png",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    gif: "image/gif",
    webp: "image/webp",
    heic: "image/heic",
    mp3: "audio/mpeg",
    m4a: "audio/mp4",
    wav: "audio/wav",
    ogg: "audio/ogg",
    opus: "audio/opus",
    aac: "audio/aac",
    mp4: "video/mp4",
    mov: "video/quicktime",
    webm: "video/webm",
    mkv: "video/x-matroska",
    "3gp": "video/3gpp",
    pdf: "application/pdf",
    json: "application/json",
    html: "text/html",
    htm: "text/html",
    md: "text/markdown",
    txt: "text/plain",
    csv: "text/csv",
    xml: "application/xml",
    svg: "image/svg+xml",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation"
  };
  return m[ext] ?? "application/octet-stream";
}
function safeName(name) {
  return (import_node_path3.default.basename(name || "file").replace(/[^\w.\- ()]+/g, "_").slice(-120) || "file").trim();
}
function filePath(a) {
  return import_node_path3.default.join(root(), a.id, safeName(a.name));
}
function saveFile(name, mime, data, note) {
  const n = safeName(name);
  const m = mime && mime !== "application/octet-stream" ? mime : guessMime(n);
  const a = { id: id("file"), name: n, mime: m, size: data.length, kind: kindOf(n, m), ...note ? { note } : {} };
  import_node_fs3.default.mkdirSync(import_node_path3.default.join(root(), a.id), { recursive: true });
  import_node_fs3.default.writeFileSync(filePath(a), data);
  import_node_fs3.default.writeFileSync(meta(a.id), JSON.stringify(a));
  return a;
}
function startUpload(name, mime) {
  const n = safeName(name);
  const m = mime && mime !== "application/octet-stream" ? mime : guessMime(n);
  const a = { id: id("file"), name: n, mime: m, size: 0, kind: kindOf(n, m) };
  import_node_fs3.default.mkdirSync(import_node_path3.default.join(root(), a.id), { recursive: true });
  return { attachment: a, stream: import_node_fs3.default.createWriteStream(filePath(a)), finish: (size) => import_node_fs3.default.writeFileSync(meta(a.id), JSON.stringify({ ...a, size })) };
}
function getFile(id2) {
  if (!/^file_[a-f0-9]{16}$/.test(id2)) return null;
  try {
    return JSON.parse(import_node_fs3.default.readFileSync(meta(id2), "utf8"));
  } catch {
    return null;
  }
}
function readText(a, max = 6e4) {
  const raw = import_node_fs3.default.readFileSync(filePath(a), "utf8");
  if (/html/.test(a.mime) || /\.html?$/i.test(a.name)) return clip(htmlToText(raw), max);
  if (/json/.test(a.mime)) {
    try {
      return clip(JSON.stringify(JSON.parse(raw), null, 1), max);
    } catch {
    }
  }
  return clip(raw, max);
}
function describe(a) {
  return `${a.name} (${a.kind}, ${a.mime}, ${human(a.size)})${a.note ? ` \u2014 ${a.note}` : ""}`;
}
function toBlocks(list, vision = true) {
  const blocks = [];
  for (const a of list) {
    try {
      if (a.kind === "image" && vision && a.size < 5e6 && /png|jpe?g|gif|webp/.test(a.mime)) {
        blocks.push({ type: "text", text: `[Image: ${describe(a)}]` });
        blocks.push({ type: "image", mediaType: a.mime, data: import_node_fs3.default.readFileSync(filePath(a)).toString("base64") });
      } else if (a.kind === "text" && a.size < 2e6) {
        blocks.push({ type: "text", text: `[File: ${describe(a)}]
${readText(a, 4e4)}
[End of ${a.name}]` });
      } else {
        blocks.push({ type: "text", text: `[Attached file: ${describe(a)}. File id ${a.id}. Use file_read to look inside it if it's readable.]` });
      }
    } catch {
      blocks.push({ type: "text", text: `[Attached file ${a.name} could not be read.]` });
    }
  }
  return blocks;
}
function exportTo(dir, list) {
  const out = [];
  import_node_fs3.default.mkdirSync(import_node_path3.default.join(dir, "attachments"), { recursive: true });
  for (const a of list) {
    const rel = import_node_path3.default.join("attachments", `${a.id.slice(5, 11)}-${safeName(a.name)}`);
    try {
      import_node_fs3.default.copyFileSync(filePath(a), import_node_path3.default.join(dir, rel));
      out.push(rel);
    } catch {
    }
  }
  return out;
}
var import_node_fs3, import_node_path3, root, meta, TEXT_EXT, human;
var init_files = __esm({
  "src/files.ts"() {
    "use strict";
    import_node_fs3 = __toESM(require("node:fs"), 1);
    import_node_path3 = __toESM(require("node:path"), 1);
    init_store();
    init_util();
    root = () => import_node_path3.default.dirname(dataPath("files", ".keep"));
    meta = (id2) => import_node_path3.default.join(root(), id2, "meta.json");
    TEXT_EXT = /\.(txt|md|markdown|json|jsonl|html?|xml|csv|tsv|ya?ml|toml|ini|log|js|mjs|cjs|ts|tsx|jsx|py|java|kt|c|h|cpp|cs|go|rs|rb|php|sh|sql|css|scss|svg|tex|rtf|srt|vtt|ics|vcf)$/i;
    human = (n) => n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1e3))} KB`;
  }
});

// src/archive.ts
async function download(url, file4, onProgress) {
  const res = await fetch(url, { headers: { "user-agent": "MausDroid" } });
  if (!res.ok || !res.body) throw new Error(`Download failed (HTTP ${res.status}) for ${url}`);
  const total = Number(res.headers.get("content-length") ?? 0);
  import_node_fs4.default.mkdirSync(import_node_path4.default.dirname(file4), { recursive: true });
  const out = import_node_fs4.default.createWriteStream(`${file4}.part`);
  const reader = res.body.getReader();
  let done = 0;
  try {
    while (true) {
      const r = await reader.read();
      if (r.done) break;
      done += r.value.length;
      if (!out.write(Buffer.from(r.value))) await new Promise((ok) => out.once("drain", ok));
      onProgress?.(done, total);
    }
  } finally {
    await new Promise((ok) => out.end(ok));
  }
  import_node_fs4.default.renameSync(`${file4}.part`, file4);
}
async function extractTarGz(file4, pick) {
  const written = [];
  let buf = Buffer.alloc(0);
  let current = null;
  let longName = null;
  let collectingLongName = null;
  const consume = (chunk) => {
    buf = buf.length ? Buffer.concat([buf, chunk]) : chunk;
    while (true) {
      if (current) {
        if (current.remaining > 0) {
          if (!buf.length) return;
          const n = Math.min(current.remaining, buf.length);
          const part = buf.subarray(0, n);
          if (collectingLongName) collectingLongName.push(Buffer.from(part));
          else if (current.out !== null) import_node_fs4.default.writeSync(current.out, part);
          buf = buf.subarray(n);
          current.remaining -= n;
          if (current.remaining > 0) return;
        }
        if (buf.length < current.pad) return;
        buf = buf.subarray(current.pad);
        if (current.out !== null) import_node_fs4.default.closeSync(current.out);
        if (collectingLongName) {
          longName = Buffer.concat(collectingLongName).toString("utf8").replace(/\0.*$/s, "");
          collectingLongName = null;
        }
        current = null;
      }
      if (buf.length < 512) return;
      const h = buf.subarray(0, 512);
      buf = buf.subarray(512);
      if (h.every((b) => b === 0)) continue;
      const str2 = (a, b) => h.subarray(a, b).toString("utf8").replace(/\0.*$/s, "");
      const size = parseInt(str2(124, 136).trim() || "0", 8) || 0;
      const type = String.fromCharCode(h[156] || 48);
      const prefix = str2(345, 500);
      let name = longName ?? (prefix ? `${prefix}/${str2(0, 100)}` : str2(0, 100));
      longName = null;
      const pad3 = (512 - size % 512) % 512;
      if (type === "L") {
        collectingLongName = [];
        current = { remaining: size, pad: pad3, out: null };
        continue;
      }
      name = name.replace(/^\.\//, "");
      let out = null;
      if (type === "0" || type === "\0" || type === "7") {
        const dest = pick(name);
        if (dest) {
          import_node_fs4.default.mkdirSync(import_node_path4.default.dirname(dest), { recursive: true });
          out = import_node_fs4.default.openSync(dest, "w", 493);
          written.push(dest);
        }
      } else if (type === "2") {
        const dest = pick(name);
        if (dest) written.push(`${dest}\0${str2(157, 257)}`);
      }
      current = { remaining: size, pad: pad3, out };
    }
  };
  await (0, import_promises.pipeline)(
    import_node_fs4.default.createReadStream(file4),
    import_node_zlib2.default.createGunzip(),
    new import_node_stream.Writable({
      write(chunk, _enc, cb) {
        try {
          consume(chunk);
          cb();
        } catch (e) {
          cb(e);
        }
      }
    })
  );
  const files2 = written.filter((w) => !w.includes("\0"));
  for (const link of written.filter((w) => w.includes("\0"))) {
    const [dest, target] = link.split("\0");
    const src = import_node_path4.default.join(import_node_path4.default.dirname(dest), import_node_path4.default.basename(target));
    if (import_node_fs4.default.existsSync(src)) {
      import_node_fs4.default.copyFileSync(src, dest);
      import_node_fs4.default.chmodSync(dest, 493);
      files2.push(dest);
    }
  }
  return files2;
}
var import_node_fs4, import_node_path4, import_node_zlib2, import_promises, import_node_stream;
var init_archive = __esm({
  "src/archive.ts"() {
    "use strict";
    import_node_fs4 = __toESM(require("node:fs"), 1);
    import_node_path4 = __toESM(require("node:path"), 1);
    import_node_zlib2 = __toESM(require("node:zlib"), 1);
    import_promises = require("node:stream/promises");
    import_node_stream = require("node:stream");
  }
});

// src/subscriptions.ts
function set(id2, patch3) {
  const before = status.get(id2)?.stage;
  const s = { ...status.get(id2) ?? { id: id2, stage: "not-installed" }, ...patch3, id: id2 };
  status.set(id2, s);
  emit("subs.changed", { id: id2, status: s });
  if (s.stage === "signed-in" && before !== "signed-in") for (const l of signedInListeners) l(id2);
}
function isSignedIn(id2) {
  if (id2 === "claude") return Boolean(getSecret("sub:claude:token")) || claudeCreds().some((f) => import_node_fs5.default.existsSync(f));
  return import_node_fs5.default.existsSync(import_node_path5.default.join(subHome("chatgpt"), ".codex", "auth.json"));
}
function subStatus(id2) {
  const s = status.get(id2);
  if (s && (s.stage === "installing" || s.stage === "signing-in" || s.stage === "error")) return s;
  return { id: id2, stage: isSignedIn(id2) ? "signed-in" : installed(id2) ? "installed" : "not-installed", message: s?.message };
}
async function npmTarball(pkg, version) {
  const meta2 = await (await fetch(`https://registry.npmjs.org/${pkg.replace("/", "%2F")}`)).json();
  const v = version ?? meta2["dist-tags"]?.latest;
  const d = meta2.versions?.[v]?.dist;
  if (!d) throw new Error(`Couldn't find ${pkg}@${v} on npm`);
  return { version: v, url: d.tarball, integrity: d.integrity };
}
function checkIntegrity(file4, integrity) {
  const [algo, want] = integrity.split("-");
  const got = import_node_crypto3.default.createHash(algo).update(import_node_fs5.default.readFileSync(file4)).digest("base64");
  if (got !== want) throw new Error("Download check failed (file damaged). Try again.");
}
async function ensureMusl(id2) {
  if (hasMusl()) return;
  set(id2, { message: "Getting system libraries (Alpine Linux)\u2026" });
  const base = "https://dl-cdn.alpinelinux.org/alpine/latest-stable/main/aarch64";
  const idxFile = import_node_path5.default.join(root2(), "dl", "APKINDEX.tar.gz");
  await download(`${base}/APKINDEX.tar.gz`, idxFile);
  const idxOut = import_node_path5.default.join(root2(), "dl", "APKINDEX");
  await extractTarGz(idxFile, (n) => n === "APKINDEX" ? idxOut : null);
  const index = import_node_fs5.default.readFileSync(idxOut, "utf8");
  const versionOf = (pkg) => index.match(new RegExp(`\\nP:${pkg.replace(/[+]/g, "\\+")}\\nV:([^\\n]+)`))?.[1];
  for (const pkg of ["musl", "libstdc++", "libgcc"]) {
    const v = versionOf(pkg);
    if (!v) {
      if (pkg === "musl") throw new Error(`Alpine package ${pkg} not found`);
      continue;
    }
    const f = import_node_path5.default.join(root2(), "dl", `${pkg}-${v}.apk`);
    await download(`${base}/${pkg}-${v}.apk`, f);
    await extractTarGz(f, (n) => /^(usr\/)?lib\/[^/]+\.so[.\d]*$/.test(n) ? import_node_path5.default.join(lib(), import_node_path5.default.basename(n)) : null);
    import_node_fs5.default.rmSync(f, { force: true });
  }
  if (!import_node_fs5.default.existsSync(import_node_path5.default.join(lib(), "libc.musl-aarch64.so.1"))) import_node_fs5.default.copyFileSync(import_node_path5.default.join(lib(), "ld-musl-aarch64.so.1"), import_node_path5.default.join(lib(), "libc.musl-aarch64.so.1"));
  if (!hasMusl()) throw new Error("The system library download didn't contain the loader.");
}
function patchInterpreter(file4) {
  const b = import_node_fs5.default.readFileSync(file4);
  const old = Buffer.from("/lib/ld-musl-aarch64.so.1\0");
  const i = b.indexOf(old);
  if (i < 0) return;
  const neu = Buffer.alloc(old.length);
  Buffer.from("./.mausld\0").copy(neu);
  neu.copy(b, i);
  import_node_fs5.default.writeFileSync(file4, b, { mode: 493 });
}
async function install(id2) {
  if (installed(id2)) return;
  if (process.arch !== "arm64" && config.platform === "android") throw new Error("Only 64-bit phones are supported.");
  set(id2, { stage: "installing", progress: 0, message: "Starting download\u2026" });
  import_node_fs5.default.mkdirSync(bin(), { recursive: true });
  const dl = import_node_path5.default.join(root2(), "dl");
  if (id2 === "chatgpt") {
    const top = await npmTarball("@openai/codex");
    const t = await npmTarball("@openai/codex", `${top.version}-linux-arm64`);
    const f = import_node_path5.default.join(dl, "codex.tgz");
    await download(t.url, f, progress(id2, `Codex ${top.version} (about 170 MB)`));
    checkIntegrity(f, t.integrity);
    set(id2, { message: "Unpacking\u2026" });
    await extractTarGz(f, (n) => /aarch64-unknown-linux-musl\/bin\/(codex|codex-code-mode-host)$/.test(n) ? bin(import_node_path5.default.basename(n)) : null);
    import_node_fs5.default.rmSync(f, { force: true });
  } else {
    await ensureMusl(id2);
    const t = await npmTarball("@anthropic-ai/claude-code-linux-arm64-musl");
    const f = import_node_path5.default.join(dl, "claude.tgz");
    await download(t.url, f, progress(id2, `Claude Code ${t.version} (about 170 MB)`));
    checkIntegrity(f, t.integrity);
    set(id2, { message: "Unpacking\u2026" });
    await extractTarGz(f, (n) => n === "package/claude" ? bin("claude") : null);
    import_node_fs5.default.rmSync(f, { force: true });
    patchInterpreter(bin("claude"));
  }
  set(id2, { stage: "installed", progress: void 0, message: `${SUBS[id2].program} is installed.` });
}
function caBundle() {
  if (certFile && import_node_fs5.default.existsSync(certFile)) return certFile;
  certFile = import_node_path5.default.join(root2(), "cacert.pem");
  import_node_fs5.default.writeFileSync(certFile, import_node_tls.default.rootCertificates.join("\n"));
  return certFile;
}
function programEnv(id2) {
  const proxy = `http://127.0.0.1:${config.port + 3}`;
  const env = {
    ...process.env,
    HOME: subHome(id2),
    TMPDIR: import_node_path5.default.dirname(dataPath("tmp", "x")),
    // These Linux programs can't read Android's network settings, so their
    // traffic goes through MausDroid's local proxy, which resolves names.
    HTTPS_PROXY: proxy,
    HTTP_PROXY: proxy,
    https_proxy: proxy,
    http_proxy: proxy,
    NO_PROXY: "127.0.0.1,localhost",
    no_proxy: "127.0.0.1,localhost",
    SSL_CERT_FILE: caBundle(),
    LD_LIBRARY_PATH: lib(),
    SHELL: "/system/bin/sh",
    // No browser for the programs to open: MausDroid opens sign-in pages itself.
    BROWSER: import_node_fs5.default.existsSync("/system/bin/true") ? "/system/bin/true" : "true",
    TERM: "xterm-256color",
    NO_COLOR: "1"
  };
  if (id2 === "claude") {
    const tok = getSecret("sub:claude:token");
    if (tok) env.CLAUDE_CODE_OAUTH_TOKEN = tok;
    env.DISABLE_AUTOUPDATER = "1";
  }
  return env;
}
function programCommand(id2, args) {
  if (id2 === "chatgpt") return [bin("codex"), args];
  return [bin("claude"), args];
}
function findClaudeKey(log2) {
  const lines2 = log2.split(/\r?\n/).map((l) => l.trim());
  for (let i = 0; i < lines2.length; i++) {
    const m = lines2[i].match(/sk-ant-oat[0-9A-Za-z_-]{20,}/);
    if (!m) continue;
    let tok = m[0];
    if (lines2[i].endsWith(tok)) for (let j = i + 1; j < lines2.length && /^[0-9A-Za-z_-]+$/.test(lines2[j]) && tok.length < 400; j++) tok += lines2[j];
    return tok;
  }
  return null;
}
async function signIn(id2, openUrl) {
  try {
    await install(id2);
  } catch (e) {
    set(id2, { stage: "error", message: `Couldn't install ${SUBS[id2].program} on this phone: ${errorText(e)}` });
    return;
  }
  sessions.get(id2)?.kill();
  workDir();
  const loginArgs = id2 === "chatgpt" ? ["login"] : ["auth", "login", "--claudeai"];
  const [cmd, args] = programCommand(id2, loginArgs);
  const native = process.env.MAUSDROID_NATIVE_DIR;
  const usePty = Boolean(process.env.MAUSDROID_LOGIN_PTY) && native;
  const child2 = usePty ? (0, import_node_child_process.spawn)(import_node_path5.default.join(native, "libtsbridge.so"), ["pty", cmd, ...args], { cwd: workDir(), env: programEnv(id2) }) : (0, import_node_child_process.spawn)(cmd, args, { cwd: workDir(), env: programEnv(id2) });
  sessions.set(id2, child2);
  if (usePty) viaPty.add(id2);
  else viaPty.delete(id2);
  set(id2, { stage: "signing-in", message: `Opening the ${SUBS[id2].label} sign-in page\u2026`, loginUrl: void 0, needsCode: false, log: "" });
  let log2 = "";
  let opened = false;
  const onData = (d) => {
    const clean = stripAnsi(d.toString("utf8")).split("\n").filter((l) => /[A-Za-z0-9]{2,}/.test(l)).join("\n");
    if (!clean.trim()) return;
    log2 = (log2 + "\n" + clean).replace(/\n{2,}/g, "\n").slice(-6e3);
    const compact = log2.replace(/\n(?=\S)/g, (m, off) => /[A-Za-z0-9%&=._~:/?#-]$/.test(log2.slice(0, off)) ? "" : m);
    const url = compact.match(/https:\/\/[^\s"'<>]+(oauth|authorize|auth\.openai\.com)[^\s"'<>]*/)?.[0];
    const needsCode = /paste|authorization code|enter.*code/i.test(log2) && id2 !== "chatgpt";
    if (id2 === "claude") {
      const tok = findClaudeKey(log2);
      if (tok) void setSecret("sub:claude:token", tok).then(() => set(id2, { stage: "signed-in", message: "Signed in to Claude \u2713", loginUrl: void 0, needsCode: false }));
    }
    set(id2, { log: log2.slice(-1500), ...url ? { loginUrl: url } : {}, needsCode });
    if (url && !opened) {
      opened = true;
      set(id2, { message: `Sign in on the ${SUBS[id2].label} page that opened.${needsCode ? " Then paste the code here." : ""}` });
      void openUrl(url).catch(() => {
      });
    }
  };
  child2.stdout?.on("data", onData);
  child2.stderr?.on("data", onData);
  child2.on("error", (e) => set(id2, { stage: "error", message: `${SUBS[id2].program} couldn't start on this phone (${e.message}). Use "My computer" instead.` }));
  child2.on("close", (code) => {
    if (sessions.get(id2) === child2) sessions.delete(id2);
    clearTimeout(watchdogs.get(id2));
    if (code === 0 && id2 === "claude" && !isSignedIn(id2)) import_node_fs5.default.writeFileSync(claudeCreds()[1], (/* @__PURE__ */ new Date()).toISOString());
    if (isSignedIn(id2)) set(id2, { stage: "signed-in", message: `Signed in to ${SUBS[id2].label} \u2713`, loginUrl: void 0, needsCode: false });
    else if (status.get(id2)?.stage === "signing-in") {
      const reason = log2.split("\n").map((l) => l.trim()).filter(Boolean).reverse().find((l) => /error|couldn't|failed|invalid|expired|denied|not accepted|wasn't/i.test(l));
      set(id2, { stage: "error", message: `${reason ? reason.replace(/^\[err\]/, "") : `Sign-in didn't finish (exit ${code}).`} Tap Sign in to try again.`, log: log2.slice(-2500), loginUrl: void 0, needsCode: false });
    }
  });
}
function sendCode(id2, code) {
  const c = sessions.get(id2);
  if (!c?.stdin) throw new Error("No sign-in is waiting for a code. Tap Sign in again.");
  c.stdin.write(`${code.trim()}${viaPty.has(id2) ? "\r" : "\n"}`);
  set(id2, { message: "Checking the code\u2026", needsCode: false });
  clearTimeout(watchdogs.get(id2));
  watchdogs.set(
    id2,
    setTimeout(() => {
      if (status.get(id2)?.stage !== "signing-in") return;
      cancelSignIn(id2);
      set(id2, { stage: "error", message: `${SUBS[id2].program} didn't finish signing in within 90 seconds (it may not be able to reach ${SUBS[id2].company} from this phone). Tap Sign in to try again, or use your computer (Options).`, log: status.get(id2)?.log });
    }, 9e4)
  );
}
function cancelSignIn(id2) {
  sessions.get(id2)?.kill();
  sessions.delete(id2);
  set(id2, { stage: installed(id2) ? "installed" : "not-installed", message: void 0, loginUrl: void 0, needsCode: false });
}
async function signOut(id2) {
  cancelSignIn(id2);
  if (id2 === "claude") {
    await setSecret("sub:claude:token", null);
    for (const f of claudeCreds()) import_node_fs5.default.rmSync(f, { force: true });
  }
  if (id2 === "chatgpt") import_node_fs5.default.rmSync(import_node_path5.default.join(subHome("chatgpt"), ".codex", "auth.json"), { force: true });
  set(id2, { stage: installed(id2) ? "installed" : "not-installed", message: "Signed out." });
}
async function uninstall(id2) {
  await signOut(id2);
  for (const f of id2 === "chatgpt" ? ["codex", "codex-code-mode-host"] : ["claude"]) import_node_fs5.default.rmSync(bin(f), { force: true });
  set(id2, { stage: "not-installed", message: "Removed from this phone." });
}
var import_node_child_process, import_node_crypto3, import_node_fs5, import_node_path5, import_node_tls, SUBS, status, root2, bin, lib, subHome, workDir, signedInListeners, onSignedIn, installed, hasMusl, claudeCreds, allSubs, progress, certFile, sessions, watchdogs, viaPty, stripAnsi;
var init_subscriptions = __esm({
  "src/subscriptions.ts"() {
    "use strict";
    import_node_child_process = require("node:child_process");
    import_node_crypto3 = __toESM(require("node:crypto"), 1);
    import_node_fs5 = __toESM(require("node:fs"), 1);
    import_node_path5 = __toESM(require("node:path"), 1);
    import_node_tls = __toESM(require("node:tls"), 1);
    init_config();
    init_store();
    init_events();
    init_secrets();
    init_archive();
    init_util();
    SUBS = {
      claude: { label: "Claude", program: "Claude Code", company: "Anthropic" },
      chatgpt: { label: "ChatGPT", program: "Codex", company: "OpenAI" }
    };
    status = /* @__PURE__ */ new Map();
    root2 = () => import_node_path5.default.dirname(dataPath("subs", ".keep"));
    bin = (...p) => import_node_path5.default.join(root2(), "bin", ...p);
    lib = () => import_node_path5.default.join(root2(), "lib");
    subHome = (id2) => {
      const h = import_node_path5.default.join(root2(), "home", id2);
      import_node_fs5.default.mkdirSync(h, { recursive: true });
      return h;
    };
    workDir = () => {
      const w = import_node_path5.default.join(root2(), "work");
      import_node_fs5.default.mkdirSync(w, { recursive: true });
      const link = import_node_path5.default.join(w, ".mausld");
      const target = import_node_path5.default.join(lib(), "ld-musl-aarch64.so.1");
      if (import_node_fs5.default.existsSync(target) && !import_node_fs5.default.existsSync(link)) import_node_fs5.default.symlinkSync(target, link);
      return w;
    };
    signedInListeners = [];
    onSignedIn = (fn) => signedInListeners.push(fn);
    installed = (id2) => id2 === "chatgpt" ? import_node_fs5.default.existsSync(bin("codex")) : import_node_fs5.default.existsSync(bin("claude")) && hasMusl();
    hasMusl = () => import_node_fs5.default.existsSync(import_node_path5.default.join(lib(), "ld-musl-aarch64.so.1"));
    claudeCreds = () => [import_node_path5.default.join(subHome("claude"), ".claude", ".credentials.json"), import_node_path5.default.join(subHome("claude"), ".mausdroid-signed-in")];
    allSubs = () => Object.keys(SUBS).map((id2) => ({ ...subStatus(id2), ...SUBS[id2] }));
    progress = (id2, what) => (done, total) => {
      const pct = total ? Math.round(done / total * 100) : void 0;
      const s = status.get(id2);
      if (pct !== void 0 && s?.progress === pct) return;
      set(id2, { progress: pct, message: `Downloading ${what}\u2026 ${pct !== void 0 ? `${pct}%` : `${Math.round(done / 1e6)} MB`}` });
    };
    certFile = null;
    sessions = /* @__PURE__ */ new Map();
    watchdogs = /* @__PURE__ */ new Map();
    viaPty = /* @__PURE__ */ new Set();
    stripAnsi = (s) => s.replace(/\x1b\[[0-9;?]*[ -/]*[@-~]/g, "").replace(/\x1b\][^\x07]*\x07/g, "").replace(/\r/g, "\n");
  }
});

// src/providers/cli.ts
function cliArgs(run) {
  if (run.engine === "claude") {
    const mcp2 = JSON.stringify({ mcpServers: { mausdroid: { type: "http", url: run.mcpUrl, headers: { authorization: `Bearer ${run.mcpToken}` } } } });
    const args = [
      "-p",
      run.prompt,
      "--output-format",
      "stream-json",
      "--verbose",
      "--mcp-config",
      mcp2,
      "--permission-prompt-tool",
      "mcp__mausdroid__approval_prompt",
      "--append-system-prompt",
      run.systemPrompt,
      "--include-partial-messages"
    ];
    if (run.model && run.model !== "default") args.push("--model", run.model);
    if (run.resume) args.push("--resume", run.resume);
    return args;
  }
  {
    const base = [
      "exec",
      "--json",
      "--skip-git-repo-check",
      "-c",
      `mcp_servers.mausdroid.url="${run.mcpUrl}"`,
      // Newer Codex takes the key from an environment variable (MAUSDROID_MCP_TOKEN, set when it starts), not the command line.
      "-c",
      `mcp_servers.mausdroid.bearer_token_env_var="MAUSDROID_MCP_TOKEN"`
    ];
    if (run.model && run.model !== "default") base.push("-m", run.model);
    for (const img of run.images ?? []) base.push("-i", img);
    return run.resume ? ["exec", "resume", run.resume, ...base.slice(1), run.prompt] : [...base, `${run.systemPrompt}

${run.prompt}`];
  }
  return [];
}
function parseCliLine(engine, line, acc) {
  let ev;
  try {
    ev = JSON.parse(line);
  } catch {
    return [];
  }
  const out = [];
  if (engine === "claude") {
    if (ev.type === "system" && ev.session_id) out.push({ kind: "session", sessionId: ev.session_id });
    if (ev.type === "stream_event" && ev.event?.type === "content_block_delta" && ev.event.delta?.type === "text_delta" && ev.event.delta.text) out.push({ kind: "delta", text: ev.event.delta.text });
    if (ev.type === "assistant")
      for (const b of ev.message?.content ?? []) {
        if (b.type === "text") out.push({ kind: "text", text: b.text });
        if (b.type === "tool_use") out.push({ kind: "tool", name: b.name, input: b.input });
      }
    if (ev.type === "user") {
      for (const b of ev.message?.content ?? [])
        if (b.type === "tool_result") out.push({ kind: "tool_result", text: typeof b.content === "string" ? b.content : JSON.stringify(b.content).slice(0, 2e3) });
    }
    if (ev.type === "result") {
      if (ev.session_id) out.push({ kind: "session", sessionId: ev.session_id });
      out.push(ev.is_error ? { kind: "error", text: ev.result ?? "Claude reported an error" } : { kind: "done" });
    }
  } else if (engine === "codex") {
    if (ev.type === "thread.started") out.push({ kind: "session", sessionId: ev.thread_id });
    if (ev.type === "item.completed") {
      const it = ev.item ?? {};
      if (it.type === "agent_message") out.push({ kind: "text", text: it.text });
      else if (it.type === "command_execution") out.push({ kind: "tool", name: "shell", input: { command: it.command } }, { kind: "tool_result", text: String(it.aggregated_output ?? "").slice(0, 2e3) });
      else if (it.type === "mcp_tool_call") out.push({ kind: "tool", name: it.tool, input: it.arguments });
    }
    if (ev.type === "turn.completed") out.push({ kind: "done" });
    if (ev.type === "turn.failed" || ev.type === "error") out.push({ kind: "error", text: ev.error?.message ?? ev.message ?? "ChatGPT (Codex) error" });
  }
  return out;
}
async function* lines(stream) {
  for await (const l of stream) yield l;
}
async function* runOnComputer(p, run, signal) {
  const res = await fetch(`${p.computerUrl.replace(/\/$/, "")}/run`, {
    method: "POST",
    signal,
    headers: { "content-type": "application/json", authorization: `Bearer ${getSecret(`computer:${p.id}`) ?? ""}` },
    body: JSON.stringify(run)
  });
  if (!res.ok || !res.body) throw new Error(`Your computer said: HTTP ${res.status} ${await res.text()}`);
  const reader = res.body.getReader();
  const dec = new import_node_string_decoder2.StringDecoder("utf8");
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.write(Buffer.from(value));
    let i;
    while ((i = buf.indexOf("\n")) >= 0) {
      yield buf.slice(0, i);
      buf = buf.slice(i + 1);
    }
  }
  if (buf.trim()) yield buf;
}
async function* runOnPhone(sub, run, signal) {
  const [cmd, args] = programCommand(sub, cliArgs(run));
  const child2 = (0, import_node_child_process2.spawn)(cmd, args, { cwd: workDir(), env: { ...programEnv(sub), MAUSDROID_MCP_TOKEN: run.mcpToken }, stdio: ["ignore", "pipe", "pipe"] });
  signal.addEventListener("abort", () => child2.kill("SIGTERM"), { once: true });
  let stderr = "";
  child2.stderr.on("data", (d) => stderr = (stderr + d).slice(-4e3));
  const started2 = new Promise((ok, fail) => {
    child2.once("spawn", ok);
    child2.once("error", fail);
  });
  await started2;
  yield* lines(import_node_readline.default.createInterface({ input: child2.stdout }));
  const code = await new Promise((r) => child2.exitCode !== null ? r(child2.exitCode) : child2.on("close", r));
  if (code !== 0 && !signal.aborted) throw new Error(`${SUBS[sub].program} stopped (code ${code}): ${stderr.slice(-600)}`);
}
function withFiles(run, list, forComputer) {
  if (!list.length) return run;
  let rels;
  let files2;
  if (forComputer) {
    let total = 0;
    files2 = [];
    rels = [];
    for (const a of list) {
      if ((total += a.size) > 4e7) break;
      const rel = import_node_path6.default.join("attachments", `${a.id.slice(5, 11)}-${a.name}`);
      files2.push({ path: rel, b64: import_node_fs6.default.readFileSync(filePath(a)).toString("base64") });
      rels.push(rel);
    }
  } else rels = exportTo(workDir(), list);
  const lines2 = list.map((a, i) => rels[i] ? `- ${rels[i]} \u2014 ${describe(a)}` : null).filter(Boolean);
  const images = list.map((a, i) => a.kind === "image" && rels[i] ? rels[i] : null).filter(Boolean);
  return {
    ...run,
    images: run.engine === "codex" ? images : void 0,
    files: files2,
    prompt: `${run.prompt}

Attached files (open them with your tools; paths are relative to the current folder):
${lines2.join("\n")}`
  };
}
async function* runCli(p, run, signal) {
  const sub = p.subId;
  const { attachments = [], ...rest } = run;
  const base = { ...rest, engine: engineFor(sub) };
  const acc = { text: "" };
  const canComputer = Boolean(p.computerUrl);
  const phoneReady = p.runOn !== "computer" && isSignedIn(sub);
  if (!phoneReady && !canComputer) {
    throw new Error(`Sign in to ${SUBS[sub].label} first: Settings \u2192 AI \u2192 ${SUBS[sub].label} \u2192 Sign in.`);
  }
  let source;
  let full = withFiles(base, attachments, !phoneReady);
  if (phoneReady) {
    try {
      source = runOnPhone(sub, full, signal);
      const first = await source.next();
      if (!first.done) for (const e of parseCliLine(full.engine, first.value, acc)) yield e;
    } catch (e) {
      if (!canComputer) throw e;
      yield { kind: "tool", name: "switching to your computer", input: { reason: String(e.message).slice(0, 200) } };
      full = withFiles(base, attachments, true);
      source = runOnComputer(p, full, signal);
    }
  } else source = runOnComputer(p, full, signal);
  for await (const line of source) for (const e of parseCliLine(full.engine, line, acc)) yield e;
  if (acc.text.trim()) yield { kind: "text", text: acc.text.trim() };
}
var import_node_child_process2, import_node_readline, import_node_string_decoder2, import_node_fs6, import_node_path6, engineFor;
var init_cli = __esm({
  "src/providers/cli.ts"() {
    "use strict";
    import_node_child_process2 = require("node:child_process");
    import_node_readline = __toESM(require("node:readline"), 1);
    import_node_string_decoder2 = require("node:string_decoder");
    init_secrets();
    import_node_fs6 = __toESM(require("node:fs"), 1);
    import_node_path6 = __toESM(require("node:path"), 1);
    init_files();
    init_subscriptions();
    engineFor = (sub) => sub === "chatgpt" ? "codex" : "claude";
  }
});

// src/tools/web.ts
function needsJavaScript(html, text) {
  if (/enable javascript|requires javascript|javascript is (disabled|required)|turn on javascript/i.test(text)) return true;
  const scripts = (html.match(/<script\b/gi) ?? []).length;
  if (text.replace(/\s+/g, " ").trim().length < 600 && scripts >= 1) return true;
  if (/<div[^>]+id=["'](root|app|__next|__nuxt|svelte)["'][^>]*>\s*<\/div>/i.test(html) && text.length < 2e3) return true;
  return false;
}
async function renderInBrowser(url, waitMs) {
  const { bridge: bridge2 } = await Promise.resolve().then(() => (init_bridge(), bridge_exports));
  const opened = await bridge2("/browser/open", { url }, 9e4);
  try {
    await new Promise((r) => setTimeout(r, Math.min(15e3, Math.max(0, waitMs))));
    const read = await bridge2("/browser/read", { tab: opened.tab, mode: "text" }, 3e4);
    const text = String(read.text ?? opened.text ?? "");
    return clip(`Rendered with JavaScript: ${opened.url}
Title: ${opened.title}

${text}`);
  } finally {
    await bridge2("/browser/close", { tab: opened.tab }).catch(() => {
    });
  }
}
async function webFetch(url, render = "auto", waitMs = 2500) {
  const u = new URL(url);
  if (!/^https?:$/.test(u.protocol)) throw new Error("Only http and https links can be fetched.");
  const { bridgeAvailable: bridgeAvailable2 } = await Promise.resolve().then(() => (init_bridge(), bridge_exports));
  if (render === "always") {
    if (!bridgeAvailable2()) throw new Error("Showing JavaScript pages needs the Android app's background browser.");
    return renderInBrowser(u.toString(), waitMs);
  }
  const res = await fetch(u, {
    headers: { "user-agent": "Mozilla/5.0 (Linux; Android 15) MausDroid/0.1", accept: "text/html,application/json,text/plain;q=0.9,*/*;q=0.5" },
    redirect: "follow",
    signal: AbortSignal.timeout(3e4)
  });
  const type = res.headers.get("content-type") ?? "";
  const body = await res.text();
  const isHtml = type.includes("html");
  const text = isHtml ? htmlToText(body) : body;
  if (isHtml && render === "auto" && needsJavaScript(body, text)) {
    if (bridgeAvailable2()) {
      try {
        return await renderInBrowser(res.url || u.toString(), waitMs);
      } catch (e) {
        return clip(`HTTP ${res.status} ${res.url}
(This page needs JavaScript and the background browser couldn't open it: ${e.message})

${text}`);
      }
    }
    return clip(`HTTP ${res.status} ${res.url}
(This page builds its content with JavaScript, so this plain copy may be incomplete. On the phone MausDroid opens such pages in its background browser.)

${text}`);
  }
  return clip(`HTTP ${res.status} ${res.url}

${text}`);
}
async function webSearch(query) {
  const res = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`, {
    headers: { "user-agent": "Mozilla/5.0 (Linux; Android 15) MausDroid/0.1" },
    signal: AbortSignal.timeout(2e4)
  });
  const html = await res.text();
  const results = [];
  const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>)?/g;
  let m;
  while ((m = re.exec(html)) && results.length < 10) {
    let link = m[1];
    const uddg = link.match(/uddg=([^&]+)/);
    if (uddg) link = decodeURIComponent(uddg[1]);
    results.push(`${results.length + 1}. ${htmlToText(m[2])}
   ${link}
   ${htmlToText(m[3] ?? "")}`);
  }
  return results.length ? results.join("\n\n") : "No results (the search page may have changed; try the browser tool).";
}
function tailnetFetch(url, method = "GET", body, headers2 = {}) {
  const [phost, pport] = config.tailnetProxy.split(":");
  const u = new URL(url);
  return new Promise((resolve, reject) => {
    const done = (res) => {
      let data = "";
      res.setEncoding("utf8");
      res.on("data", (c) => data += c);
      res.on("end", () => resolve(clip(`HTTP ${res.statusCode}

${data}`)));
    };
    if (u.protocol === "http:") {
      const req = import_node_http2.default.request({ host: phost, port: Number(pport), method, path: url, headers: { host: u.host, ...headers2 } }, done);
      req.on("error", (e) => reject(new Error(`Tailnet: ${e.message} (is Tailscale on? Settings \u2192 Tailscale)`)));
      req.setTimeout(3e4, () => req.destroy(new Error("timed out")));
      if (body) req.write(body);
      req.end();
      return;
    }
    const connect = import_node_http2.default.request({ host: phost, port: Number(pport), method: "CONNECT", path: `${u.hostname}:${u.port || 443}` });
    connect.on("connect", (_res, socket) => {
      const tlsSock = import_node_tls2.default.connect({ socket, servername: u.hostname });
      const req = import_node_https2.default.request({ createConnection: () => tlsSock, method, path: u.pathname + u.search, headers: { host: u.host, ...headers2 } }, done);
      req.on("error", reject);
      if (body) req.write(body);
      req.end();
    });
    connect.on("error", (e) => reject(new Error(`Tailnet: ${e.message}`)));
    connect.end();
  });
}
var import_node_http2, import_node_https2, import_node_tls2;
var init_web = __esm({
  "src/tools/web.ts"() {
    "use strict";
    import_node_http2 = __toESM(require("node:http"), 1);
    import_node_https2 = __toESM(require("node:https"), 1);
    import_node_tls2 = __toESM(require("node:tls"), 1);
    init_config();
    init_util();
  }
});

// src/notify.ts
function inQuietHours() {
  const q = settings().quietHours;
  if (!q) return false;
  const t = localParts(/* @__PURE__ */ new Date()).hm;
  return q.start <= q.end ? t >= q.start && t < q.end : t >= q.start || t < q.end;
}
async function notifyUser(a) {
  const alert = {
    id: id("alert"),
    title: a.title,
    body: a.body,
    botId: a.botId,
    cardId: a.cardId,
    priority: a.priority ?? "normal",
    at: now(),
    read: false,
    type: a.type ?? (a.cardId ? "approval" : "bot-alert"),
    source: a.source,
    routineId: a.routineId,
    eventId: a.eventId,
    link: a.link
  };
  alerts.update((l) => {
    l.push(alert);
    if (l.length > 500) l.splice(0, l.length - 500);
  });
  emit("alert", { alert });
  for (const l of alertListeners) {
    try {
      l(alert);
    } catch {
    }
  }
  if (a.silentRecord) return alert;
  if (inQuietHours() && alert.priority !== "high") return alert;
  if (bridgeAvailable()) {
    await bridge("/notify", { ...a, id: alert.id, silent: alert.priority === "low" }).catch(() => {
    });
  }
  return alert;
}
function markAlertsRead() {
  alerts.update((l) => l.forEach((x) => x.read = true));
}
var alertListeners, onAlert, alerts, listAlerts;
var init_notify = __esm({
  "src/notify.ts"() {
    "use strict";
    init_bridge();
    init_events();
    init_store();
    init_util();
    init_settings();
    init_time();
    alertListeners = /* @__PURE__ */ new Set();
    onAlert = (fn) => {
      alertListeners.add(fn);
      return () => alertListeners.delete(fn);
    };
    alerts = collection("alerts", []);
    listAlerts = () => alerts.get().slice().reverse();
  }
});

// src/approvals.ts
function pendingCards() {
  return [...pending.values()].map(({ resolve, ...rest }) => rest);
}
function requestApproval(botId, tool, title, detail, signal, label) {
  const bot = getBot(botId);
  if (bot?.alwaysAllow.includes(tool)) return Promise.resolve({ allow: true });
  return open({ kind: "approval", botId, tool, toolLabel: label, title, detail }, signal);
}
function askQuestion(botId, question, options, signal) {
  return open({ kind: "question", botId, title: question, detail: "", options }, signal);
}
function open(p, signal) {
  return new Promise((resolve) => {
    const card = { ...p, id: id("card"), createdAt: (/* @__PURE__ */ new Date()).toISOString(), resolve };
    pending.set(card.id, card);
    const { resolve: _r, ...pub } = card;
    emit("card", { card: pub });
    const bot = getBot(p.botId);
    void notifyUser({
      title: `${bot?.emoji ?? "\u{1F916}"} ${bot?.name ?? "Bot"} ${p.kind === "approval" ? "needs your OK" : "has a question"}`,
      body: p.kind === "approval" ? `${p.title}
${p.detail}`.slice(0, 300) : p.title,
      botId: p.botId,
      cardId: card.id,
      actions: p.kind === "approval" ? ["Allow", "Deny"] : void 0,
      priority: "high"
    });
    signal?.addEventListener("abort", () => settle(card.id, { allow: false, answer: "(stopped)" }), { once: true });
  });
}
function settle(cardId, r) {
  const card = pending.get(cardId);
  if (!card) return false;
  pending.delete(cardId);
  if (r.always && card.tool) {
    const bot = getBot(card.botId);
    if (bot && !bot.alwaysAllow.includes(card.tool)) updateBot(bot.id, { alwaysAllow: [...bot.alwaysAllow, card.tool] });
  }
  emit("card.settled", { cardId, allow: r.allow, answer: r.answer });
  card.resolve(r);
  return true;
}
var pending;
var init_approvals = __esm({
  "src/approvals.ts"() {
    "use strict";
    init_events();
    init_util();
    init_bots();
    init_notify();
    pending = /* @__PURE__ */ new Map();
  }
});

// src/memory.ts
function readMemory(scope) {
  try {
    return import_node_fs7.default.readFileSync(file2(scope), "utf8");
  } catch {
    return "";
  }
}
function appendMemory(scope, note) {
  const line = `- ${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}: ${note.replace(/\n+/g, " ").trim()}
`;
  import_node_fs7.default.appendFileSync(file2(scope), line);
}
function writeMemory(scope, text) {
  import_node_fs7.default.writeFileSync(file2(scope), text);
}
var import_node_fs7, file2;
var init_memory = __esm({
  "src/memory.ts"() {
    "use strict";
    import_node_fs7 = __toESM(require("node:fs"), 1);
    init_store();
    file2 = (scope) => dataPath("memory", `${scope.replace(/[^a-zA-Z0-9_-]/g, "")}.md`);
  }
});

// src/schedule.ts
function withTimeZone(tz, fn) {
  if (!tz || tz === "local") return fn();
  const before = process.env.TZ;
  process.env.TZ = tz;
  try {
    return fn();
  } finally {
    if (before === void 0) delete process.env.TZ;
    else process.env.TZ = before;
  }
}
function inWindow(d, w) {
  if (!w) return true;
  if (w.days?.length && !w.days.includes(d.getDay())) return false;
  const [sh, sm] = parseHM(w.start);
  const [eh, em] = parseHM(w.end);
  const m = minutesOf(d);
  const a = sh * 60 + sm;
  const b = eh * 60 + em;
  return a <= b ? m >= a && m <= b : m >= a || m <= b;
}
function validateSchedule(s) {
  const errs = [];
  try {
    if (s.kind === "daily" || s.kind === "weekly") {
      if (!s.time) errs.push("Choose a time.");
      else parseHM(s.time);
    }
    if (s.kind === "weekly" && !(s.days ?? []).length) errs.push("Choose at least one weekday.");
    if ((s.days ?? []).some((d) => d < 0 || d > 6)) errs.push("Weekdays are 0 (Sunday) to 6 (Saturday).");
    if (s.kind === "interval" && (s.minutes ?? 60) < 15) errs.push("Intervals must be at least 15 minutes.");
    if (s.kind === "once" && (!s.at || isNaN(Date.parse(s.at)))) errs.push("Choose a date and time.");
    if (s.kind === "custom") {
      const c = s.custom;
      if (!c) errs.push("Describe the custom schedule.");
      else if (c.mode === "interval" && (c.minutes ?? 0) < 15) errs.push("Intervals must be at least 15 minutes.");
      else if (c.mode === "dates" && !(c.dates ?? []).length) errs.push("Add at least one date and time.");
      else if (c.mode === "dates" && (c.dates ?? []).some((x) => !/^\d{4}-\d\d-\d\dT\d\d:\d\d$/.test(x))) errs.push('Dates look like "2026-12-01T07:30".');
      else if (c.mode === "recurring") {
        if (!(c.times ?? []).length) errs.push("Add at least one time.");
        (c.times ?? []).forEach(parseHM);
        if ((c.everyDays ?? 1) < 1) errs.push("Repeat every 1 day or more.");
      }
    }
    if (s.window) {
      parseHM(s.window.start);
      parseHM(s.window.end);
    }
    if (s.kind === "alert" && !s.alert) errs.push("Say which alerts should start it.");
    if (s.kind === "geofence") {
      const g = s.geofence;
      if (!g || Math.abs(g.lat) > 90 || Math.abs(g.lng) > 180) errs.push("Give a valid place (latitude/longitude).");
      else if (g.radiusM < 100 || g.radiusM > 5e4) errs.push("Radius must be between 100 m and 50 km.");
    }
    if (s.timeZone && s.timeZone !== "local" && !/^[A-Za-z_]+(\/[A-Za-z0-9_+\-]+)+$|^UTC$/.test(s.timeZone)) errs.push(`Unknown time zone "${s.timeZone}".`);
  } catch (e) {
    errs.push(e.message);
  }
  return errs;
}
function nextOccurrence(s, from) {
  return withTimeZone(s.timeZone, () => next(s, from));
}
function next(s, from) {
  switch (s.kind) {
    case "alert":
    case "geofence":
      return null;
    case "once": {
      const t = s.at ? new Date(s.at) : null;
      return t && t > from ? { at: t, key: `once@${t.toISOString()}` } : null;
    }
    case "interval":
      return intervalNext(from, s.minutes ?? 60, s.window);
    case "daily":
    case "weekly": {
      const [h, m] = parseHM(s.time ?? "");
      for (let i = 0; i < 400; i++) {
        const c = new Date(from.getFullYear(), from.getMonth(), from.getDate() + i, h, m, 0, 0);
        if (c <= from) continue;
        if (s.kind === "weekly" && !(s.days ?? []).includes(c.getDay())) continue;
        if (!inWindow(c, s.window)) continue;
        return { at: c, key: localKey(new Date(c.getFullYear(), c.getMonth(), c.getDate(), h, m)) };
      }
      return null;
    }
    case "custom": {
      const c = s.custom;
      if (!c) return null;
      if (c.mode === "interval") return intervalNext(from, c.minutes ?? 60, s.window);
      if (c.mode === "dates") {
        const all = (c.dates ?? []).map((x) => {
          const [d, t] = x.split("T");
          const [Y, M, D] = d.split("-").map(Number);
          const [h, m] = t.split(":").map(Number);
          return { at: new Date(Y, M - 1, D, h, m), key: `date@${x}` };
        }).filter((o) => o.at > from && inWindow(o.at, s.window)).sort((a, b) => a.at.getTime() - b.at.getTime());
        return all[0] ?? null;
      }
      const times = (c.times ?? []).map(parseHM).sort((a, b) => a[0] * 60 + a[1] - (b[0] * 60 + b[1]));
      const every = Math.max(1, c.everyDays ?? 1);
      const [sy, sm, sd] = (c.startDate ?? "").split("-").map(Number);
      const start = c.startDate ? new Date(sy, sm - 1, sd) : new Date(from.getFullYear(), from.getMonth(), from.getDate());
      for (let i = 0; i < 800; i++) {
        const day = new Date(from.getFullYear(), from.getMonth(), from.getDate() + i);
        const diff = Math.round((day.getTime() - start.getTime()) / 864e5);
        if (diff < 0 || diff % every !== 0) continue;
        if (c.days?.length && !c.days.includes(day.getDay())) continue;
        for (const [h, m] of times) {
          const at = new Date(day.getFullYear(), day.getMonth(), day.getDate(), h, m);
          if (at > from && inWindow(at, s.window)) return { at, key: localKey(new Date(day.getFullYear(), day.getMonth(), day.getDate(), h, m)) };
        }
      }
      return null;
    }
  }
}
function intervalNext(from, minutes2, window) {
  const step2 = Math.max(15, minutes2) * 6e4;
  let t = Math.floor(from.getTime() / step2) * step2 + step2;
  for (let i = 0; i < 1e4; i++, t += step2) {
    const d = new Date(t);
    if (inWindow(d, window)) return { at: d, key: `every${minutes2}@${d.toISOString()}` };
  }
  return null;
}
function describeSchedule(s) {
  const tz = s.timeZone && s.timeZone !== "local" ? ` (${s.timeZone})` : "";
  const win = s.window ? `, only between ${time12(s.window.start)} and ${time12(s.window.end)}${s.window.days?.length ? ` on ${dayList(s.window.days)}` : ""}` : "";
  const cond = s.conditions ? `, if ${s.conditions}` : "";
  try {
    switch (s.kind) {
      case "alert": {
        const a = s.alert ?? {};
        const what = [a.type && `${a.type} alerts`, a.source && `from "${a.source}"`, a.contains && `mentioning "${a.contains}"`, a.minPriority && a.minPriority !== "low" && `${a.minPriority}+ priority`].filter(Boolean).join(" ");
        return `Upon alert: ${what || "any alert"}${cond}`;
      }
      case "daily":
        return `Once a day at ${time12(s.time)}${tz}${win}${cond}`;
      case "weekly":
        return `Once a week: ${dayList(s.days ?? [])} at ${time12(s.time)}${tz}${win}${cond}`;
      case "once":
        return `Once on ${new Date(s.at).toLocaleString()}${cond}`;
      case "interval":
        return `Every ${s.minutes ?? 60} minutes${win}${cond}`;
      case "geofence":
        return `When you ${s.geofence?.on === "exit" ? "leave" : "arrive at"} a place (${s.geofence?.radiusM} m radius) \u2014 not active in this version`;
      case "custom": {
        const c = s.custom;
        if (c.mode === "interval") return `Every ${c.minutes} minutes${tz}${win}${cond}`;
        if (c.mode === "dates") return `On ${(c.dates ?? []).map((d) => d.replace("T", " at ")).join("; ")}${tz}${win}${cond}`;
        return `Every ${(c.everyDays ?? 1) === 1 ? "day" : `${c.everyDays} days`}${c.days?.length ? ` (${dayList(c.days)})` : ""} at ${(c.times ?? []).map(time12).join(", ")}${tz}${win}${cond}`;
      }
    }
  } catch {
    return "Schedule needs fixing";
  }
}
var pad2, HM, parseHM, minutesOf, localKey, DAY, time12, dayList;
var init_schedule = __esm({
  "src/schedule.ts"() {
    "use strict";
    pad2 = (n) => String(n).padStart(2, "0");
    HM = /^([01]?\d|2[0-3]):([0-5]\d)$/;
    parseHM = (s) => {
      const m = s.match(HM);
      if (!m) throw new Error(`"${s}" isn't a time like 07:30`);
      return [Number(m[1]), Number(m[2])];
    };
    minutesOf = (d) => d.getHours() * 60 + d.getMinutes();
    localKey = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}@${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
    DAY = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    time12 = (hm) => {
      const [h, m] = parseHM(hm);
      return `${h % 12 || 12}:${pad2(m)} ${h < 12 ? "am" : "pm"}`;
    };
    dayList = (d) => d.length === 7 ? "every day" : d.length === 5 && [1, 2, 3, 4, 5].every((x) => d.includes(x)) ? "weekdays" : d.map((x) => DAY[x]).join(", ");
  }
});

// src/routines.ts
function computeNext(r, from = /* @__PURE__ */ new Date()) {
  const o = nextOccurrence(r.schedule, from);
  return { nextRunAt: o?.at.toISOString(), nextKey: o?.key };
}
function check(schedule) {
  const errs = validateSchedule(schedule);
  if (errs.length) throw new Error(errs.join(" "));
  if (schedule.kind === "geofence") throw new Error("Place-based (geofence) routines are prepared but not switched on in this version.");
}
function createRoutine(input) {
  check(input.schedule);
  if (!input.title?.trim()) throw new Error("Give the routine a short title.");
  if (!input.prompt?.trim()) throw new Error("Say what the routine should do.");
  const routine = {
    retry: { max: 1, delayMinutes: 5 },
    timeoutMinutes: 15,
    ...input,
    title: input.title.trim(),
    id: id("rt"),
    createdAt: now(),
    enabled: input.enabled ?? true
  };
  Object.assign(routine, routine.enabled ? computeNext(routine) : { nextRunAt: void 0, nextKey: void 0 });
  file3.update((l) => void l.push(routine));
  emit("routines.changed", {});
  return routine;
}
function updateRoutine(rid, patch3) {
  let out;
  if (patch3.schedule) check(patch3.schedule);
  file3.update((l) => {
    const r = l.find((x) => x.id === rid);
    if (!r) throw new Error("No such routine");
    const { id: _id, createdAt: _c, botId: _b, system: _s, ...safe } = patch3;
    Object.assign(r, safe, { updatedAt: now() });
    Object.assign(r, r.enabled ? computeNext(r) : { nextRunAt: void 0, nextKey: void 0 });
    out = { ...r };
  });
  emit("routines.changed", {});
  return out;
}
function deleteRoutine(rid) {
  file3.update((l) => {
    const i = l.findIndex((x) => x.id === rid);
    if (i >= 0) l.splice(i, 1);
  });
  emit("routines.changed", {});
}
function advance(rid, from) {
  file3.update((l) => {
    const r = l.find((x) => x.id === rid);
    if (!r) return;
    Object.assign(r, computeNext(r, from));
    if (!r.nextRunAt && (r.schedule.kind === "once" || r.schedule.kind === "custom" && r.schedule.custom?.mode === "dates")) r.enabled = false;
  });
  emit("routines.changed", {});
}
function addRun(r) {
  const run = { ...r, id: id("run"), queuedAt: now() };
  runsFile.update((l) => {
    l.push(run);
    if (l.length > 3e3) l.splice(0, l.length - 3e3);
  });
  emit("routines.changed", {});
  return run;
}
function patchRun(runId, patch3) {
  let out;
  runsFile.update((l) => {
    const r = l.find((x) => x.id === runId);
    if (r) {
      Object.assign(r, patch3);
      out = { ...r };
    }
  });
  if (out && patch3.status && ["succeeded", "failed", "timed_out", "missed", "skipped"].includes(patch3.status)) {
    file3.update((l) => {
      const rt = l.find((x) => x.id === out.routineId);
      if (rt) rt.lastResult = { status: out.status, at: now(), summary: (out.result ?? out.error ?? "").slice(0, 300) };
    });
  }
  emit("routines.changed", {});
  return out;
}
function markRoutineRan(rid) {
  file3.update((l) => {
    const r = l.find((x) => x.id === rid);
    if (r) r.lastRunAt = now();
  });
}
function historySummary(routineId) {
  const recent2 = listRuns(routineId, 20);
  const count = (s) => recent2.filter((r) => r.status === s).length;
  return { last20: { succeeded: count("succeeded"), failed: count("failed") + count("timed_out"), missed: count("missed"), skipped: count("skipped") }, lastStatus: recent2[0]?.status ?? null };
}
function routineDetails(r) {
  return {
    id: r.id,
    title: r.title,
    prompt: r.prompt,
    botId: r.botId,
    schedule: r.schedule,
    scheduleText: describeSchedule(r.schedule),
    enabled: r.enabled,
    nextRunAt: r.nextRunAt ?? null,
    lastRunAt: r.lastRunAt ?? null,
    lastResult: r.lastResult ?? null,
    history: historySummary(r.id),
    retry: r.retry,
    timeoutMinutes: r.timeoutMinutes,
    deadline: r.deadline ?? null,
    system: r.system ?? null
  };
}
var file3, runsFile, listRoutines, getRoutine, pauseRoutine, resumeRoutine, listRuns, getRun;
var init_routines = __esm({
  "src/routines.ts"() {
    "use strict";
    init_store();
    init_util();
    init_events();
    init_schedule();
    file3 = collection("routines", []);
    runsFile = collection("routine-runs", []);
    file3.update((l) => {
      for (const r of l) {
        r.retry ??= { max: 1, delayMinutes: 5 };
        r.timeoutMinutes ??= 15;
        if (r.enabled && !r.nextKey && r.nextRunAt) r.nextKey = `legacy@${r.nextRunAt}`;
      }
    });
    listRoutines = (botId) => file3.get().filter((r) => !botId || r.botId === botId);
    getRoutine = (rid) => file3.get().find((r) => r.id === rid);
    pauseRoutine = (rid) => updateRoutine(rid, { enabled: false });
    resumeRoutine = (rid) => updateRoutine(rid, { enabled: true });
    listRuns = (routineId, limit = 50) => runsFile.get().filter((r) => !routineId || r.routineId === routineId).slice(-limit).reverse();
    getRun = (runId) => runsFile.get().find((r) => r.id === runId);
  }
});

// src/scheduler.ts
var scheduler_exports = {};
__export(scheduler_exports, {
  addRunValidator: () => addRunValidator,
  execute: () => execute,
  handleAlert: () => handleAlert,
  matchesAlert: () => matchesAlert,
  recoverAfterRestart: () => recoverAfterRestart,
  runRoutineNow: () => runRoutineNow,
  startScheduler: () => startScheduler,
  tick: () => tick
});
function lockedBy(routineId) {
  const runId = active.get(routineId);
  if (!runId) return null;
  const run = getRun(runId);
  if (!run || !["queued", "running"].includes(run.status)) {
    active.delete(routineId);
    return null;
  }
  return run;
}
function deadlineFor(r, from) {
  if (!r.deadline) return null;
  const [h, m] = r.deadline.split(":").map(Number);
  return withTimeZone(r.schedule.timeZone, () => new Date(from.getFullYear(), from.getMonth(), from.getDate(), h, m));
}
function promptFor(r, run, extra = "") {
  const bits = [
    r.prompt,
    r.schedule.conditions ? `
Only act if this condition holds: ${r.schedule.conditions}. If it doesn't, reply "Condition not met" and stop.` : "",
    extra,
    `
(This is your routine "${r.title}" \u2014 ${describeSchedule(r.schedule)}. Run ${run.id}, attempt ${run.attempt}. The person is probably not watching: if there's something they should know, use notify_user; otherwise reply briefly with what you did.)`
  ];
  return bits.join("\n");
}
function execute(r, key2, trigger, opts = {}) {
  if (!getBot(r.botId)) return null;
  if (trigger !== "retry" && listRuns(r.id, 200).some((x) => x.key === key2 && ["queued", "running", "succeeded"].includes(x.status))) return null;
  const busy = lockedBy(r.id);
  if (busy) {
    return addRun({ routineId: r.id, botId: r.botId, key: key2, trigger, status: "skipped", attempt: opts.attempt ?? 1, scheduledFor: opts.scheduledFor, error: `Previous run ${busy.id} was still ${busy.status}.` });
  }
  const run = addRun({ routineId: r.id, botId: r.botId, key: key2, trigger, status: "queued", attempt: opts.attempt ?? 1, scheduledFor: opts.scheduledFor });
  active.set(r.id, run.id);
  markRoutineRan(r.id);
  const started2 = /* @__PURE__ */ new Date();
  let limit = started2.getTime() + (r.timeoutMinutes ?? 15) * 6e4;
  const dl = deadlineFor(r, started2);
  if (dl && dl.getTime() > started2.getTime()) limit = Math.min(limit, dl.getTime());
  timers.set(
    run.id,
    setTimeout(() => timedOut(run.id), Math.max(1e3, limit - started2.getTime()))
  );
  sendToBot(r.botId, promptFor(r, run, opts.extra), `routine: ${r.title}`, [], run.id);
  return run;
}
function finish(runId, status2, text) {
  if (status2 === "succeeded") {
    const cur = getRun(runId);
    const rt = cur ? getRoutine(cur.routineId) : void 0;
    const problem = rt?.system ? validators.get(rt.system)?.(cur) : null;
    if (problem) {
      status2 = "failed";
      text = `${problem}${text ? `

Bot said: ${text}` : ""}`;
    }
  }
  clearTimeout(timers.get(runId));
  timers.delete(runId);
  const run = patchRun(runId, { status: status2, finishedAt: (/* @__PURE__ */ new Date()).toISOString(), ...status2 === "succeeded" ? { result: clip(text, 2e3) } : { error: clip(text || status2, 2e3) } });
  if (!run) return;
  if (active.get(run.routineId) === runId) active.delete(run.routineId);
  const r = getRoutine(run.routineId);
  if (!r) return;
  if (status2 === "failed" || status2 === "timed_out") {
    const retry = r.retry ?? { max: 1, delayMinutes: 5 };
    const late = r.deadline ? (deadlineFor(r, /* @__PURE__ */ new Date())?.getTime() ?? Infinity) <= Date.now() + retry.delayMinutes * 6e4 : false;
    if (run.attempt <= retry.max && !late) {
      patchRun(runId, { retryAt: new Date(Date.now() + retry.delayMinutes * 6e4).toISOString() });
    } else {
      const bot = getBot(r.botId);
      void notifyUser({
        title: `${bot?.emoji ?? "\u26A0\uFE0F"} Routine "${r.title}" ${status2 === "timed_out" ? "ran out of time" : "failed"}`,
        body: clip(text || "No details.", 280),
        botId: r.botId,
        priority: "normal",
        type: "routine-result",
        source: r.title,
        routineId: r.id
      });
    }
  }
}
function timedOut(runId) {
  const run = getRun(runId);
  if (!run || !["queued", "running"].includes(run.status)) return;
  if (currentRunTags(run.botId).includes(runId)) stopBot(run.botId);
  finish(runId, "timed_out", "The run took too long and was stopped.");
}
function matchesAlert(r, a) {
  const t = r.schedule.alert;
  if (r.schedule.kind !== "alert" || !t || !r.enabled) return false;
  if (a.routineId === r.id) return false;
  if (t.type && t.type !== a.type) return false;
  if (t.source && !(a.source ?? "").toLowerCase().includes(t.source.toLowerCase())) return false;
  if (t.minPriority && RANK[a.priority] < RANK[t.minPriority]) return false;
  if (t.contains && !`${a.title}
${a.body}`.toLowerCase().includes(t.contains.toLowerCase())) return false;
  return true;
}
function handleAlert(a) {
  for (const r of listRoutines()) {
    if (!matchesAlert(r, a)) continue;
    const eventKey = a.eventId ?? `${a.type}|${a.source}|${a.title}|${a.body}`.slice(0, 500);
    const k = `${r.id}|${eventKey}`;
    const ttl = (r.schedule.alert?.dedupeMinutes ?? 60) * 6e4;
    const seen = recentAlertKeys.get(k);
    if (seen && Date.now() - seen < ttl) continue;
    recentAlertKeys.set(k, Date.now());
    execute(r, `alert@${eventKey}`, "alert", { extra: `
The alert that started this:
Type: ${a.type}
From: ${a.source ?? "?"}
Priority: ${a.priority}
Title: ${a.title}
${a.body}` });
  }
  for (const [k, t] of recentAlertKeys) if (Date.now() - t > 24 * 36e5) recentAlertKeys.delete(k);
}
function runRoutineNow(rid) {
  const r = getRoutine(rid);
  if (!r) throw new Error("No such routine");
  const run = execute(r, `manual@${(/* @__PURE__ */ new Date()).toISOString()}`, "manual");
  if (!run) throw new Error("Couldn't start it (its bot is missing).");
  return run;
}
function tick(at = /* @__PURE__ */ new Date()) {
  for (const r of listRoutines()) {
    if (!r.enabled || !r.nextRunAt || !r.nextKey) continue;
    const due = new Date(r.nextRunAt);
    if (due > at) continue;
    const late = at.getTime() - due.getTime();
    if (late <= GRACE_MS) {
      execute(r, r.nextKey, "schedule", { scheduledFor: r.nextRunAt });
    } else {
      const policy = r.schedule.missedPolicy ?? "run-once";
      const tooLate = late > (r.schedule.catchUpHours ?? 12) * 36e5 || r.deadline && (deadlineFor(r, at)?.getTime() ?? Infinity) <= at.getTime();
      if (policy === "run-once" && !tooLate) execute(r, r.nextKey, "catch-up", { scheduledFor: r.nextRunAt, extra: `
(This run was due at ${due.toLocaleString()} but the phone missed it; it's running late.)` });
      else {
        addRun({ routineId: r.id, botId: r.botId, key: r.nextKey, trigger: "schedule", status: "missed", attempt: 1, scheduledFor: r.nextRunAt, error: tooLate ? "Missed and too late to catch up." : "Missed (set to skip missed runs)." });
        if (r.deadline) void notifyUser({ title: `Routine "${r.title}" was missed`, body: `It was due ${due.toLocaleString()} and couldn't run before its deadline.`, botId: r.botId, type: "routine-result", source: r.title, routineId: r.id });
      }
    }
    advance(r.id, at);
  }
  for (const run of listRuns(void 0, 300)) {
    if (!run.retryAt || run.retried || new Date(run.retryAt) > at) continue;
    patchRun(run.id, { retried: true });
    const r = getRoutine(run.routineId);
    if (r?.enabled) execute(r, run.key, "retry", { attempt: run.attempt + 1, scheduledFor: run.scheduledFor });
  }
}
function recoverAfterRestart() {
  for (const run of listRuns(void 0, 300)) {
    if (run.status === "queued" || run.status === "running") finish(run.id, "failed", "MausDroid restarted during this run.");
  }
}
function listen() {
  onTurnStart((_botId, tags) => {
    for (const t of tags) {
      const run = getRun(t);
      if (run?.status === "queued") patchRun(t, { status: "running", startedAt: (/* @__PURE__ */ new Date()).toISOString() });
    }
  });
  onTurnEnd((_botId, reply, info) => {
    for (const t of info?.tags ?? []) {
      const run = getRun(t);
      if (!run || !["queued", "running"].includes(run.status)) continue;
      finish(t, info.aborted || info.failed ? "failed" : "succeeded", info.aborted ? "Stopped before it finished." : reply);
    }
  });
}
function startScheduler() {
  if (started) return;
  started = true;
  listen();
  recoverAfterRestart();
  onAlert(handleAlert);
  setInterval(() => tick(), 3e4);
  tick();
}
var GRACE_MS, timers, active, recentAlertKeys, validators, addRunValidator, RANK, started;
var init_scheduler = __esm({
  "src/scheduler.ts"() {
    "use strict";
    init_routines();
    init_agent();
    init_bots();
    init_notify();
    init_schedule();
    init_util();
    GRACE_MS = 3 * 6e4;
    timers = /* @__PURE__ */ new Map();
    active = /* @__PURE__ */ new Map();
    recentAlertKeys = /* @__PURE__ */ new Map();
    validators = /* @__PURE__ */ new Map();
    addRunValidator = (system, fn) => validators.set(system, fn);
    RANK = { low: 0, normal: 1, high: 2 };
    started = false;
  }
});

// src/mcp.ts
var McpClient;
var init_mcp = __esm({
  "src/mcp.ts"() {
    "use strict";
    init_sse();
    McpClient = class {
      constructor(url, headers2 = {}) {
        this.url = url;
        this.headers = headers2;
      }
      sessionId = null;
      nextId = 1;
      initialized = false;
      async rpc(method, params, notify = false) {
        const body = { jsonrpc: "2.0", method, params };
        if (!notify) body.id = this.nextId++;
        const h = {
          "content-type": "application/json",
          accept: "application/json, text/event-stream",
          ...this.headers
        };
        if (this.sessionId) h["mcp-session-id"] = this.sessionId;
        const res = await fetch(this.url, { method: "POST", headers: h, body: JSON.stringify(body), signal: AbortSignal.timeout(18e4) });
        const sid = res.headers.get("mcp-session-id");
        if (sid) this.sessionId = sid;
        if (notify) return null;
        if (!res.ok) throw new Error(`MCP ${method}: HTTP ${res.status} ${(await res.text()).slice(0, 300)}`);
        let msg;
        if ((res.headers.get("content-type") ?? "").includes("text/event-stream")) {
          for await (const { data } of readSSE(res)) {
            const m = JSON.parse(data);
            if (m.id === body.id) {
              msg = m;
              break;
            }
          }
        } else msg = await res.json();
        if (msg?.error) throw new Error(`MCP ${method}: ${msg.error.message}`);
        return msg?.result;
      }
      async init() {
        if (this.initialized) return;
        await this.rpc("initialize", {
          protocolVersion: "2025-06-18",
          capabilities: {},
          clientInfo: { name: "MausDroid", version: "0.1" }
        });
        await this.rpc("notifications/initialized", void 0, true);
        this.initialized = true;
      }
      async listTools() {
        await this.init();
        const out = [];
        let cursor;
        do {
          const r = await this.rpc("tools/list", cursor ? { cursor } : {});
          for (const t of r.tools ?? []) out.push({ name: t.name, description: t.description ?? "", inputSchema: t.inputSchema ?? { type: "object" } });
          cursor = r.nextCursor;
        } while (cursor);
        return out;
      }
      async callTool(name, args) {
        await this.init();
        const r = await this.rpc("tools/call", { name, arguments: args ?? {} });
        const parts = [];
        const images = [];
        for (const c of r.content ?? []) {
          if (c.type === "text") parts.push(c.text);
          else if (c.type === "image") images.push({ mediaType: c.mimeType, data: c.data });
          else parts.push(JSON.stringify(c));
        }
        if (r.structuredContent && !parts.length) parts.push(JSON.stringify(r.structuredContent));
        return { text: parts.join("\n"), isError: Boolean(r.isError), images };
      }
    };
  }
});

// src/composio.ts
async function responseError(res) {
  const t = await res.text();
  try {
    const j = JSON.parse(t);
    return j.error?.message ?? j.message ?? t.slice(0, 300);
  } catch {
    return t.slice(0, 300);
  }
}
async function createSession(key2, userId) {
  const res = await fetch(`${API2}/tool_router/session`, {
    method: "POST",
    headers: headers(key2, true),
    body: JSON.stringify({
      user_id: userId,
      manage_connections: { enable: true, enable_wait_for_connections: true, enable_connection_removal: true },
      multi_account: { enable: true, max_accounts_per_toolkit: 10, require_explicit_selection: true },
      // Apps signed in with your own developer app (e.g. eBay) use your sign-in setup.
      ...Object.keys(settings().composio.authConfigs ?? {}).length ? { auth_configs: settings().composio.authConfigs } : {}
    }),
    signal: AbortSignal.timeout(3e4)
  });
  if (!res.ok) throw new Error(`Composio refused this key: ${await responseError(res)}`);
  const j = await res.json();
  const u = new URL(j.mcp.url);
  if (!process.env.MAUSDROID_COMPOSIO_API && (u.protocol !== "https:" || !(u.hostname === "composio.dev" || u.hostname.endsWith(".composio.dev"))))
    throw new Error("Composio returned an untrusted MCP address");
  return j;
}
async function connectComposio(key2) {
  key2 = key2.trim();
  if (!key2.startsWith("ak_")) throw new Error("Composio project API keys start with ak_ (from the project's API Keys page).");
  const userId = settings().composio.userId ?? `mausdroid_${(0, import_node_crypto4.randomUUID)()}`;
  const s = await createSession(key2, userId);
  await setSecret("composio", key2);
  updateSettings((st) => {
    st.composio = { userId, sessionId: s.session_id, mcpUrl: s.mcp.url };
  });
  client = null;
  tools = null;
}
async function disconnectComposio() {
  await setSecret("composio", null);
  updateSettings((st) => {
    st.composio = { userId: st.composio.userId };
  });
  client = null;
  tools = null;
}
function mcp() {
  const key2 = getSecret("composio");
  const url = settings().composio.mcpUrl;
  if (!key2 || !url) return null;
  client ??= new McpClient(url, headers(key2));
  return client;
}
async function composioTools() {
  const c = mcp();
  if (!c) return [];
  if (!tools) {
    try {
      tools = (await c.listTools()).map((t) => ({ ...t, name: `composio__${t.name}` }));
    } catch (e) {
      const key2 = getSecret("composio");
      const s = await createSession(key2, settings().composio.userId);
      updateSettings((st) => {
        st.composio.sessionId = s.session_id;
        st.composio.mcpUrl = s.mcp.url;
      });
      client = new McpClient(s.mcp.url, headers(key2));
      tools = (await client.listTools()).map((t) => ({ ...t, name: `composio__${t.name}` }));
    }
  }
  return tools;
}
async function callComposio(name, args) {
  const c = mcp();
  if (!c) throw new Error("Composio is not connected. Add your project key in Settings \u2192 Connected apps.");
  const r = await c.callTool(name.replace(/^composio__/, ""), args);
  const m = r.text.match(/toolkit ([a-z0-9_]+)[^\n]{0,40}does not manage auth/i);
  if (m) r.text += `

[MausDroid: ${m[1]} needs the person's own ${m[1]} developer app. Tell them: Settings \u2192 Connected apps \u2192 ${m[1]} \u2192 "Set up sign-in", enter its keys there (never in chat), then connect again.]`;
  return r;
}
async function listToolkits(search = "", cursor) {
  const key2 = getSecret("composio");
  if (!key2) throw new Error("Add your Composio project key first.");
  const q = new URLSearchParams({ limit: "50" });
  if (search) q.set("search", search);
  if (cursor) q.set("cursor", cursor);
  const res = await fetch(`${API2}/toolkits?${q}`, { headers: headers(key2) });
  if (!res.ok) throw new Error(await responseError(res));
  const j = await res.json();
  return {
    items: (j.items ?? []).map((t) => ({ slug: t.slug, name: t.name, logo: t.meta?.logo, description: t.meta?.description, categories: (t.meta?.categories ?? []).map((c) => c.name ?? c) })),
    nextCursor: j.next_cursor ?? null
  };
}
async function listConnections() {
  const key2 = getSecret("composio");
  const userId = settings().composio.userId;
  if (!key2 || !userId) return [];
  const res = await fetch(`${API2}/connected_accounts?user_ids=${encodeURIComponent(userId)}&limit=100`, { headers: headers(key2) });
  if (!res.ok) throw new Error(await responseError(res));
  const j = await res.json();
  return (j.items ?? []).map((a) => ({ id: a.id, toolkit: a.toolkit?.slug, status: a.status, alias: a.alias ?? a.data?.alias ?? null, createdAt: a.created_at }));
}
async function linkToolkit(toolkit, alias) {
  const key2 = getSecret("composio");
  const st = settings().composio;
  if (!key2 || !st.sessionId) throw new Error("Add your Composio project key first.");
  const res = await fetch(`${API2}/tool_router/session/${encodeURIComponent(st.sessionId)}/link`, {
    method: "POST",
    headers: headers(key2, true),
    body: JSON.stringify({ toolkit, ...alias ? { alias } : {} })
  });
  if (!res.ok) throw new Error(explainAuthError(toolkit, await responseError(res)));
  const j = await res.json();
  const url = j.redirect_url ?? j.link ?? j.url;
  if (!url) throw new Error("Composio did not return a sign-in link.");
  return { url };
}
async function removeConnection(id2) {
  const key2 = getSecret("composio");
  if (!key2) throw new Error("Composio is not connected.");
  const res = await fetch(`${API2}/connected_accounts/${encodeURIComponent(id2)}?revoke_on_delete=true`, { method: "DELETE", headers: headers(key2) });
  if (!res.ok) throw new Error(await responseError(res));
  tools = null;
}
async function toolkitAuth(slug) {
  const key2 = getSecret("composio");
  if (!key2) throw new Error("Add your Composio project key first.");
  const res = await fetch(`${API2}/toolkits/${encodeURIComponent(slug)}`, { headers: headers(key2) });
  if (!res.ok) throw new Error(await responseError(res));
  const j = await res.json();
  const field = (f, required) => ({ name: f.name, label: f.displayName ?? f.name, description: f.description ?? "", secret: Boolean(f.is_secret), required, default: f.default ?? null });
  const schemes = (j.auth_config_details ?? []).map((d) => ({
    mode: d.mode,
    fields: [...(d.fields?.auth_config_creation?.required ?? []).map((f) => field(f, true)), ...(d.fields?.auth_config_creation?.optional ?? []).filter((f) => f.user_visible !== false).map((f) => field(f, false))]
  }));
  return {
    slug: j.slug ?? slug,
    name: j.name ?? slug,
    composioManaged: (j.composio_managed_auth_schemes ?? []).length > 0,
    schemes,
    yours: settings().composio.authConfigs?.[slug] ?? null
  };
}
async function setupCustomAuth(slug, mode, credentials) {
  const key2 = getSecret("composio");
  const st = settings().composio;
  if (!key2 || !st.userId) throw new Error("Add your Composio project key first.");
  const clean = Object.fromEntries(Object.entries(credentials ?? {}).map(([k, v]) => [k, String(v ?? "").trim()]).filter(([, v]) => v));
  const res = await fetch(`${API2}/auth_configs`, {
    method: "POST",
    headers: headers(key2, true),
    body: JSON.stringify({ toolkit: { slug }, auth_config: { type: "use_custom_auth", authScheme: mode, credentials: clean, name: `MausDroid ${slug}`, is_enabled_for_tool_router: true } }),
    signal: AbortSignal.timeout(3e4)
  });
  if (!res.ok) throw new Error(`Composio didn't accept these details: ${await responseError(res)}`);
  const j = await res.json();
  const id2 = j.auth_config?.id ?? j.id;
  if (!id2) throw new Error("Composio didn't return the new sign-in setup.");
  updateSettings((s) => {
    s.composio.authConfigs = { ...s.composio.authConfigs ?? {}, [slug]: id2 };
  });
  await renewSession();
  return { id: id2 };
}
async function removeCustomAuth(slug) {
  updateSettings((s) => {
    const m = { ...s.composio.authConfigs ?? {} };
    delete m[slug];
    s.composio.authConfigs = m;
  });
  await renewSession();
}
async function renewSession() {
  const key2 = getSecret("composio");
  const userId = settings().composio.userId;
  if (!key2 || !userId) return;
  const s = await createSession(key2, userId);
  updateSettings((st) => {
    st.composio.sessionId = s.session_id;
    st.composio.mcpUrl = s.mcp.url;
  });
  client = null;
  tools = null;
}
function explainAuthError(slug, message) {
  return /does not manage auth|auth_config_override|create an auth config/i.test(message) ? `${slug} needs your own developer app: Settings \u2192 Connected apps \u2192 ${slug} \u2192 "Set up sign-in" and enter its keys.` : message;
}
async function describeTool(slug) {
  const hit = toolInfo.get(slug);
  if (hit) return hit;
  const key2 = getSecret("composio");
  if (!key2) throw new Error("Composio is not connected.");
  const res = await fetch(`${API2}/tools/${encodeURIComponent(slug)}`, { headers: headers(key2) });
  if (!res.ok) throw new Error(`Composio tool ${slug}: ${await responseError(res)}`);
  const j = await res.json();
  const info = { version: j.version ?? j.toolkit?.version, params: Object.keys(j.input_parameters?.properties ?? j.inputParameters?.properties ?? {}) };
  toolInfo.set(slug, info);
  return info;
}
async function argsFor(slug, wanted) {
  const { params } = await describeTool(slug);
  const out = {};
  for (const { names, value } of Object.values(wanted)) {
    if (value === void 0 || value === null || value === "") continue;
    const name = names.find((n) => params.includes(n)) ?? (params.length ? void 0 : names[0]);
    if (name) out[name] = value;
  }
  return out;
}
async function executeTool(slug, args, connectedAccountId) {
  const key2 = getSecret("composio");
  const userId = settings().composio.userId;
  if (!key2 || !userId) throw new Error("Composio is not connected.");
  const info = await describeTool(slug).catch(() => ({ version: void 0 }));
  const res = await fetch(`${API2}/tools/execute/${encodeURIComponent(slug)}`, {
    method: "POST",
    headers: headers(key2, true),
    body: JSON.stringify({ user_id: userId, connected_account_id: connectedAccountId, arguments: args, ...info.version ? { version: info.version } : {} }),
    signal: AbortSignal.timeout(6e4)
  });
  if (!res.ok) throw new Error(await responseError(res));
  const j = await res.json();
  if (j.successful === false || j.error) throw new Error(typeof j.error === "string" ? j.error : JSON.stringify(j.error ?? "Composio reported a failure"));
  return j.data ?? j;
}
var import_node_crypto4, API2, client, tools, headers, toolInfo;
var init_composio = __esm({
  "src/composio.ts"() {
    "use strict";
    import_node_crypto4 = require("node:crypto");
    init_mcp();
    init_secrets();
    init_settings();
    API2 = process.env.MAUSDROID_COMPOSIO_API ?? "https://backend.composio.dev/api/v3";
    client = null;
    tools = null;
    headers = (key2, json2 = false) => ({
      "x-api-key": key2,
      ...json2 ? { "content-type": "application/json" } : {}
    });
    toolInfo = /* @__PURE__ */ new Map();
  }
});

// src/calendar.ts
function findArray(data, keys) {
  if (!data || typeof data !== "object") return [];
  for (const k of keys) if (Array.isArray(data[k])) return data[k];
  for (const v of Object.values(data)) {
    if (v && typeof v === "object") {
      const hit = findArray(v, keys);
      if (hit.length) return hit;
    }
  }
  return [];
}
async function discoverCalendars() {
  const accounts = (await listConnections()).filter((a) => a.toolkit === "googlecalendar" && a.status === "ACTIVE");
  const out = { calendars: [], problems: [], checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
  if (!accounts.length) out.problems.push({ accountId: "", accountAlias: "", error: "No Google Calendar account is connected. Connect one in Settings \u2192 Connected apps \u2192 Google Calendar." });
  for (const a of accounts) {
    const alias = a.alias ?? a.id;
    try {
      const data = await executeTool(SLUGS.list, {}, a.id);
      for (const c of findArray(data, ["items", "calendars"])) {
        const role = String(c.accessRole ?? c.access_role ?? "reader");
        out.calendars.push({ accountId: a.id, accountAlias: alias, calendarId: String(c.id), name: String(c.summaryOverride ?? c.summary ?? c.id), accessRole: role, writable: role === "owner" || role === "writer", primary: Boolean(c.primary) });
      }
    } catch (e) {
      out.problems.push({ accountId: a.id, accountAlias: alias, error: explain(e.message) });
    }
  }
  store.update((s) => s.last = out);
  return out;
}
function explain(msg) {
  if (/401|unauthor|invalid_grant|expired/i.test(msg)) return `The sign-in for this account has expired. Reconnect it in Connected apps. (${msg.slice(0, 120)})`;
  if (/403|forbidden|insufficient|permission/i.test(msg)) return `This account doesn't allow it (no permission). If it's a shared calendar, ask its owner for "Make changes to events". (${msg.slice(0, 120)})`;
  if (/404|not found/i.test(msg)) return `Calendar not found from this account. (${msg.slice(0, 120)})`;
  return msg.slice(0, 300);
}
function setDestination(d) {
  store.update((s) => s.destination = d ? { ...d } : null);
  emit("settings.changed");
}
async function resolveTarget(target) {
  const dest = getDestination();
  if (target?.calendarId && target.accountId) return { accountId: target.accountId, calendarId: target.calendarId };
  const known = lastDiscovery()?.calendars ?? (await discoverCalendars()).calendars;
  if (target?.name || target?.calendarId) {
    const want = (target.name ?? target.calendarId ?? "").toLowerCase();
    const hit = known.find((c) => c.calendarId.toLowerCase() === want || c.name.toLowerCase() === want) ?? known.find((c) => c.name.toLowerCase().includes(want));
    if (!hit) throw new Error(`No calendar called "${target.name ?? target.calendarId}". Use calendar_list to see them.`);
    return { accountId: hit.accountId, calendarId: hit.calendarId };
  }
  if (!dest) throw new Error("No destination calendar chosen. Pick one in Settings \u2192 Connected apps \u2192 Calendars (MausDroid never guesses the default calendar).");
  return { accountId: dest.accountId, calendarId: dest.calendarId };
}
function writableCheck(accountId, calendarId) {
  const c = lastDiscovery()?.calendars.find((x) => x.accountId === accountId && x.calendarId === calendarId);
  if (c && !c.writable) throw new Error(`"${c.name}" is read-only for ${c.accountAlias} (access: ${c.accessRole}). Ask the owner for "Make changes to events", or choose another calendar.`);
  return c;
}
async function eventsAround(accountId, calendarId, ev) {
  const r = toUtcRange(ev.start, ev.durationMinutes ?? 60);
  const args = await argsFor(SLUGS.events, {
    cal: { names: ["calendarId", "calendar_id"], value: calendarId },
    min: { names: ["timeMin", "time_min"], value: r.min },
    max: { names: ["timeMax", "time_max"], value: r.max },
    q: { names: ["q", "query"], value: ev.summary },
    single: { names: ["singleEvents", "single_events"], value: true }
  });
  const data = await executeTool(SLUGS.events, args, accountId);
  return { items: findArray(data, ["items", "events"]), startMs: r.startMs };
}
async function createEvent(ev, target) {
  if (!ev.summary?.trim() || !ev.start) throw new Error("An event needs a title and a start time.");
  const { accountId, calendarId } = await resolveTarget(target);
  const info = writableCheck(accountId, calendarId);
  const label = info ? `${info.name} (${info.accountAlias})` : calendarId;
  const before = await eventsAround(accountId, calendarId, ev).catch(() => null);
  const dup = before?.items.find((it) => sameEvent(it, ev, before.startMs));
  if (dup) return { status: "duplicate", verified: true, calendar: label, eventId: dup.id, link: dup.htmlLink, detail: `"${ev.summary}" already exists at that time in ${label}; nothing added.` };
  const minutes2 = ev.durationMinutes ?? 60;
  const args = await argsFor(SLUGS.create, {
    cal: { names: ["calendar_id", "calendarId"], value: calendarId },
    summary: { names: ["summary", "title"], value: ev.summary },
    start: { names: ["start_datetime", "start_time", "startDateTime"], value: ev.start },
    hours: { names: ["event_duration_hour"], value: Math.floor(minutes2 / 60) },
    mins: { names: ["event_duration_minutes"], value: minutes2 % 60 },
    tz: { names: ["timezone", "time_zone", "timeZone"], value: ev.timeZone },
    desc: { names: ["description"], value: ev.description },
    loc: { names: ["location"], value: ev.location }
  });
  let created;
  try {
    created = await executeTool(SLUGS.create, args, accountId);
  } catch (e) {
    return { status: "failed", verified: false, calendar: label, detail: `Couldn't add it to ${label}: ${explain(e.message)}` };
  }
  const eventId = created?.id ?? created?.response_data?.id ?? findArray({ x: [created] }, ["x"])[0]?.id;
  const after = await eventsAround(accountId, calendarId, ev).catch(() => null);
  const found = after?.items.find((it) => eventId && it.id === eventId || sameEvent(it, ev, after.startMs));
  return found ? { status: "created", verified: true, calendar: label, eventId: found.id, link: found.htmlLink, detail: `Added "${ev.summary}" to ${label} and confirmed it's there.` } : { status: "created", verified: false, calendar: label, eventId, detail: `Google accepted "${ev.summary}" for ${label}, but it didn't show up when checked. Please look in the calendar.` };
}
async function testWrite(target) {
  const { accountId, calendarId } = await resolveTarget(target);
  const start = new Date(Date.now() + 400 * 864e5);
  start.setUTCHours(3, 0, 0, 0);
  const ev = { summary: `MausDroid write test ${start.getTime().toString(36)}`, start: start.toISOString(), durationMinutes: 15, description: "Automatic permission check; deleted straight away." };
  let ok = false;
  let detail;
  try {
    writableCheck(accountId, calendarId);
    const r = await createEvent(ev, { accountId, calendarId });
    ok = r.status === "created" && r.verified;
    detail = ok ? "Can add events here (test event created, found and removed)." : r.detail;
    if (r.eventId) {
      const del = await argsFor(SLUGS.remove, { cal: { names: ["calendar_id", "calendarId"], value: calendarId }, id: { names: ["event_id", "eventId"], value: r.eventId } });
      await executeTool(SLUGS.remove, del, accountId).catch((e) => detail += ` (Couldn't remove the test event: ${e.message})`);
    }
  } catch (e) {
    detail = explain(e.message);
  }
  const result = { ok, at: (/* @__PURE__ */ new Date()).toISOString(), detail };
  store.update((s) => {
    if (s.destination && s.destination.accountId === accountId && s.destination.calendarId === calendarId) s.destination.writeTest = result;
  });
  return result;
}
async function busyBetween(from, to) {
  const found = lastDiscovery() ?? await discoverCalendars();
  if (!found.calendars.length) throw new Error(found.problems[0]?.error ?? "No Google Calendar is connected");
  let readable = 0;
  for (const c of found.calendars.filter((x) => x.accessRole !== "freeBusyReader").slice(0, 10)) {
    try {
      const args = await argsFor(SLUGS.events, {
        cal: { names: ["calendarId", "calendar_id"], value: c.calendarId },
        min: { names: ["timeMin", "time_min"], value: from.toISOString() },
        max: { names: ["timeMax", "time_max"], value: to.toISOString() },
        single: { names: ["singleEvents", "single_events"], value: true }
      });
      const items = findArray(await executeTool(SLUGS.events, args, c.accountId), ["items", "events"]);
      readable++;
      for (const ev of items) {
        const st = ev.start?.dateTime;
        const en = ev.end?.dateTime;
        if (!st) continue;
        if (ev.transparency === "transparent" || ev.status === "cancelled") continue;
        if (new Date(st) < to && (!en || new Date(en) > from)) return { busy: true, event: String(ev.summary ?? "an event") };
      }
    } catch {
    }
  }
  if (!readable) throw new Error("none of your calendars could be read");
  return { busy: false };
}
var SLUGS, store, getDestination, lastDiscovery, toUtcRange, sameEvent;
var init_calendar = __esm({
  "src/calendar.ts"() {
    "use strict";
    init_composio();
    init_store();
    init_events();
    SLUGS = {
      list: "GOOGLECALENDAR_LIST_CALENDARS",
      events: "GOOGLECALENDAR_EVENTS_LIST",
      create: "GOOGLECALENDAR_CREATE_EVENT",
      remove: "GOOGLECALENDAR_DELETE_EVENT"
    };
    store = collection("calendar", { destination: null, last: null });
    getDestination = () => store.get().destination;
    lastDiscovery = () => store.get().last;
    toUtcRange = (start, minutes2) => {
      const s = new Date(start);
      return { min: new Date(s.getTime() - 6e4).toISOString(), max: new Date(s.getTime() + Math.max(1, minutes2) * 6e4 + 6e4).toISOString(), startMs: s.getTime() };
    };
    sameEvent = (item, ev, startMs) => {
      const st = item.start?.dateTime ?? item.start?.date ?? item.start_datetime;
      return String(item.summary ?? "").trim().toLowerCase() === ev.summary.trim().toLowerCase() && st && Math.abs(new Date(st).getTime() - startMs) < 6e4;
    };
  }
});

// src/brief-logic.ts
function dayStatus(date, t) {
  const key2 = ymd(date);
  const within = (a, b) => key2 >= a && key2 <= b;
  const events = t.days.filter((d) => d.kind === "event" && within(d.start, d.end)).map((d) => d.name);
  const base = { date: key2, events };
  if (!t.terms.length) return { ...base, schoolDay: date.getDay() >= 1 && date.getDay() <= 5, reason: "No term dates set up yet, so weekdays are assumed to be school days.", unconfirmed: true };
  const term = t.terms.find((x) => within(x.start, x.end));
  const special = t.days.find((d) => d.kind !== "event" && within(d.start, d.end));
  if (date.getDay() === 0 || date.getDay() === 6) return { ...base, schoolDay: false, term: term?.name, reason: "Weekend.", unconfirmed: false };
  if (!term) {
    const next2 = t.terms.filter((x) => x.start > key2).sort((a, b) => a.start.localeCompare(b.start))[0];
    return { ...base, schoolDay: false, reason: `School holidays${next2 ? ` (${next2.name} starts ${next2.start})` : ""}.`, unconfirmed: t.terms.some((x) => !x.confirmed) };
  }
  const week = Math.floor((parse(key2).getTime() - parse(term.start).getTime()) / (7 * 864e5)) + 1;
  if (special) return { ...base, schoolDay: false, term: term.name, week, reason: `${special.name} (${special.kind.replace("-", " ")}).`, unconfirmed: !special.confirmed || !term.confirmed };
  return { ...base, schoolDay: true, term: term.name, week, reason: `${term.name}, week ${week}.`, unconfirmed: !term.confirmed };
}
function weekOf(text) {
  const m = text.match(WEEK);
  return m ? { term: m[1] ? Number(m[1]) : void 0, week: Number(m[2]) } : null;
}
function rankStaffUpdates(files2, now2, current) {
  const warnings = [];
  const scored = files2.filter((f) => !/folder|shortcut/.test(f.mimeType)).map((f) => {
    let score = 0;
    if (TITLE.test(f.name)) score += 5;
    else if (f.contentMatch) score += 2;
    const ageDays = (now2.getTime() - new Date(f.modifiedTime).getTime()) / 864e5;
    score += ageDays <= 7 ? 3 : ageDays <= 14 ? 1 : -2;
    const w = weekOf(f.name);
    if (w && current?.week) score += w.week === current.week && (!w.term || !current.term || w.term === current.term) ? 3 : -3;
    if (/document|pdf|wordprocessing|msword|text\//.test(f.mimeType)) score += 1;
    if (/spreadsheet|presentation|image|video/.test(f.mimeType)) score -= 1;
    if (/copy of|draft|template|old\b/i.test(f.name)) score -= 3;
    return { ...f, score, ageDays };
  }).sort((a, b) => b.score - a.score || new Date(b.modifiedTime).getTime() - new Date(a.modifiedTime).getTime());
  const valid = scored.filter((f) => f.score >= 4 && f.ageDays <= 10);
  const best = valid[0] ?? null;
  if (!best) warnings.push(scored.length ? `No current Staff Update found (closest: "${scored[0].name}", modified ${scored[0].modifiedTime.slice(0, 10)}).` : "No Staff Update found in Google Drive.");
  const close = valid.filter((f) => f !== best && best && best.score - f.score <= 1);
  if (best && close.length) warnings.push(`Several possible Staff Updates; using "${best.name}" (also: ${close.map((c) => `"${c.name}"`).join(", ")}).`);
  const strip = ({ ageDays, ...f }) => f;
  return { best: best ? strip(best) : null, alternatives: scored.filter((f) => f !== best).slice(0, 4).map(strip), warnings };
}
function normaliseSheetName(name) {
  let n = name.replace(/ /g, " ").replace(/\s+/g, " ").trim();
  while (/^copy of /i.test(n)) n = n.replace(/^copy of /i, "");
  return n.replace(/\s*\(\d+\)$/, "").toLowerCase();
}
function pickSportSheet(names, week, term) {
  const warnings = [];
  const candidates = names.map((name, index) => ({ name, index, norm: normaliseSheetName(name), w: weekOf(normaliseSheetName(name)), copy: /^\s*copy of/i.test(name) })).filter((c) => c.w && c.w.week === week && (!c.w.term || !term || c.w.term === term));
  if (!candidates.length) {
    const weeks = names.map((n) => weekOf(normaliseSheetName(n))?.week).filter((x) => Boolean(x));
    const latest = weeks.length ? Math.max(...weeks) : null;
    warnings.push(`Week ${week} sport sheet isn't published yet${latest ? ` (latest tab is week ${latest})` : ""}. Not using an older week.`);
    return { sheet: null, week, warnings, duplicates: [] };
  }
  candidates.sort((a, b) => Number(a.copy) - Number(b.copy) || a.index - b.index);
  const chosen = candidates[0];
  const duplicates = candidates.slice(1).map((c) => c.name);
  if (duplicates.length) warnings.push(`Duplicate week ${week} tabs found (${[chosen.name, ...duplicates].map((n) => `"${n.trim()}"`).join(", ")}); using "${chosen.name.trim()}".`);
  return { sheet: chosen.name, week, warnings, duplicates };
}
function extractThursday(values, identifiers) {
  const warnings = [];
  const clean = values.map((r) => r.map((c) => String(c ?? "").trim()));
  const headerIdx = clean.findIndex((r) => r.some((c) => /thu(rs(day)?)?\b/i.test(c)));
  const header = headerIdx >= 0 ? clean[headerIdx] : clean[0] ?? [];
  const thuCol = header.findIndex((c) => /thu(rs(day)?)?\b/i.test(c));
  const ids = identifiers.map((s) => s.trim().toLowerCase()).filter(Boolean);
  let rows = clean.slice(headerIdx >= 0 ? headerIdx + 1 : 1).filter((r) => r.some(Boolean));
  if (ids.length) {
    const mine = rows.filter((r) => r.some((c) => ids.some((id2) => c.toLowerCase().includes(id2))));
    if (!mine.length) warnings.push(`Your name/code (${identifiers.join(", ")}) isn't on this week's sport sheet.`);
    rows = mine;
  } else {
    warnings.push("Add your name or staff code in Morning Brief settings to pick out your sport allocation.");
    rows = rows.slice(0, 40);
  }
  if (thuCol >= 0) rows = rows.map((r) => [r[0], r[thuCol]].filter((x) => x !== void 0));
  return { header: thuCol >= 0 ? [header[0], header[thuCol]] : header, rows, column: thuCol >= 0 ? header[thuCol] : void 0, warnings };
}
var ymd, parse, TITLE, WEEK;
var init_brief_logic = __esm({
  "src/brief-logic.ts"() {
    "use strict";
    ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    parse = (s) => {
      const [y, m, d] = s.split("-").map(Number);
      return new Date(y, m - 1, d);
    };
    TITLE = /staff\s*(update|bulletin|news(letter)?|notices?)|weekly\s*(staff\s*)?update/i;
    WEEK = /(?:\bt(?:erm)?\s*(\d)\s*)?(?:\b|(?<=\d))w(?:ee)?k?\s*0?(\d{1,2})\b/i;
  }
});

// src/brief.ts
function saveBriefSettings(b) {
  store2.update((s) => {
    if (b.prefs) s.prefs = { ...s.prefs, ...b.prefs };
    if (b.terms) s.terms = b.terms;
  });
  emit("settings.changed");
  return briefSettings();
}
async function accountsFor(toolkit) {
  return (await listConnections()).filter((a) => a.toolkit === toolkit && a.status === "ACTIVE");
}
async function searchStaffUpdates(terms, since2) {
  const warnings = [];
  const files2 = [];
  const accounts = await accountsFor("googledrive");
  if (!accounts.length) return { files: files2, warnings: ["Google Drive isn't connected, so the Staff Update couldn't be found."] };
  const esc = (t) => t.replace(/'/g, "\\'");
  const byName = terms.map((t) => `name contains '${esc(t)}'`).join(" or ");
  const byText = terms.map((t) => `fullText contains '${esc(t)}'`).join(" or ");
  for (const a of accounts) {
    for (const [q, content] of [[`(${byName}) and modifiedTime > '${since2.toISOString()}' and trashed = false`, false], [`(${byText}) and modifiedTime > '${since2.toISOString()}' and trashed = false`, true]]) {
      try {
        const args = await argsFor("GOOGLEDRIVE_FIND_FILE", { q: { names: ["q", "query"], value: q }, size: { names: ["pageSize", "page_size"], value: 25 }, order: { names: ["orderBy", "order_by"], value: "modifiedTime desc" } });
        const data = await executeTool("GOOGLEDRIVE_FIND_FILE", args, a.id);
        for (const f of findArray2(data, ["files", "items"])) {
          if (files2.some((x) => x.id === f.id)) continue;
          files2.push({ id: f.id, name: f.name ?? f.title, mimeType: f.mimeType ?? "", modifiedTime: f.modifiedTime ?? f.modified_time ?? (/* @__PURE__ */ new Date(0)).toISOString(), webViewLink: f.webViewLink ?? `https://drive.google.com/file/d/${f.id}/view`, contentMatch: content, account: a.alias });
        }
      } catch (e) {
        warnings.push(`Drive search (${a.alias ?? a.id}) failed: ${e.message.slice(0, 160)}`);
      }
    }
  }
  return { files: files2, warnings };
}
async function readSport(prefs, week, term) {
  const id2 = sheetId(prefs.sportSheet);
  if (!id2) return { sport: null, warnings: ["No sport matrix spreadsheet set (Morning Brief settings)."], source: void 0 };
  if (!week) return { sport: null, warnings: ["The school week isn't known (add term dates), so the sport sheet can't be chosen."], source: void 0 };
  const accounts = await accountsFor("googlesheets");
  if (!accounts.length) return { sport: null, warnings: ["Google Sheets isn't connected."], source: void 0 };
  const warnings = [];
  for (const a of accounts) {
    try {
      const info = await executeTool("GOOGLESHEETS_GET_SPREADSHEET_INFO", await argsFor("GOOGLESHEETS_GET_SPREADSHEET_INFO", { id: { names: ["spreadsheet_id", "spreadsheetId"], value: id2 } }), a.id);
      const names = findArray2(info, ["sheets"]).map((s) => String(s.properties?.title ?? s.title ?? ""));
      const pick = pickSportSheet(names, week, term);
      warnings.push(...pick.warnings);
      const source = `https://docs.google.com/spreadsheets/d/${id2}`;
      if (!pick.sheet) return { sport: { sheet: null, header: [], rows: [], source }, warnings, source };
      const range = `'${pick.sheet.replace(/'/g, "''")}'!A1:Z300`;
      const vals = await executeTool("GOOGLESHEETS_BATCH_GET", await argsFor("GOOGLESHEETS_BATCH_GET", { id: { names: ["spreadsheet_id", "spreadsheetId"], value: id2 }, ranges: { names: ["ranges"], value: [range] } }), a.id);
      const values = findArray2(vals, ["values"]).length && Array.isArray(findArray2(vals, ["values"])[0]) ? findArray2(vals, ["values"]) : findArray2(findArray2(vals, ["valueRanges", "value_ranges"])[0] ?? {}, ["values"]);
      const t = extractThursday(values, prefs.identifiers);
      warnings.push(...t.warnings);
      return { sport: { sheet: pick.sheet.trim(), header: t.header, rows: t.rows, source: `${source} \xB7 tab "${pick.sheet.trim()}"` }, warnings, source };
    } catch (e) {
      warnings.push(`Sport sheet (${a.alias ?? a.id}): ${e.message.slice(0, 160)}`);
    }
  }
  return { sport: null, warnings, source: void 0 };
}
async function todaysEvents(prefs, date) {
  const warnings = [];
  const out = [];
  let found;
  try {
    found = lastDiscovery() ?? await discoverCalendars();
  } catch (e) {
    return { events: out, warnings: [`Calendar couldn't be read: ${e.message}`] };
  }
  for (const p of found.problems) warnings.push(`Calendar: ${p.accountAlias ? `${p.accountAlias}: ` : ""}${p.error}`);
  const wanted = prefs.briefCalendars.length ? found.calendars.filter((c) => prefs.briefCalendars.some((w) => w.accountId === c.accountId && w.calendarId === c.calendarId)) : found.calendars.filter((c) => c.accessRole !== "freeBusyReader").slice(0, 8);
  const start = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const end = new Date(start.getTime() + 864e5);
  for (const c of wanted) {
    try {
      const args = await argsFor(SLUGS.events, { cal: { names: ["calendarId", "calendar_id"], value: c.calendarId }, min: { names: ["timeMin", "time_min"], value: start.toISOString() }, max: { names: ["timeMax", "time_max"], value: end.toISOString() }, single: { names: ["singleEvents", "single_events"], value: true }, order: { names: ["orderBy", "order_by"], value: "startTime" } });
      for (const ev of findArray2(await executeTool(SLUGS.events, args, c.accountId), ["items", "events"])) {
        const st = ev.start?.dateTime ?? ev.start?.date ?? "";
        out.push({ time: st.length > 10 ? new Date(st).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) : "All day", title: ev.summary ?? "(no title)", calendar: `${c.name} (${c.accountAlias})`, link: ev.htmlLink });
      }
    } catch (e) {
      warnings.push(`Calendar "${c.name}" couldn't be read: ${e.message.slice(0, 120)}`);
    }
  }
  out.sort((a, b) => a.time === "All day" ? -1 : b.time === "All day" ? 1 : 0);
  return { events: out, warnings };
}
async function prepareBrief(dateStr) {
  const date = dateStr ? /* @__PURE__ */ new Date(`${dateStr}T08:00:00`) : /* @__PURE__ */ new Date();
  const { prefs, terms } = briefSettings();
  const day = dayStatus(date, terms);
  const warnings = [];
  if (day.unconfirmed) warnings.push("Term dates aren't confirmed, so school-day/week details may be wrong (Morning Brief settings).");
  const termNo = Number(day.term?.match(/\d+/)?.[0]) || void 0;
  const [cal, staff, sport] = await Promise.all([
    todaysEvents(prefs, date),
    searchStaffUpdates(prefs.staffUpdateTerms.length ? prefs.staffUpdateTerms : ["Staff Update"], new Date(date.getTime() - 21 * 864e5)),
    readSport(prefs, day.week, termNo)
  ]);
  const pick = rankStaffUpdates(staff.files, date, { term: termNo, week: day.week });
  warnings.push(...cal.warnings, ...staff.warnings, ...pick.warnings, ...sport.warnings);
  const dest = getDestination();
  const calendarStatus = dest ? `Events go to ${dest.name} (${dest.accountAlias})${dest.writeTest ? dest.writeTest.ok ? " \u2014 write tested \u2713" : " \u2014 write test failed" : " \u2014 not write-tested yet"}` : "No destination calendar chosen; events can only be proposed.";
  const cutoff = Date.now() - 24 * 36e5;
  const notices = listAlerts().filter((a) => new Date(a.at).getTime() > cutoff && a.type !== "approval" && a.type !== "routine-result").slice(0, 10).map((a) => `${a.title}: ${a.body}`.slice(0, 200));
  const sources = [];
  if (pick.best) sources.push({ label: `Staff Update: ${pick.best.name}`, url: pick.best.webViewLink });
  if (sport.source) sources.push({ label: "Sport matrix", url: sport.source.split(" \xB7 ")[0] });
  const out = {
    date: day.date,
    day,
    prefs: { ...prefs, assumed: Object.keys(DEFAULT_PREFS).filter((k) => k !== "confirmed" && !prefs.confirmed.includes(k)) },
    schedule: cal.events,
    staffUpdate: pick.best ? { name: pick.best.name, link: pick.best.webViewLink, modified: pick.best.modifiedTime, id: pick.best.id, account: pick.best.account } : null,
    staffUpdateAlternatives: pick.alternatives.map((f) => ({ name: f.name, link: f.webViewLink, modified: f.modifiedTime })),
    sport: sport.sport,
    notices,
    warnings,
    sources,
    calendarStatus
  };
  drafts.set(out.date, out);
  return out;
}
async function publishBrief(input, botId) {
  const date = input.date ?? (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const d = drafts.get(date) ?? await prepareBrief(date);
  const prefs = briefSettings().prefs;
  const b = {
    id: id("brief"),
    date: d.date,
    createdAt: now(),
    day: d.day,
    summary: input.summary,
    schedule: d.schedule,
    staffUpdate: d.staffUpdate ? { name: d.staffUpdate.name, link: d.staffUpdate.link, modified: d.staffUpdate.modified, summary: input.staff_update_summary } : null,
    sport: d.sport,
    notices: [...input.notices ?? [], ...d.notices].slice(0, 15),
    warnings: [...d.warnings, ...input.extra_warnings ?? []],
    sources: d.sources,
    calendarStatus: d.calendarStatus,
    proposedEvents: prefs.eventCreation === "never" ? [] : (input.proposed_events ?? []).map((e) => ({ id: id("pe"), summary: e.summary, start: e.start, durationMinutes: e.duration_minutes, reason: e.reason, status: "proposed" }))
  };
  store2.update((s) => {
    s.briefings.push(b);
    if (s.briefings.length > 120) s.briefings.splice(0, s.briefings.length - 120);
  });
  emit("briefing", { id: b.id });
  await notifyUser({
    title: "Morning Brief ready",
    body: `${b.day.reason}${b.warnings.length ? ` ${b.warnings.length} thing(s) to check.` : ""} Tap to open.`,
    botId,
    type: "briefing",
    source: "Morning Brief",
    link: `briefing:${b.id}`
  });
  return b;
}
async function decideEvent(bid, eid, approve2) {
  const b = getBriefing(bid);
  const e = b?.proposedEvents.find((x) => x.id === eid);
  if (!b || !e) throw new Error("No such proposal");
  if (e.status !== "proposed" && e.status !== "failed") return e;
  let patch3;
  if (!approve2) patch3 = { status: "dismissed" };
  else {
    const r = await createEvent({ summary: e.summary, start: e.start, durationMinutes: e.durationMinutes });
    patch3 = { status: r.status === "created" ? "added" : r.status, detail: r.detail };
  }
  store2.update((s) => Object.assign(s.briefings.find((x) => x.id === bid).proposedEvents.find((x) => x.id === eid), patch3));
  emit("briefing", { id: bid });
  return { ...e, ...patch3 };
}
var DEFAULT_PREFS, store2, briefSettings, listBriefings, getBriefing, sheetId, findArray2, drafts, MORNING_BRIEF_PROMPT;
var init_brief = __esm({
  "src/brief.ts"() {
    "use strict";
    init_composio();
    init_store();
    init_events();
    init_util();
    init_brief_logic();
    init_calendar();
    init_notify();
    DEFAULT_PREFS = {
      staffUpdateTerms: ["Staff Update"],
      sportSheet: "",
      identifiers: [],
      briefCalendars: [],
      missingInfo: "warn",
      eventCreation: "propose",
      content: "Short: today's schedule, key Staff Update items, my Thursday sport, anything needing action.",
      holidays: "short",
      confirmed: []
    };
    store2 = collection("brief", { prefs: DEFAULT_PREFS, terms: { terms: [], days: [] }, briefings: [] });
    store2.update((s) => s.prefs = { ...DEFAULT_PREFS, ...s.prefs });
    briefSettings = () => ({ prefs: store2.get().prefs, terms: store2.get().terms });
    listBriefings = () => store2.get().briefings.slice().reverse().map(({ id: id2, date, createdAt, summary, warnings }) => ({ id: id2, date, createdAt, summary: summary.slice(0, 160), warnings: warnings.length }));
    getBriefing = (bid) => store2.get().briefings.find((b) => b.id === bid);
    sheetId = (s) => s.match(/\/d\/([A-Za-z0-9_-]{20,})/)?.[1] ?? (s.trim().match(/^[A-Za-z0-9_-]{20,}$/) ? s.trim() : "");
    findArray2 = (data, keys) => {
      if (!data || typeof data !== "object") return [];
      for (const k of keys) if (Array.isArray(data[k])) return data[k];
      for (const v of Object.values(data)) if (v && typeof v === "object") {
        const hit = findArray2(v, keys);
        if (hit.length) return hit;
      }
      return [];
    };
    drafts = /* @__PURE__ */ new Map();
    MORNING_BRIEF_PROMPT = `Prepare today's Morning Brief.
1. Call morning_brief_prepare.
2. If it's not a school day, follow the holiday preference (short brief or skip).
3. If a Staff Update was found, read it (Google Docs/Drive through connected apps, or web_fetch its link) and pick out what matters for me today and this week. Don't use an older Staff Update if this week's is missing \u2014 say it's missing.
4. Use only the sport rows returned (never last week's). If the sport sheet is missing, say so.
5. Write the brief following my content preference, in plain words.
6. For dated items that should be in my calendar, propose events (don't create them).
7. Call morning_brief_publish with the summary, a short Staff Update summary, notices and proposed events. Mention every warning honestly.`;
  }
});

// src/audit.ts
function canonicalUrl(u) {
  try {
    const x = new URL(u.trim());
    let p = x.pathname.replace(/\/+$/, "").replace(/\.git$/, "");
    if (x.hostname.replace(/^www\./, "") === "github.com") p = p.split("/").slice(0, 3).join("/");
    return `${x.hostname.replace(/^www\./, "").toLowerCase()}${p.toLowerCase()}`;
  } catch {
    return u.trim().toLowerCase();
  }
}
function similar(a, b) {
  const A = tokens(a);
  const B = tokens(b);
  if (!A.size || !B.size) return false;
  const inter = [...A].filter((t) => B.has(t)).length;
  return inter / (/* @__PURE__ */ new Set([...A, ...B])).size >= 0.75;
}
function scoreCandidate(c) {
  const reasons = [];
  const crit = { utility: c.utility, adoption: c.adoption, scope_fit: c.scope_fit, setup: c.setup, privacy: c.privacy };
  for (const [k, v] of Object.entries(crit)) if (!Number.isInteger(v) || v < 1 || v > 5) reasons.push(`${k} must be a whole number 1\u20135`);
  const total = Object.values(crit).reduce((a, v) => a + (Number(v) || 0), 0);
  const flags2 = new Set(Object.entries(c.safety ?? {}).filter(([, v]) => v).map(([k]) => k));
  const text = `${c.name}. ${c.summary}. ${Object.values(c.alignment ?? {}).join(". ")}`;
  for (const [flag, re] of SAFETY_WORDS) if (re.test(text)) flags2.add(flag);
  for (const f of flags2) reasons.push(`Safety: ${SAFETY_FLAGS[f]}`);
  if (c.action_type === "unsupported") reasons.push("Unsupported or prohibited action");
  if (!PHASES.includes(c.phase)) reasons.push("phase must be phase-1-ready, phase-2-queued or phase-3-queued");
  if (!/^https?:\/\//.test(c.source_url ?? "")) reasons.push("needs a source URL");
  if (c.account_alias && !/^personal/i.test(c.account_alias)) reasons.push("research must use personal account aliases only");
  return { ...c, slug: slugify(c.name), total, accepted: reasons.length === 0, reasons };
}
function dedupe(list, wiki) {
  const kept = [];
  const duplicates = [];
  const seen = wiki.map((w) => ({ slug: w.slug, url: canonicalUrl(w.source_url), name: w.name }));
  for (const c of list) {
    const url = canonicalUrl(c.source_url);
    const hit = seen.find((s) => s.slug === c.slug || url && s.url === url || similar(s.name, c.name));
    if (hit) duplicates.push({ name: c.name, of: hit.slug });
    else {
      kept.push(c);
      seen.push({ slug: c.slug, url, name: c.name });
    }
  }
  return { kept, duplicates };
}
function gh(path13, init = {}) {
  const token = getSecret("github");
  if (!token) throw new Error("No GitHub token saved (Settings \u2192 Memory \u2192 GitHub token) with access to the private wiki repo.");
  return fetch(`${GH}${path13}`, { ...init, headers: { authorization: `Bearer ${token}`, accept: "application/vnd.github+json", "user-agent": "MausDroid-audit", "content-type": "application/json", ...init.headers ?? {} }, signal: AbortSignal.timeout(3e4) });
}
async function checkWiki() {
  try {
    const r = await gh(`/repos/${WIKI_REPO}`);
    if (r.status === 404) return { ok: false, detail: `Wiki repo ${WIKI_REPO} not found (or the token can't see it). Create it as a PRIVATE repo and give the token access.` };
    if (!r.ok) return { ok: false, detail: `GitHub said HTTP ${r.status}.` };
    const j = await r.json();
    if (!j.private) return { ok: false, detail: `${WIKI_REPO} is PUBLIC. MausDroid only writes to a private wiki; nothing was filed.` };
    return { ok: true, detail: `${WIKI_REPO} (private)` };
  } catch (e) {
    return { ok: false, detail: e.message };
  }
}
async function wikiEntries() {
  const r = await gh(`/repos/${WIKI_REPO}/contents/entries`);
  if (r.status === 404) return [];
  if (!r.ok) throw new Error(`Couldn't list the wiki (HTTP ${r.status}).`);
  const files2 = (await r.json()).filter((f) => f.name.endsWith(".md"));
  const out = [];
  for (const f of files2.slice(0, 400)) {
    const one = await gh(`/repos/${WIKI_REPO}/contents/entries/${encodeURIComponent(f.name)}`);
    if (!one.ok) continue;
    const text = unb64((await one.json()).content ?? "");
    const fm = Object.fromEntries((text.match(/^---\n([\s\S]*?)\n---/)?.[1] ?? "").split("\n").map((l) => l.match(/^(\w+):\s*(.*)$/)).filter(Boolean).map((m) => [m[1], m[2].trim()]));
    out.push({ slug: fm.slug ?? f.name.replace(/\.md$/, ""), name: fm.name ?? "", source_url: fm.source_url ?? "", status: fm.status });
  }
  return out;
}
function entryMarkdown(c, date) {
  const a = c.alignment ?? {};
  const prims = c.primitives.length ? c.primitives.map((p) => `  - ${p}`).join("\n") : "  - none";
  return `---
slug: ${c.slug}
name: ${c.name.replace(/\n/g, " ")}
source_ecosystem: ${c.source_ecosystem}
source_url: ${c.source_url}
discovered_date: ${date}
score: ${c.total}
mausdroid_phase: ${c.phase}
status: backlog
primitives:
${prims}
account_alias: ${c.account_alias ?? "personal"}
safety_check: pass
---

## Summary
${c.summary}

## MausDroid alignment
- **What it does:** ${a.what ?? c.summary}
- **Why it's useful:** ${a.why ?? "\u2014"}
- **Required integrations:** ${a.integrations ?? (c.composio?.join(", ") || "none")}
- **Existing MausDroid primitives:** ${c.primitives.join(", ") || "\u2014"}
- **Implementation requirements:** ${a.implementation ?? "\u2014"}
- **Phase 1 workaround:** ${a.workaround ?? "\u2014"}
- **Upgrade path:** ${a.upgrade_path ?? "\u2014"}
- **Privacy considerations:** ${a.privacy ?? "\u2014"}
- **Action type:** ${c.action_type ?? "user-approved"}
`;
}
function looksSecret(text) {
  return /\b(sk-[a-z0-9-]{16,}|ghp_[A-Za-z0-9]{20,}|github_pat_\w{20,}|ak_[A-Za-z0-9]{16,}|xox[bp]-\w+|AKIA[0-9A-Z]{16}|tskey-\w+)\b|\b(?:\d[ -]?){13,19}\b|password\s*[:=]\s*\S+/i.test(text);
}
async function fileEntry(c, date) {
  const md = entryMarkdown(c, date);
  if (looksSecret(md)) return { slug: c.slug, ok: false, verified: false, detail: "Refused: the entry looks like it contains a credential or card number." };
  const path13 = `entries/${c.slug}.md`;
  const put = await gh(`/repos/${WIKI_REPO}/contents/${path13}`, { method: "PUT", body: JSON.stringify({ message: `Audit ${date}: add ${c.slug}`, content: b64(md) }) });
  if (!put.ok) return { slug: c.slug, ok: false, verified: false, detail: `GitHub refused (HTTP ${put.status}${put.status === 422 ? ": an entry with this slug may already exist" : ""}).` };
  const back = await gh(`/repos/${WIKI_REPO}/contents/${path13}`);
  const same2 = back.ok && unb64((await back.json()).content ?? "") === md;
  return { slug: c.slug, ok: true, verified: same2, detail: same2 ? "Filed and read back \u2713" : "Write accepted but read-back didn't match." };
}
function upsertAudit(runId, patch3) {
  let rec;
  audits.update((l) => {
    rec = l.find((a) => a.runId === runId);
    if (!rec) {
      rec = { runId, startedAt: now(), scored: [], duplicates: [], filings: [], wiki: null, unavailable: [] };
      l.push(rec);
      if (l.length > 60) l.splice(0, l.length - 60);
    }
    Object.assign(rec, patch3);
  });
  emit("audit", { runId });
  return rec;
}
function rank(list) {
  return list.filter((c) => c.accepted).sort((a, b) => b.total - a.total || b.utility - a.utility || a.name.localeCompare(b.name)).map((c, i) => ({ ...c, rank: i + 1 }));
}
function buildReport(rec, notes = "") {
  const ranked = rank(rec.scored);
  const top = ranked.slice(0, 20);
  const overflow = ranked.slice(20);
  const filedOk = rec.filings.filter((f) => f.ok && f.verified);
  const byPhase = (p) => filedOk.filter((f) => f.phase === p).length;
  const rejected = rec.scored.filter((c) => !c.accepted);
  const lines2 = [
    `# MausDroid Routine & Skill Audit \u2014 ${rec.startedAt.slice(0, 10)}`,
    "",
    `Research window: ${rec.startedAt.slice(11, 16)}\u2013${(rec.researchCutoffAt ?? rec.startedAt).slice(11, 16)} UTC (5-minute cutoff). Wiki: ${rec.wiki?.detail ?? "not checked"}.`,
    "",
    "## Top 20",
    "",
    "| Rank | Routine / Skill | Source | Phase Tag | MausDroid Primitives | Composio / Account | Fit (1-5) | Wiki Slug |",
    "|---|---|---|---|---|---|---|---|",
    ...top.map((c) => `| ${c.rank} | ${cell(c.name)} (${c.total}/25) | [${cell(c.source_ecosystem)}](${c.source_url}) | ${c.phase} | ${cell(c.primitives.join(", "))} | ${cell([...c.composio ?? [], c.account_alias ?? "personal"].join(" / "))} | ${c.scope_fit} | ${c.slug} |`),
    top.length ? "" : "_No accepted candidates._",
    "## Top 3 Phase 1 immediate taps",
    ...ranked.filter((c) => c.phase === "phase-1-ready").slice(0, 3).map((c, i) => `${i + 1}. **${c.name}** \u2014 ${c.summary}`) || [],
    ranked.some((c) => c.phase === "phase-1-ready") ? "" : "_None this week._",
    "## Installable through the Skills marketplace",
    ...[...new Set(ranked.map((c) => c.github_repo).filter(Boolean))].map((r) => `- ${r}`),
    ranked.some((c) => c.github_repo) ? "" : "_None._",
    `## Wiki overflow (ranked 21+): ${filedOk.length} filed of ${overflow.length}`,
    `- phase-1-ready: ${byPhase("phase-1-ready")} \xB7 phase-2-queued: ${byPhase("phase-2-queued")} \xB7 phase-3-queued: ${byPhase("phase-3-queued")}`,
    rec.duplicates.length ? `- Already in the wiki / repeats skipped: ${rec.duplicates.map((d) => `${d.name} (= ${d.of})`).join("; ")}` : "",
    "## Rejected",
    ...rejected.length ? rejected.map((c) => `- ${c.name}: ${c.reasons.join("; ")}`) : ["_None._"],
    "## Unavailable research sources",
    ...rec.unavailable.length ? rec.unavailable.map((u) => `- ${u}`) : ["_None reported._"],
    "## Wiki filing errors",
    ...rec.filings.filter((f) => !f.ok || !f.verified).map((f) => `- ${f.slug}: ${f.detail}`).concat(rec.wiki && !rec.wiki.ok ? [`- Wiki unavailable: ${rec.wiki.detail}`] : []) || [],
    rec.filings.some((f) => !f.ok || !f.verified) || rec.wiki && !rec.wiki.ok ? "" : "_None._",
    notes ? `
## Notes
${notes}` : ""
  ];
  return lines2.filter((l, i, a) => !(l === "" && a[i - 1] === "")).join("\n");
}
var AUDIT_SYSTEM, WIKI_REPO, GH, SAFETY_FLAGS, SAFETY_WORDS, slugify, tokens, PHASES, b64, unb64, audits, listAudits, auditFor, cell, RESEARCH_TOOLS, AUDIT_PROMPT;
var init_audit = __esm({
  "src/audit.ts"() {
    "use strict";
    init_store();
    init_secrets();
    init_events();
    init_util();
    AUDIT_SYSTEM = "weekly-audit";
    WIKI_REPO = process.env.MAUSDROID_WIKI_REPO ?? "DanGeo13/mausdroid-routine-wiki";
    GH = process.env.MAUSDROID_GITHUB_API ?? "https://api.github.com";
    SAFETY_FLAGS = {
      meta_account_control: "drives or autonomously controls a Meta (Facebook/Messenger/WhatsApp/Instagram/Marketplace) account",
      compass_login: "logs into Compass",
      card_security_code: "exposes a CVV or card security information",
      desktop_only_shell: "needs desktop-only shell execution",
      unapproved_sensitive_ops: "performs sensitive account operations without approval",
      unsafe_credentials: "handles credentials unsafely",
      unnecessary_personal_data: "exposes personal data unnecessarily"
    };
    SAFETY_WORDS = [
      ["meta_account_control", /\b(auto[- ]?(post|reply|message|list)|drive|control|automate|log ?in(to)?|bot for)\b[^.]{0,40}\b(facebook|messenger|whatsapp|instagram|marketplace|meta)\b|\b(facebook|messenger|whatsapp|instagram|marketplace)\b[^.]{0,40}\b(automation|auto[- ]?(post|reply|message)|scraper|bot)\b/i],
      ["compass_login", /\b(log ?in(to)?|sign ?in(to)?|scrape|automate)\b[^.]{0,30}\bcompass\b|\bcompass\b[^.]{0,30}\b(login|password|credentials)\b/i],
      ["card_security_code", /\b(cvv|cvc|card security code|security code of (the|your) card)\b/i],
      ["desktop_only_shell", /\b(desktop[- ]only|requires? (a )?(mac|windows|linux desktop)|powershell|applescript)\b/i],
      ["unsafe_credentials", /\b(store|save|paste|share)s? (your |the )?(password|api key|token)s? (in|into) (the )?(prompt|notes|wiki|chat|plain ?text)/i]
    ];
    slugify = (s) => s.toLowerCase().normalize("NFKD").replace(/[^\w\s-]/g, "").trim().replace(/[\s_]+/g, "-").replace(/-+/g, "-").slice(0, 60);
    tokens = (s) => new Set(s.toLowerCase().replace(/[^\w\s]/g, " ").split(/\s+/).filter((t) => t.length > 2));
    PHASES = ["phase-1-ready", "phase-2-queued", "phase-3-queued"];
    b64 = (s) => Buffer.from(s, "utf8").toString("base64");
    unb64 = (s) => Buffer.from(s, "base64").toString("utf8");
    audits = collection("audits", []);
    listAudits = () => audits.get().slice().reverse();
    auditFor = (runId) => audits.get().find((a) => a.runId === runId);
    cell = (s) => String(s ?? "").replace(/\|/g, "\\|").replace(/\n/g, " ");
    RESEARCH_TOOLS = /^(web_search|web_fetch|browser_open|browser_read|browser_click|browser_scroll|composio__COMPOSIO_SEARCH_TOOLS|composio__COMPOSIO_MULTI_EXECUTE_TOOL|skills_market_search|tailnet_fetch)$/;
    AUDIT_PROMPT = `Run the weekly MausDroid Routine & Skill Audit. You have a strict 5-minute research window; after it, research tools stop working, so be quick. Finish before 08:00.
1. Call audit_begin.
2. Research (personal account aliases only; don't assume integrations are connected) useful workflows, skills and capabilities for MausDroid from: Grok Bot, Meta Muse, OpenAI Dots, Claude Duet, n8n, Nod, GitHub claude-skills and agent-skills repositories, connected Composio apps, and the Skills marketplace (skills_market_search). Use web_search, web_fetch, browser tools and Composio search. Note any source you couldn't reach.
3. For each candidate, score utility, adoption signal, MausDroid scope fit, setup simplicity and privacy/safety (1\u20135 each), set safety flags honestly, mark the action type (read-only / user-approved / autonomous / unsupported), choose the phase (phase-1-ready = existing MausDroid capabilities; phase-2-queued = new integrations, Android capabilities or moderate changes; phase-3-queued = major engineering), list MausDroid primitives (e.g. notify_user, routine_create, calendar_create_event, web_fetch, composio apps), and fill the alignment fields. Never describe a rejected idea differently to get it through.
4. Call audit_score with all candidates (it applies the safety gate, removes duplicates against the wiki and ranks them).
5. Call audit_file_overflow to file every accepted candidate ranked 21 or lower in the private wiki.
6. Call audit_finish with unavailable sources and short notes; it returns the report built from the recorded data.
7. Call memory_save (scope "bot") with three lines: highest-value discoveries; top Phase 1 implementation; overflow counts and blockers.
8. Call notify_user (priority normal, title "Sunday Routine Audit Ready") with one sentence: the top Phase 1 recommendation and the total wiki overflow count.
If anything fails or is incomplete, say so plainly in the notification instead of presenting a successful audit.`;
  }
});

// src/skills.ts
var skills_exports = {};
__export(skills_exports, {
  ensureBuiltinSkills: () => ensureBuiltinSkills,
  installFromGitHub: () => installFromGitHub,
  listRepoSkills: () => listRepoSkills,
  listSkills: () => listSkills,
  parseFrontmatter: () => parseFrontmatter,
  readSkill: () => readSkill,
  readSkillFile: () => readSkillFile,
  removeSkill: () => removeSkill,
  saveSkill: () => saveSkill,
  searchMarketplace: () => searchMarketplace
});
function ghHeaders() {
  const h = { "user-agent": "MausDroid-skills", accept: "application/vnd.github+json" };
  const t = getSecret("github");
  if (t) h.authorization = `Bearer ${t}`;
  return h;
}
function parseFrontmatter(md) {
  const m = md.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!m) return { body: md };
  const meta2 = {};
  for (const line of m[1].split(/\r?\n/)) {
    const kv = line.match(/^([A-Za-z_-]+):\s*(.*)$/);
    if (kv) meta2[kv[1]] = kv[2].replace(/^["']|["']$/g, "").trim();
  }
  return { name: meta2.name, description: meta2.description, body: m[2] };
}
function listSkills() {
  const out = [];
  if (!import_node_fs8.default.existsSync(root3())) return out;
  for (const d of import_node_fs8.default.readdirSync(root3())) {
    const file4 = import_node_path7.default.join(root3(), d, "SKILL.md");
    if (!import_node_fs8.default.existsSync(file4)) continue;
    const fm = parseFrontmatter(import_node_fs8.default.readFileSync(file4, "utf8"));
    let source;
    try {
      source = JSON.parse(import_node_fs8.default.readFileSync(import_node_path7.default.join(root3(), d, ".source.json"), "utf8")).source;
    } catch {
    }
    out.push({ name: fm.name ?? d, description: fm.description ?? "", source, dir: import_node_path7.default.join(root3(), d) });
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}
function readSkill(name) {
  const s = listSkills().find((x) => x.name === name);
  if (!s) throw new Error(`No skill called ${name}`);
  const md = import_node_fs8.default.readFileSync(import_node_path7.default.join(s.dir, "SKILL.md"), "utf8");
  const extra = import_node_fs8.default.readdirSync(s.dir, { recursive: true }).map(String).filter((f) => f !== "SKILL.md" && !f.startsWith("."));
  return `${md}

[Other files in this skill: ${extra.join(", ") || "none"}. Ask with skill_read using file= to open one.]`;
}
function readSkillFile(name, file4) {
  const s = listSkills().find((x) => x.name === name);
  if (!s) throw new Error(`No skill called ${name}`);
  const p = import_node_path7.default.resolve(s.dir, file4);
  if (!p.startsWith(s.dir + import_node_path7.default.sep)) throw new Error("That file is outside the skill folder.");
  return import_node_fs8.default.readFileSync(p, "utf8");
}
function saveSkill(name, md) {
  const safe = name.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-|-$/g, "") || "skill";
  const dir = import_node_path7.default.join(root3(), safe);
  import_node_fs8.default.mkdirSync(dir, { recursive: true });
  import_node_fs8.default.writeFileSync(import_node_path7.default.join(dir, "SKILL.md"), md);
  return safe;
}
function removeSkill(name) {
  const s = listSkills().find((x) => x.name === name);
  if (s) import_node_fs8.default.rmSync(s.dir, { recursive: true, force: true });
}
async function searchMarketplace(q) {
  const query = `${q ? `${q} ` : ""}topic:claude-skills OR topic:agent-skills OR topic:claude-code-skills`;
  const res = await fetch(`${API3}/search/repositories?q=${encodeURIComponent(query)}&sort=stars&per_page=30`, { headers: ghHeaders() });
  if (!res.ok) throw new Error(`GitHub search: HTTP ${res.status}${res.status === 403 ? " (rate limit: add a GitHub token in Settings)" : ""}`);
  const j = await res.json();
  const featured = [{ full_name: "anthropics/skills", description: "Anthropic's official example skills", stargazers_count: null, html_url: "https://github.com/anthropics/skills" }];
  return [...featured, ...j.items ?? []].map((r) => ({ repo: r.full_name, description: r.description, stars: r.stargazers_count, url: r.html_url }));
}
function parseRepoRef(ref) {
  const m = ref.trim().replace(/^https:\/\/github\.com\//, "").replace(/\.git$/, "").match(/^([^/]+)\/([^/]+)(?:\/tree\/([^/]+))?(?:\/(.*))?$/);
  if (!m) throw new Error("Use owner/repo or a github.com link.");
  return { owner: m[1], repo: m[2], branch: m[3], sub: (m[4] ?? "").replace(/\/$/, "") };
}
async function listRepoSkills(ref) {
  const { owner, repo, branch, sub } = parseRepoRef(ref);
  let ref2 = branch;
  if (!ref2) {
    const r = await fetch(`${API3}/repos/${owner}/${repo}`, { headers: ghHeaders() });
    if (!r.ok) throw new Error(`GitHub: HTTP ${r.status}`);
    ref2 = (await r.json()).default_branch;
  }
  const t = await fetch(`${API3}/repos/${owner}/${repo}/git/trees/${ref2}?recursive=1`, { headers: ghHeaders() });
  if (!t.ok) throw new Error(`GitHub: HTTP ${t.status}`);
  const tree = (await t.json()).tree;
  const dirs = tree.filter((e) => e.type === "blob" && /(^|\/)SKILL\.md$/.test(e.path) && (!sub || e.path.startsWith(sub))).map((e) => import_node_path7.default.posix.dirname(e.path));
  return { owner, repo, branch: ref2, tree, dirs };
}
async function installFromGitHub(ref, only) {
  const { owner, repo, branch, tree, dirs } = await listRepoSkills(ref);
  const chosen = only?.length ? dirs.filter((d) => only.includes(d) || only.includes(import_node_path7.default.posix.basename(d))) : dirs;
  if (!chosen.length) throw new Error("No SKILL.md found there.");
  if (chosen.length > 40) throw new Error(`That repo has ${chosen.length} skills \u2014 pick specific ones.`);
  const installed2 = [];
  for (const d of chosen) {
    const files2 = tree.filter((e) => e.type === "blob" && (d === "." ? !e.path.includes("/") || e.path === "SKILL.md" : e.path.startsWith(d + "/")) && (e.size ?? 0) < 1e6);
    if (files2.length > 200) continue;
    const skillMd = await (await fetch(`https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${d === "." ? "" : d + "/"}SKILL.md`)).text();
    const fm = parseFrontmatter(skillMd);
    const name = saveSkill(fm.name ?? import_node_path7.default.posix.basename(d === "." ? repo : d), skillMd);
    const dir = import_node_path7.default.join(root3(), name);
    for (const f of files2) {
      const rel = d === "." ? f.path : f.path.slice(d.length + 1);
      if (rel === "SKILL.md") continue;
      const res = await fetch(`https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${f.path}`);
      if (!res.ok) continue;
      const target = import_node_path7.default.join(dir, rel);
      import_node_fs8.default.mkdirSync(import_node_path7.default.dirname(target), { recursive: true });
      import_node_fs8.default.writeFileSync(target, Buffer.from(await res.arrayBuffer()));
    }
    import_node_fs8.default.writeFileSync(import_node_path7.default.join(dir, ".source.json"), JSON.stringify({ source: `github.com/${owner}/${repo}/${d}`, branch }));
    installed2.push(name);
  }
  return installed2;
}
function ensureBuiltinSkills() {
  for (const [name, md] of Object.entries(BUILTIN_SKILLS)) {
    if (listSkills().some((s) => s.name === name)) continue;
    saveSkill(name, md);
  }
}
var import_node_fs8, import_node_path7, root3, API3, BUILTIN_SKILLS;
var init_skills = __esm({
  "src/skills.ts"() {
    "use strict";
    import_node_fs8 = __toESM(require("node:fs"), 1);
    import_node_path7 = __toESM(require("node:path"), 1);
    init_store();
    init_secrets();
    root3 = () => import_node_path7.default.dirname(dataPath("skills", ".keep"));
    API3 = "https://api.github.com";
    BUILTIN_SKILLS = {
      gumtree: `---
name: gumtree
description: Search, watch and read Gumtree (Australia) listings in the background browser with the person's own login \u2014 Gumtree has no app connection. Use for "find on Gumtree", price checks, watching for new listings, and drafting listings or messages for approval.
---
# Gumtree (through the background browser)

Gumtree has no API or Composio toolkit, so use the phone's background browser (browser_open, browser_read, browser_scroll, browser_click, browser_type, browser_screenshot).

## Searching
- Open https://www.gumtree.com.au/s-QUERY/k0 (spaces as hyphens, e.g. /s-road-bike/k0). Add a location by opening the site and using its location box, or ask the person for their suburb once and remember it (memory_save).
- browser_read the results; scroll for more. For each useful listing give: title, price, suburb, posted time and the link. Point out obvious duplicates or likely scams (too-cheap prices, "shipping only", requests to pay outside Gumtree).
- To check a listing, open its link and read the description, condition and seller details.

## Watching for new listings
- Suggest a routine (routine_create, e.g. every 2 hours) that runs the same search and calls notify_user only for listings it hasn't reported before (keep the links you've seen in memory).

## Logging in
- Only when needed (messages, saved searches, posting): call browser_ask_login so the person signs in themselves in the browser. Never ask for their password in chat.

## Never without the person's OK
- Posting, editing or deleting a listing, messaging a seller, making an offer or paying. Draft the text first, show it, and only send after they approve (the approval card).
- Don't create accounts or automate bulk actions; keep to what a person would do by hand.
`
    };
  }
});

// src/location.ts
function describeLocationError(r) {
  return r.error ? MESSAGES[r.error] ?? `Location unavailable (${r.error}).` : null;
}
async function getLocation(requester, maxAgeMs = 12e4) {
  const reqId = id("loc");
  active2.set(reqId, { requester, startedAt: now() });
  emit("location", { state: "active", id: reqId, requester });
  let r;
  try {
    if (!bridgeAvailable()) r = { permission: "unavailable", error: "unavailable", note: "Location needs the Android app." };
    else r = await bridge("/location/get", { maxAgeMs: Math.min(Math.max(maxAgeMs, 1e4), 30 * 6e4), timeoutMs: 2e4 }, 3e4);
  } catch (e) {
    r = { permission: "unavailable", error: "unavailable", note: e.message };
  } finally {
    active2.delete(reqId);
  }
  if (r.error || typeof r.latitude !== "number" || typeof r.longitude !== "number") {
    delete r.latitude;
    delete r.longitude;
  }
  const outcome = r.error ? r.error : r.stale ? "stale fix" : "ok";
  log.update((l) => {
    l.push({ id: reqId, at: now(), requester, outcome });
    if (l.length > 200) l.splice(0, l.length - 200);
  });
  emit("location", { state: "done", id: reqId, requester, outcome });
  return r;
}
var log, active2, recentLocationUses, activeLocationRequests, MESSAGES;
var init_location = __esm({
  "src/location.ts"() {
    "use strict";
    init_bridge();
    init_events();
    init_store();
    init_util();
    log = collection("location-uses", []);
    active2 = /* @__PURE__ */ new Map();
    recentLocationUses = () => log.get().slice().reverse().slice(0, 30);
    activeLocationRequests = () => [...active2.entries()].map(([id2, a]) => ({ id: id2, ...a }));
    MESSAGES = {
      permission_not_requested: "Location permission hasn't been given. The person can allow it in Settings \u2192 Phone \u2192 Location (MausDroid never turns it on by itself).",
      permission_denied: "The person said no to location access.",
      permission_permanently_denied: "Location is blocked for MausDroid in Android settings. The person can allow it under App info \u2192 Permissions \u2192 Location.",
      location_off: "Location is turned off on the phone.",
      no_provider: "No location provider is available on the phone.",
      unavailable: "The phone couldn't get a location fix right now."
    };
  }
});

// src/calls.ts
function saveCallSettings(p) {
  store3.update((s) => s.settings = { ...s.settings, ...p });
  emit("settings.changed");
  return callSettings();
}
function callBot() {
  const s = callSettings();
  const bots = listBots().filter((b) => !b.hidden);
  return s.botId && getBot(s.botId) || bots.find((b) => b.name.trim().toLowerCase() === "maus") || bots.find((b) => b.pinned) || bots[0];
}
function record(r) {
  const c = { ...r, id: id("call"), at: now() };
  store3.update((s) => {
    s.log.push(c);
    if (s.log.length > 300) s.log.splice(0, s.log.length - 300);
  });
  emit("call", { call: c });
  return c;
}
function patch(id2, p) {
  let out;
  store3.update((s) => {
    const c = s.log.find((x) => x.id === id2);
    if (c) Object.assign(c, p), out = { ...c };
  });
  if (out) emit("call", { call: out });
  return out;
}
function inLockout(at, lockouts, tz) {
  return withTimeZone(tz, () => {
    const m = at.getHours() * 60 + at.getMinutes();
    const day = at.getDay();
    const yesterday = (day + 6) % 7;
    for (const w of lockouts) {
      const a = minutes(w.start);
      const b = minutes(w.end);
      if (a <= b) {
        if (w.days.includes(day) && m >= a && m < b) return w;
      } else if (w.days.includes(day) && m >= a || w.days.includes(yesterday) && m < b) return w;
    }
    return null;
  });
}
async function mayCall(at = /* @__PURE__ */ new Date()) {
  const s = callSettings();
  if (!s.enabled) return { ok: false, reason: "Calls are switched off." };
  const tz = settings().timeZone?.includes("/") ? settings().timeZone : void 0;
  const lock = inLockout(at, s.lockouts, tz);
  if (lock) return { ok: false, reason: `It's a lock-out time (${lock.label ?? `${lock.start}\u2013${lock.end}`}).` };
  const hourAgo = at.getTime() - 36e5;
  const recent2 = store3.get().log.filter((c) => c.direction === "incoming" && c.state !== "blocked" && new Date(c.at).getTime() > hourAgo).length;
  if (recent2 >= s.maxPerHour) return { ok: false, reason: `Maus already called ${recent2} time(s) in the last hour (limit ${s.maxPerHour}).` };
  const margin = s.calendarMarginMinutes * 6e4;
  const busy = await busyBetween(new Date(at.getTime() - margin), new Date(at.getTime() + margin)).catch((e) => ({ busy: true, event: void 0, error: e.message }));
  if (busy.error) return { ok: false, reason: `Couldn't check your calendar (${busy.error}), so no call \u2014 better safe than interrupting.` };
  if (busy.busy) return { ok: false, reason: `You have "${busy.event ?? "an event"}" in your calendar right now.` };
  return { ok: true, reason: "Free." };
}
async function ringUser(reason, openingLine) {
  const bot = callBot();
  if (!bot) throw new Error("No bot to call from.");
  const allowed = await mayCall();
  if (!allowed.ok) {
    const c2 = record({ direction: "incoming", botId: bot.id, reason, state: "blocked", detail: allowed.reason });
    await notifyUser({ title: `${bot.emoji} ${bot.name} wanted to call`, body: `${reason} (Didn't ring: ${allowed.reason})`, botId: bot.id, priority: "low", type: "call" });
    return c2;
  }
  if (!bridgeAvailable()) throw new Error("Calls need the Android app.");
  const c = record({ direction: "incoming", botId: bot.id, reason, openingLine, state: "ringing" });
  const result = new Promise((resolve) => {
    waiting.set(c.id, resolve);
    setTimeout(() => waiting.get(c.id) && (waiting.delete(c.id), resolve("missed")), Number(process.env.MAUSDROID_CALL_RING_MS ?? 45e3));
  });
  await bridge("/call/ring", { callId: c.id, name: bot.name, emoji: bot.emoji, reason });
  const state3 = await result;
  await bridge("/call/stop-ring", { callId: c.id }).catch(() => {
  });
  const out = patch(c.id, { state: state3, ...state3 === "missed" ? { endedAt: now(), detail: "No answer" } : {} });
  if (state3 === "missed") await notifyUser({ title: `Missed call from ${bot.emoji} ${bot.name}`, body: reason, botId: bot.id, type: "call" });
  return out;
}
function answerCall(id2, answer2) {
  const fn = waiting.get(id2);
  if (!fn) return getCall(id2);
  waiting.delete(id2);
  fn(answer2 ? "active" : "declined");
  return getCall(id2);
}
function startOutgoing() {
  const bot = callBot();
  if (!bot) throw new Error("No bot to call.");
  if (!callSettings().enabled) throw new Error("Calls are switched off (Settings \u2192 Voice & assistant).");
  return record({ direction: "outgoing", botId: bot.id, reason: "You called", state: "active" });
}
function endCall(id2) {
  return patch(id2, { state: "ended", endedAt: now() });
}
function callTurn(callId, text) {
  const c = getCall(callId);
  if (!c || c.state !== "active") throw new Error("This call has ended.");
  return new Promise((resolve) => {
    const off = onTurnEnd((botId, reply) => {
      if (botId !== c.botId) return;
      off();
      clearTimeout(t);
      resolve({ reply });
    });
    const t = setTimeout(() => (off(), resolve({ reply: "Sorry, that's taking me a while. I'll message you when it's done." })), 12e4);
    sendToBot(c.botId, `${text}

(Said aloud during a phone call with you: answer in one to three short spoken sentences, no lists or links.)`, "call");
  });
}
var store3, callSettings, callLog, isCallBot, getCall, minutes, waiting;
var init_calls = __esm({
  "src/calls.ts"() {
    "use strict";
    init_store();
    init_events();
    init_bridge();
    init_notify();
    init_bots();
    init_calendar();
    init_settings();
    init_util();
    init_agent();
    init_schedule();
    store3 = collection("calls", {
      settings: { enabled: true, botId: null, lockouts: [{ days: [0, 1, 2, 3, 4, 5, 6], start: "21:30", end: "07:00", label: "Night" }], maxPerHour: 3, calendarMarginMinutes: 10 },
      log: []
    });
    callSettings = () => store3.get().settings;
    callLog = () => store3.get().log.slice().reverse().slice(0, 50);
    isCallBot = (botId) => callSettings().enabled && callBot()?.id === botId;
    getCall = (id2) => store3.get().log.find((c) => c.id === id2);
    minutes = (hm) => {
      const [h, m] = hm.split(":").map(Number);
      return h * 60 + m;
    };
    waiting = /* @__PURE__ */ new Map();
  }
});

// src/selfupdate.ts
function enginesRoot() {
  const ui = process.env.MAUSDROID_UI_DIR;
  if (!ui || config.platform !== "android") return process.env.MAUSDROID_ENGINES_DIR ?? null;
  return import_node_path8.default.dirname(import_node_path8.default.dirname(ui));
}
function engineVersions() {
  const root4 = enginesRoot();
  const running3 = config.version;
  if (!root4 || !import_node_fs9.default.existsSync(root4)) return { running: running3, canRollBack: false, versions: [] };
  const bad = import_node_fs9.default.existsSync(import_node_path8.default.join(root4, "bad.txt")) ? import_node_fs9.default.readFileSync(import_node_path8.default.join(root4, "bad.txt"), "utf8").split("\n").map((x) => x.trim()).filter(Boolean) : [];
  const versions = import_node_fs9.default.readdirSync(root4).filter((d) => /^\d+\.\d+\.\d+$/.test(d) && import_node_fs9.default.existsSync(import_node_path8.default.join(root4, d, "engine.cjs"))).sort((a, b) => cmp(b, a)).map((v) => ({ version: v, bad: bad.includes(v), running: v === running3 }));
  return { running: running3, canRollBack: versions.some((v) => !v.running && cmp(v.version, running3) < 0), versions };
}
function rollBack(to) {
  const root4 = enginesRoot();
  if (!root4) throw new Error("Rolling back works in the Android app.");
  const { running: running3, versions } = engineVersions();
  const target = to ? versions.find((v) => v.version === to) : versions.find((v) => cmp(v.version, running3) < 0);
  if (!target) throw new Error(to ? `Version ${to} isn't on the phone. Kept versions: ${versions.map((v) => v.version).join(", ") || "none"}.` : "There's no earlier version on the phone to go back to.");
  if (target.version === running3) throw new Error(`${running3} is already running.`);
  if (restarting) throw new Error("Already restarting.");
  if (cmp(target.version, running3) < 0) import_node_fs9.default.appendFileSync(import_node_path8.default.join(root4, "bad.txt"), `${running3}
`);
  const badFile = import_node_path8.default.join(root4, "bad.txt");
  if (import_node_fs9.default.existsSync(badFile)) import_node_fs9.default.writeFileSync(badFile, import_node_fs9.default.readFileSync(badFile, "utf8").split("\n").filter((x) => x.trim() && x.trim() !== target.version).map((x) => `${x}
`).join(""));
  import_node_fs9.default.writeFileSync(import_node_path8.default.join(root4, "current.txt"), target.version);
  for (const f of ["trial.txt", "trial-started.txt"]) import_node_fs9.default.rmSync(import_node_path8.default.join(root4, f), { force: true });
  restarting = true;
  setTimeout(() => process.exit(0), Number(process.env.MAUSDROID_RESTART_DELAY_MS ?? 2500));
  return { from: running3, to: target.version };
}
function gh2(p, init = {}) {
  const token = getSecret("github");
  if (!token) throw new Error("Save a GitHub token first (Settings \u2192 Memory \u2192 GitHub token) with access to the MausDroid repository (Actions, Contents and Pull requests: read and write).");
  return fetch(`${GH2}${p}`, { ...init, headers: { authorization: `Bearer ${token}`, accept: "application/vnd.github+json", "user-agent": "MausDroid-improver", "content-type": "application/json", ...init.headers ?? {} }, signal: AbortSignal.timeout(3e4) });
}
async function ghJson(p, init = {}) {
  const r = await gh2(p, init);
  const text = await r.text();
  let j = {};
  try {
    j = text ? JSON.parse(text) : {};
  } catch {
  }
  if (!r.ok) throw new Error(`GitHub said HTTP ${r.status}${j?.message ? `: ${j.message}` : ""}`);
  return j;
}
async function startBuild(id2, request, answers = "", attempt = 1, agent = "claude") {
  await ghJson(`/repos/${CODE_REPO}/actions/workflows/${WORKFLOW}/dispatches`, {
    method: "POST",
    body: JSON.stringify({ ref: "main", inputs: { id: id2, request: clip(request, 6e3), answers: clip(answers, 4e3), attempt: String(attempt), platform: agent } })
  });
}
async function buildState(id2, attempt = 1) {
  const owner = CODE_REPO.split("/")[0];
  const prs = await ghJson(`/repos/${CODE_REPO}/pulls?state=all&head=${owner}:improve/${id2}`);
  const pr = Array.isArray(prs) ? prs[0] : null;
  if (pr) {
    if (pr.merged_at) return { state: "merged", prNumber: pr.number, prUrl: pr.html_url };
    if (pr.state === "closed") return { state: "closed", prNumber: pr.number, prUrl: pr.html_url };
    return { state: "ready", prNumber: pr.number, prUrl: pr.html_url };
  }
  const q = await gh2(`/repos/${CODE_REPO}/contents/.improver/questions-${attempt}.md?ref=${encodeURIComponent(`improve/${id2}-questions`)}`);
  if (q.ok) {
    const j = await q.json();
    return { state: "question", questions: clip(Buffer.from(String(j.content ?? ""), "base64").toString("utf8").trim(), 3e3) };
  }
  const runs = await ghJson(`/repos/${CODE_REPO}/actions/workflows/${WORKFLOW}/runs?event=workflow_dispatch&per_page=30`);
  const run = (runs.workflow_runs ?? []).find((r) => String(r.display_title ?? r.name ?? "").includes(id2));
  if (run && run.status === "completed" && run.conclusion !== "success") return { state: "failed", runUrl: run.html_url, detail: `The cloud build ${run.conclusion} (tests failing, no change made, or it ran out of time).` };
  let progress2 = run ? "Waiting for a cloud computer" : "Starting";
  if (run && run.status === "in_progress") {
    try {
      const jobs = await ghJson(`/repos/${CODE_REPO}/actions/runs/${run.id}/jobs`);
      const steps2 = jobs.jobs?.[0]?.steps ?? [];
      const cur = steps2.find((x) => x.status === "in_progress") ?? steps2.filter((x) => x.status === "completed").at(-1);
      if (cur) progress2 = stepWords(cur.name);
    } catch {
    }
  }
  return { state: "building", runUrl: run?.html_url, progress: progress2 };
}
async function mergeBuild(prNumber) {
  await ghJson(`/repos/${CODE_REPO}/pulls/${prNumber}/merge`, { method: "PUT", body: JSON.stringify({ merge_method: "squash" }) });
}
async function closeBuild(prNumber) {
  await ghJson(`/repos/${CODE_REPO}/pulls/${prNumber}`, { method: "PATCH", body: JSON.stringify({ state: "closed" }) });
}
var import_node_fs9, import_node_path8, CODE_REPO, GH2, WORKFLOW, cmp, restarting, AGENT_NAMES, STEP_WORDS, stepWords;
var init_selfupdate = __esm({
  "src/selfupdate.ts"() {
    "use strict";
    import_node_fs9 = __toESM(require("node:fs"), 1);
    import_node_path8 = __toESM(require("node:path"), 1);
    init_config();
    init_secrets();
    init_util();
    CODE_REPO = process.env.MAUSDROID_CODE_REPO ?? "DanGeo13/MausDroid";
    GH2 = process.env.MAUSDROID_GITHUB_API ?? "https://api.github.com";
    WORKFLOW = "improver.yml";
    cmp = (a, b) => {
      const pa = a.split(".").map(Number);
      const pb = b.split(".").map(Number);
      for (let i = 0; i < 3; i++) if ((pa[i] ?? 0) !== (pb[i] ?? 0)) return (pa[i] ?? 0) - (pb[i] ?? 0);
      return 0;
    };
    restarting = false;
    AGENT_NAMES = { claude: "Claude Code", codex: "Codex" };
    STEP_WORDS = [
      [/Claude Code makes the change/, "Claude Code is making the change"],
      [/Codex makes the change/, "Codex is making the change"],
      [/Write the instructions/, "Writing up the job"],
      [/Questions for the person/, "Checking whether it needs anything from you"],
      [/Only the engine/, "Checking only allowed parts changed"],
      [/Next engine version/, "Numbering the new version"],
      [/Build and test/, "Running every test (like on your phone)"],
      [/Open the pull request/, "Getting it ready to install"]
    ];
    stepWords = (name) => STEP_WORDS.find(([re]) => re.test(name))?.[1] ?? "Setting up";
  }
});

// src/phone-notifications.ts
function addIncoming(items) {
  let added = 0;
  const fresh = [];
  store4.update((l) => {
    for (const it of Array.isArray(items) ? items.slice(0, 200) : []) {
      const postedAt = new Date(Number(it.postedAt) || Date.now()).toISOString();
      const key2 = String(it.key ?? "");
      const title = clip(String(it.title ?? ""), 300);
      const text = clip(String(it.text ?? ""), 4e3);
      if (l.some((x) => x.key === key2 && x.postedAt === postedAt) || l.some((x) => x.key === key2 && x.title === title && x.text === text)) continue;
      if (looksSecret(`${title}
${text}`)) continue;
      const n = { id: id("pn"), key: key2, pkg: String(it.pkg ?? ""), app: clip(String(it.app ?? it.pkg ?? "app"), 80), title, text, subText: it.subText ? clip(String(it.subText), 200) : void 0, category: it.category || void 0, postedAt, receivedAt: now(), pending: Boolean(it.pending) };
      l.push(n);
      fresh.push(n);
      added++;
    }
    if (l.length > 3e3) l.splice(0, l.length - 3e3);
  });
  for (const n of fresh)
    void notifyUser({ title: `${n.app}: ${n.title}`.slice(0, 200), body: n.text.slice(0, 500), type: "phone-notification", source: n.app, eventId: n.id, priority: "low", silentRecord: true });
  if (added) emit("phone-notifications", { added });
  return { added };
}
function recent(opts = {}) {
  const since2 = opts.sinceHours ? Date.now() - opts.sinceHours * 36e5 : 0;
  return store4.get().filter((n) => (!opts.app || `${n.app} ${n.pkg}`.toLowerCase().includes(opts.app.toLowerCase())) && new Date(n.postedAt).getTime() >= since2).slice(-(opts.limit ?? 200)).reverse();
}
function assistantExamples(days = 7) {
  return recent({ sinceHours: days * 24, limit: 60 }).filter((n) => /muse/i.test(`${n.app} ${n.pkg}`)).map((n) => ({ at: n.postedAt, title: n.title, text: clip(n.text, 400) }));
}
var store4, flags, firstReviewDone, markFirstReview, counts, REVIEW_PROMPT;
var init_phone_notifications = __esm({
  "src/phone-notifications.ts"() {
    "use strict";
    init_store();
    init_events();
    init_util();
    init_notify();
    init_audit();
    store4 = collection("phone-notifications", []);
    flags = collection("phone-notifications-state", {});
    firstReviewDone = () => Boolean(flags.get().firstReviewAt);
    markFirstReview = () => flags.update((f) => void (f.firstReviewAt = now()));
    counts = () => {
      const by = {};
      for (const n of store4.get()) by[n.app] = (by[n.app] ?? 0) + 1;
      return by;
    };
    REVIEW_PROMPT = (items) => `Review these notifications from Meta's Muse assistant (${items.length}; ${items.filter((n) => n.pending).length} were still pending). They show what a quality digital assistant anticipates for the person.

1. Work out the kinds of needs Muse anticipates (reminders, follow-ups, plans, nudges\u2026), when it sends them, and how it words them.
2. Compare with MausDroid's routines (routine_admin_list) and bots (bot_list): what does MausDroid not anticipate yet?
3. Suggest the few most useful changes with improve_propose (at most 5; new routines for Maus, better wording or timing) \u2014 don't change things now, the person approves the cards.
4. Save 3\u20136 short "assistant quality notes" with memory_save (scope "bot") so future checks keep them in mind.
5. Reply with a short summary: what Muse anticipates, what MausDroid now suggests doing.
MausDroid only reads these notifications; it never acts in Meta's apps.

Notifications (newest first):
${items.map((n) => `- ${n.postedAt}${n.pending ? " (pending)" : ""}: ${n.title} \u2014 ${clip(n.text.replace(/\s+/g, " "), 300)}`).join("\n")}`;
  }
});

// node_modules/tweetnacl/nacl-fast.js
var require_nacl_fast = __commonJS({
  "node_modules/tweetnacl/nacl-fast.js"(exports2, module2) {
    (function(nacl2) {
      "use strict";
      var gf = function(init) {
        var i, r = new Float64Array(16);
        if (init) for (i = 0; i < init.length; i++) r[i] = init[i];
        return r;
      };
      var randombytes = function() {
        throw new Error("no PRNG");
      };
      var _0 = new Uint8Array(16);
      var _9 = new Uint8Array(32);
      _9[0] = 9;
      var gf0 = gf(), gf1 = gf([1]), _121665 = gf([56129, 1]), D = gf([30883, 4953, 19914, 30187, 55467, 16705, 2637, 112, 59544, 30585, 16505, 36039, 65139, 11119, 27886, 20995]), D2 = gf([61785, 9906, 39828, 60374, 45398, 33411, 5274, 224, 53552, 61171, 33010, 6542, 64743, 22239, 55772, 9222]), X = gf([54554, 36645, 11616, 51542, 42930, 38181, 51040, 26924, 56412, 64982, 57905, 49316, 21502, 52590, 14035, 8553]), Y = gf([26200, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214]), I = gf([41136, 18958, 6951, 50414, 58488, 44335, 6150, 12099, 55207, 15867, 153, 11085, 57099, 20417, 9344, 11139]);
      function ts64(x, i, h, l) {
        x[i] = h >> 24 & 255;
        x[i + 1] = h >> 16 & 255;
        x[i + 2] = h >> 8 & 255;
        x[i + 3] = h & 255;
        x[i + 4] = l >> 24 & 255;
        x[i + 5] = l >> 16 & 255;
        x[i + 6] = l >> 8 & 255;
        x[i + 7] = l & 255;
      }
      function vn(x, xi, y, yi, n) {
        var i, d = 0;
        for (i = 0; i < n; i++) d |= x[xi + i] ^ y[yi + i];
        return (1 & d - 1 >>> 8) - 1;
      }
      function crypto_verify_16(x, xi, y, yi) {
        return vn(x, xi, y, yi, 16);
      }
      function crypto_verify_32(x, xi, y, yi) {
        return vn(x, xi, y, yi, 32);
      }
      function core_salsa20(o, p, k, c) {
        var j0 = c[0] & 255 | (c[1] & 255) << 8 | (c[2] & 255) << 16 | (c[3] & 255) << 24, j1 = k[0] & 255 | (k[1] & 255) << 8 | (k[2] & 255) << 16 | (k[3] & 255) << 24, j2 = k[4] & 255 | (k[5] & 255) << 8 | (k[6] & 255) << 16 | (k[7] & 255) << 24, j3 = k[8] & 255 | (k[9] & 255) << 8 | (k[10] & 255) << 16 | (k[11] & 255) << 24, j4 = k[12] & 255 | (k[13] & 255) << 8 | (k[14] & 255) << 16 | (k[15] & 255) << 24, j5 = c[4] & 255 | (c[5] & 255) << 8 | (c[6] & 255) << 16 | (c[7] & 255) << 24, j6 = p[0] & 255 | (p[1] & 255) << 8 | (p[2] & 255) << 16 | (p[3] & 255) << 24, j7 = p[4] & 255 | (p[5] & 255) << 8 | (p[6] & 255) << 16 | (p[7] & 255) << 24, j8 = p[8] & 255 | (p[9] & 255) << 8 | (p[10] & 255) << 16 | (p[11] & 255) << 24, j9 = p[12] & 255 | (p[13] & 255) << 8 | (p[14] & 255) << 16 | (p[15] & 255) << 24, j10 = c[8] & 255 | (c[9] & 255) << 8 | (c[10] & 255) << 16 | (c[11] & 255) << 24, j11 = k[16] & 255 | (k[17] & 255) << 8 | (k[18] & 255) << 16 | (k[19] & 255) << 24, j12 = k[20] & 255 | (k[21] & 255) << 8 | (k[22] & 255) << 16 | (k[23] & 255) << 24, j13 = k[24] & 255 | (k[25] & 255) << 8 | (k[26] & 255) << 16 | (k[27] & 255) << 24, j14 = k[28] & 255 | (k[29] & 255) << 8 | (k[30] & 255) << 16 | (k[31] & 255) << 24, j15 = c[12] & 255 | (c[13] & 255) << 8 | (c[14] & 255) << 16 | (c[15] & 255) << 24;
        var x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7, x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14, x15 = j15, u;
        for (var i = 0; i < 20; i += 2) {
          u = x0 + x12 | 0;
          x4 ^= u << 7 | u >>> 32 - 7;
          u = x4 + x0 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x4 | 0;
          x12 ^= u << 13 | u >>> 32 - 13;
          u = x12 + x8 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x1 | 0;
          x9 ^= u << 7 | u >>> 32 - 7;
          u = x9 + x5 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x9 | 0;
          x1 ^= u << 13 | u >>> 32 - 13;
          u = x1 + x13 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x6 | 0;
          x14 ^= u << 7 | u >>> 32 - 7;
          u = x14 + x10 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x14 | 0;
          x6 ^= u << 13 | u >>> 32 - 13;
          u = x6 + x2 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x11 | 0;
          x3 ^= u << 7 | u >>> 32 - 7;
          u = x3 + x15 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x3 | 0;
          x11 ^= u << 13 | u >>> 32 - 13;
          u = x11 + x7 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
          u = x0 + x3 | 0;
          x1 ^= u << 7 | u >>> 32 - 7;
          u = x1 + x0 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x1 | 0;
          x3 ^= u << 13 | u >>> 32 - 13;
          u = x3 + x2 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x4 | 0;
          x6 ^= u << 7 | u >>> 32 - 7;
          u = x6 + x5 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x6 | 0;
          x4 ^= u << 13 | u >>> 32 - 13;
          u = x4 + x7 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x9 | 0;
          x11 ^= u << 7 | u >>> 32 - 7;
          u = x11 + x10 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x11 | 0;
          x9 ^= u << 13 | u >>> 32 - 13;
          u = x9 + x8 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x14 | 0;
          x12 ^= u << 7 | u >>> 32 - 7;
          u = x12 + x15 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x12 | 0;
          x14 ^= u << 13 | u >>> 32 - 13;
          u = x14 + x13 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
        }
        x0 = x0 + j0 | 0;
        x1 = x1 + j1 | 0;
        x2 = x2 + j2 | 0;
        x3 = x3 + j3 | 0;
        x4 = x4 + j4 | 0;
        x5 = x5 + j5 | 0;
        x6 = x6 + j6 | 0;
        x7 = x7 + j7 | 0;
        x8 = x8 + j8 | 0;
        x9 = x9 + j9 | 0;
        x10 = x10 + j10 | 0;
        x11 = x11 + j11 | 0;
        x12 = x12 + j12 | 0;
        x13 = x13 + j13 | 0;
        x14 = x14 + j14 | 0;
        x15 = x15 + j15 | 0;
        o[0] = x0 >>> 0 & 255;
        o[1] = x0 >>> 8 & 255;
        o[2] = x0 >>> 16 & 255;
        o[3] = x0 >>> 24 & 255;
        o[4] = x1 >>> 0 & 255;
        o[5] = x1 >>> 8 & 255;
        o[6] = x1 >>> 16 & 255;
        o[7] = x1 >>> 24 & 255;
        o[8] = x2 >>> 0 & 255;
        o[9] = x2 >>> 8 & 255;
        o[10] = x2 >>> 16 & 255;
        o[11] = x2 >>> 24 & 255;
        o[12] = x3 >>> 0 & 255;
        o[13] = x3 >>> 8 & 255;
        o[14] = x3 >>> 16 & 255;
        o[15] = x3 >>> 24 & 255;
        o[16] = x4 >>> 0 & 255;
        o[17] = x4 >>> 8 & 255;
        o[18] = x4 >>> 16 & 255;
        o[19] = x4 >>> 24 & 255;
        o[20] = x5 >>> 0 & 255;
        o[21] = x5 >>> 8 & 255;
        o[22] = x5 >>> 16 & 255;
        o[23] = x5 >>> 24 & 255;
        o[24] = x6 >>> 0 & 255;
        o[25] = x6 >>> 8 & 255;
        o[26] = x6 >>> 16 & 255;
        o[27] = x6 >>> 24 & 255;
        o[28] = x7 >>> 0 & 255;
        o[29] = x7 >>> 8 & 255;
        o[30] = x7 >>> 16 & 255;
        o[31] = x7 >>> 24 & 255;
        o[32] = x8 >>> 0 & 255;
        o[33] = x8 >>> 8 & 255;
        o[34] = x8 >>> 16 & 255;
        o[35] = x8 >>> 24 & 255;
        o[36] = x9 >>> 0 & 255;
        o[37] = x9 >>> 8 & 255;
        o[38] = x9 >>> 16 & 255;
        o[39] = x9 >>> 24 & 255;
        o[40] = x10 >>> 0 & 255;
        o[41] = x10 >>> 8 & 255;
        o[42] = x10 >>> 16 & 255;
        o[43] = x10 >>> 24 & 255;
        o[44] = x11 >>> 0 & 255;
        o[45] = x11 >>> 8 & 255;
        o[46] = x11 >>> 16 & 255;
        o[47] = x11 >>> 24 & 255;
        o[48] = x12 >>> 0 & 255;
        o[49] = x12 >>> 8 & 255;
        o[50] = x12 >>> 16 & 255;
        o[51] = x12 >>> 24 & 255;
        o[52] = x13 >>> 0 & 255;
        o[53] = x13 >>> 8 & 255;
        o[54] = x13 >>> 16 & 255;
        o[55] = x13 >>> 24 & 255;
        o[56] = x14 >>> 0 & 255;
        o[57] = x14 >>> 8 & 255;
        o[58] = x14 >>> 16 & 255;
        o[59] = x14 >>> 24 & 255;
        o[60] = x15 >>> 0 & 255;
        o[61] = x15 >>> 8 & 255;
        o[62] = x15 >>> 16 & 255;
        o[63] = x15 >>> 24 & 255;
      }
      function core_hsalsa20(o, p, k, c) {
        var j0 = c[0] & 255 | (c[1] & 255) << 8 | (c[2] & 255) << 16 | (c[3] & 255) << 24, j1 = k[0] & 255 | (k[1] & 255) << 8 | (k[2] & 255) << 16 | (k[3] & 255) << 24, j2 = k[4] & 255 | (k[5] & 255) << 8 | (k[6] & 255) << 16 | (k[7] & 255) << 24, j3 = k[8] & 255 | (k[9] & 255) << 8 | (k[10] & 255) << 16 | (k[11] & 255) << 24, j4 = k[12] & 255 | (k[13] & 255) << 8 | (k[14] & 255) << 16 | (k[15] & 255) << 24, j5 = c[4] & 255 | (c[5] & 255) << 8 | (c[6] & 255) << 16 | (c[7] & 255) << 24, j6 = p[0] & 255 | (p[1] & 255) << 8 | (p[2] & 255) << 16 | (p[3] & 255) << 24, j7 = p[4] & 255 | (p[5] & 255) << 8 | (p[6] & 255) << 16 | (p[7] & 255) << 24, j8 = p[8] & 255 | (p[9] & 255) << 8 | (p[10] & 255) << 16 | (p[11] & 255) << 24, j9 = p[12] & 255 | (p[13] & 255) << 8 | (p[14] & 255) << 16 | (p[15] & 255) << 24, j10 = c[8] & 255 | (c[9] & 255) << 8 | (c[10] & 255) << 16 | (c[11] & 255) << 24, j11 = k[16] & 255 | (k[17] & 255) << 8 | (k[18] & 255) << 16 | (k[19] & 255) << 24, j12 = k[20] & 255 | (k[21] & 255) << 8 | (k[22] & 255) << 16 | (k[23] & 255) << 24, j13 = k[24] & 255 | (k[25] & 255) << 8 | (k[26] & 255) << 16 | (k[27] & 255) << 24, j14 = k[28] & 255 | (k[29] & 255) << 8 | (k[30] & 255) << 16 | (k[31] & 255) << 24, j15 = c[12] & 255 | (c[13] & 255) << 8 | (c[14] & 255) << 16 | (c[15] & 255) << 24;
        var x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7, x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14, x15 = j15, u;
        for (var i = 0; i < 20; i += 2) {
          u = x0 + x12 | 0;
          x4 ^= u << 7 | u >>> 32 - 7;
          u = x4 + x0 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x4 | 0;
          x12 ^= u << 13 | u >>> 32 - 13;
          u = x12 + x8 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x1 | 0;
          x9 ^= u << 7 | u >>> 32 - 7;
          u = x9 + x5 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x9 | 0;
          x1 ^= u << 13 | u >>> 32 - 13;
          u = x1 + x13 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x6 | 0;
          x14 ^= u << 7 | u >>> 32 - 7;
          u = x14 + x10 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x14 | 0;
          x6 ^= u << 13 | u >>> 32 - 13;
          u = x6 + x2 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x11 | 0;
          x3 ^= u << 7 | u >>> 32 - 7;
          u = x3 + x15 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x3 | 0;
          x11 ^= u << 13 | u >>> 32 - 13;
          u = x11 + x7 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
          u = x0 + x3 | 0;
          x1 ^= u << 7 | u >>> 32 - 7;
          u = x1 + x0 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x1 | 0;
          x3 ^= u << 13 | u >>> 32 - 13;
          u = x3 + x2 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x4 | 0;
          x6 ^= u << 7 | u >>> 32 - 7;
          u = x6 + x5 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x6 | 0;
          x4 ^= u << 13 | u >>> 32 - 13;
          u = x4 + x7 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x9 | 0;
          x11 ^= u << 7 | u >>> 32 - 7;
          u = x11 + x10 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x11 | 0;
          x9 ^= u << 13 | u >>> 32 - 13;
          u = x9 + x8 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x14 | 0;
          x12 ^= u << 7 | u >>> 32 - 7;
          u = x12 + x15 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x12 | 0;
          x14 ^= u << 13 | u >>> 32 - 13;
          u = x14 + x13 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
        }
        o[0] = x0 >>> 0 & 255;
        o[1] = x0 >>> 8 & 255;
        o[2] = x0 >>> 16 & 255;
        o[3] = x0 >>> 24 & 255;
        o[4] = x5 >>> 0 & 255;
        o[5] = x5 >>> 8 & 255;
        o[6] = x5 >>> 16 & 255;
        o[7] = x5 >>> 24 & 255;
        o[8] = x10 >>> 0 & 255;
        o[9] = x10 >>> 8 & 255;
        o[10] = x10 >>> 16 & 255;
        o[11] = x10 >>> 24 & 255;
        o[12] = x15 >>> 0 & 255;
        o[13] = x15 >>> 8 & 255;
        o[14] = x15 >>> 16 & 255;
        o[15] = x15 >>> 24 & 255;
        o[16] = x6 >>> 0 & 255;
        o[17] = x6 >>> 8 & 255;
        o[18] = x6 >>> 16 & 255;
        o[19] = x6 >>> 24 & 255;
        o[20] = x7 >>> 0 & 255;
        o[21] = x7 >>> 8 & 255;
        o[22] = x7 >>> 16 & 255;
        o[23] = x7 >>> 24 & 255;
        o[24] = x8 >>> 0 & 255;
        o[25] = x8 >>> 8 & 255;
        o[26] = x8 >>> 16 & 255;
        o[27] = x8 >>> 24 & 255;
        o[28] = x9 >>> 0 & 255;
        o[29] = x9 >>> 8 & 255;
        o[30] = x9 >>> 16 & 255;
        o[31] = x9 >>> 24 & 255;
      }
      function crypto_core_salsa20(out, inp, k, c) {
        core_salsa20(out, inp, k, c);
      }
      function crypto_core_hsalsa20(out, inp, k, c) {
        core_hsalsa20(out, inp, k, c);
      }
      var sigma = new Uint8Array([101, 120, 112, 97, 110, 100, 32, 51, 50, 45, 98, 121, 116, 101, 32, 107]);
      function crypto_stream_salsa20_xor(c, cpos, m, mpos, b, n, k) {
        var z = new Uint8Array(16), x = new Uint8Array(64);
        var u, i;
        for (i = 0; i < 16; i++) z[i] = 0;
        for (i = 0; i < 8; i++) z[i] = n[i];
        while (b >= 64) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < 64; i++) c[cpos + i] = m[mpos + i] ^ x[i];
          u = 1;
          for (i = 8; i < 16; i++) {
            u = u + (z[i] & 255) | 0;
            z[i] = u & 255;
            u >>>= 8;
          }
          b -= 64;
          cpos += 64;
          mpos += 64;
        }
        if (b > 0) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < b; i++) c[cpos + i] = m[mpos + i] ^ x[i];
        }
        return 0;
      }
      function crypto_stream_salsa20(c, cpos, b, n, k) {
        var z = new Uint8Array(16), x = new Uint8Array(64);
        var u, i;
        for (i = 0; i < 16; i++) z[i] = 0;
        for (i = 0; i < 8; i++) z[i] = n[i];
        while (b >= 64) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < 64; i++) c[cpos + i] = x[i];
          u = 1;
          for (i = 8; i < 16; i++) {
            u = u + (z[i] & 255) | 0;
            z[i] = u & 255;
            u >>>= 8;
          }
          b -= 64;
          cpos += 64;
        }
        if (b > 0) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < b; i++) c[cpos + i] = x[i];
        }
        return 0;
      }
      function crypto_stream(c, cpos, d, n, k) {
        var s = new Uint8Array(32);
        crypto_core_hsalsa20(s, n, k, sigma);
        var sn = new Uint8Array(8);
        for (var i = 0; i < 8; i++) sn[i] = n[i + 16];
        return crypto_stream_salsa20(c, cpos, d, sn, s);
      }
      function crypto_stream_xor(c, cpos, m, mpos, d, n, k) {
        var s = new Uint8Array(32);
        crypto_core_hsalsa20(s, n, k, sigma);
        var sn = new Uint8Array(8);
        for (var i = 0; i < 8; i++) sn[i] = n[i + 16];
        return crypto_stream_salsa20_xor(c, cpos, m, mpos, d, sn, s);
      }
      var poly1305 = function(key2) {
        this.buffer = new Uint8Array(16);
        this.r = new Uint16Array(10);
        this.h = new Uint16Array(10);
        this.pad = new Uint16Array(8);
        this.leftover = 0;
        this.fin = 0;
        var t0, t1, t2, t3, t4, t5, t6, t7;
        t0 = key2[0] & 255 | (key2[1] & 255) << 8;
        this.r[0] = t0 & 8191;
        t1 = key2[2] & 255 | (key2[3] & 255) << 8;
        this.r[1] = (t0 >>> 13 | t1 << 3) & 8191;
        t2 = key2[4] & 255 | (key2[5] & 255) << 8;
        this.r[2] = (t1 >>> 10 | t2 << 6) & 7939;
        t3 = key2[6] & 255 | (key2[7] & 255) << 8;
        this.r[3] = (t2 >>> 7 | t3 << 9) & 8191;
        t4 = key2[8] & 255 | (key2[9] & 255) << 8;
        this.r[4] = (t3 >>> 4 | t4 << 12) & 255;
        this.r[5] = t4 >>> 1 & 8190;
        t5 = key2[10] & 255 | (key2[11] & 255) << 8;
        this.r[6] = (t4 >>> 14 | t5 << 2) & 8191;
        t6 = key2[12] & 255 | (key2[13] & 255) << 8;
        this.r[7] = (t5 >>> 11 | t6 << 5) & 8065;
        t7 = key2[14] & 255 | (key2[15] & 255) << 8;
        this.r[8] = (t6 >>> 8 | t7 << 8) & 8191;
        this.r[9] = t7 >>> 5 & 127;
        this.pad[0] = key2[16] & 255 | (key2[17] & 255) << 8;
        this.pad[1] = key2[18] & 255 | (key2[19] & 255) << 8;
        this.pad[2] = key2[20] & 255 | (key2[21] & 255) << 8;
        this.pad[3] = key2[22] & 255 | (key2[23] & 255) << 8;
        this.pad[4] = key2[24] & 255 | (key2[25] & 255) << 8;
        this.pad[5] = key2[26] & 255 | (key2[27] & 255) << 8;
        this.pad[6] = key2[28] & 255 | (key2[29] & 255) << 8;
        this.pad[7] = key2[30] & 255 | (key2[31] & 255) << 8;
      };
      poly1305.prototype.blocks = function(m, mpos, bytes) {
        var hibit = this.fin ? 0 : 1 << 11;
        var t0, t1, t2, t3, t4, t5, t6, t7, c;
        var d0, d1, d2, d3, d4, d5, d6, d7, d8, d9;
        var h0 = this.h[0], h1 = this.h[1], h2 = this.h[2], h3 = this.h[3], h4 = this.h[4], h5 = this.h[5], h6 = this.h[6], h7 = this.h[7], h8 = this.h[8], h9 = this.h[9];
        var r0 = this.r[0], r1 = this.r[1], r2 = this.r[2], r3 = this.r[3], r4 = this.r[4], r5 = this.r[5], r6 = this.r[6], r7 = this.r[7], r8 = this.r[8], r9 = this.r[9];
        while (bytes >= 16) {
          t0 = m[mpos + 0] & 255 | (m[mpos + 1] & 255) << 8;
          h0 += t0 & 8191;
          t1 = m[mpos + 2] & 255 | (m[mpos + 3] & 255) << 8;
          h1 += (t0 >>> 13 | t1 << 3) & 8191;
          t2 = m[mpos + 4] & 255 | (m[mpos + 5] & 255) << 8;
          h2 += (t1 >>> 10 | t2 << 6) & 8191;
          t3 = m[mpos + 6] & 255 | (m[mpos + 7] & 255) << 8;
          h3 += (t2 >>> 7 | t3 << 9) & 8191;
          t4 = m[mpos + 8] & 255 | (m[mpos + 9] & 255) << 8;
          h4 += (t3 >>> 4 | t4 << 12) & 8191;
          h5 += t4 >>> 1 & 8191;
          t5 = m[mpos + 10] & 255 | (m[mpos + 11] & 255) << 8;
          h6 += (t4 >>> 14 | t5 << 2) & 8191;
          t6 = m[mpos + 12] & 255 | (m[mpos + 13] & 255) << 8;
          h7 += (t5 >>> 11 | t6 << 5) & 8191;
          t7 = m[mpos + 14] & 255 | (m[mpos + 15] & 255) << 8;
          h8 += (t6 >>> 8 | t7 << 8) & 8191;
          h9 += t7 >>> 5 | hibit;
          c = 0;
          d0 = c;
          d0 += h0 * r0;
          d0 += h1 * (5 * r9);
          d0 += h2 * (5 * r8);
          d0 += h3 * (5 * r7);
          d0 += h4 * (5 * r6);
          c = d0 >>> 13;
          d0 &= 8191;
          d0 += h5 * (5 * r5);
          d0 += h6 * (5 * r4);
          d0 += h7 * (5 * r3);
          d0 += h8 * (5 * r2);
          d0 += h9 * (5 * r1);
          c += d0 >>> 13;
          d0 &= 8191;
          d1 = c;
          d1 += h0 * r1;
          d1 += h1 * r0;
          d1 += h2 * (5 * r9);
          d1 += h3 * (5 * r8);
          d1 += h4 * (5 * r7);
          c = d1 >>> 13;
          d1 &= 8191;
          d1 += h5 * (5 * r6);
          d1 += h6 * (5 * r5);
          d1 += h7 * (5 * r4);
          d1 += h8 * (5 * r3);
          d1 += h9 * (5 * r2);
          c += d1 >>> 13;
          d1 &= 8191;
          d2 = c;
          d2 += h0 * r2;
          d2 += h1 * r1;
          d2 += h2 * r0;
          d2 += h3 * (5 * r9);
          d2 += h4 * (5 * r8);
          c = d2 >>> 13;
          d2 &= 8191;
          d2 += h5 * (5 * r7);
          d2 += h6 * (5 * r6);
          d2 += h7 * (5 * r5);
          d2 += h8 * (5 * r4);
          d2 += h9 * (5 * r3);
          c += d2 >>> 13;
          d2 &= 8191;
          d3 = c;
          d3 += h0 * r3;
          d3 += h1 * r2;
          d3 += h2 * r1;
          d3 += h3 * r0;
          d3 += h4 * (5 * r9);
          c = d3 >>> 13;
          d3 &= 8191;
          d3 += h5 * (5 * r8);
          d3 += h6 * (5 * r7);
          d3 += h7 * (5 * r6);
          d3 += h8 * (5 * r5);
          d3 += h9 * (5 * r4);
          c += d3 >>> 13;
          d3 &= 8191;
          d4 = c;
          d4 += h0 * r4;
          d4 += h1 * r3;
          d4 += h2 * r2;
          d4 += h3 * r1;
          d4 += h4 * r0;
          c = d4 >>> 13;
          d4 &= 8191;
          d4 += h5 * (5 * r9);
          d4 += h6 * (5 * r8);
          d4 += h7 * (5 * r7);
          d4 += h8 * (5 * r6);
          d4 += h9 * (5 * r5);
          c += d4 >>> 13;
          d4 &= 8191;
          d5 = c;
          d5 += h0 * r5;
          d5 += h1 * r4;
          d5 += h2 * r3;
          d5 += h3 * r2;
          d5 += h4 * r1;
          c = d5 >>> 13;
          d5 &= 8191;
          d5 += h5 * r0;
          d5 += h6 * (5 * r9);
          d5 += h7 * (5 * r8);
          d5 += h8 * (5 * r7);
          d5 += h9 * (5 * r6);
          c += d5 >>> 13;
          d5 &= 8191;
          d6 = c;
          d6 += h0 * r6;
          d6 += h1 * r5;
          d6 += h2 * r4;
          d6 += h3 * r3;
          d6 += h4 * r2;
          c = d6 >>> 13;
          d6 &= 8191;
          d6 += h5 * r1;
          d6 += h6 * r0;
          d6 += h7 * (5 * r9);
          d6 += h8 * (5 * r8);
          d6 += h9 * (5 * r7);
          c += d6 >>> 13;
          d6 &= 8191;
          d7 = c;
          d7 += h0 * r7;
          d7 += h1 * r6;
          d7 += h2 * r5;
          d7 += h3 * r4;
          d7 += h4 * r3;
          c = d7 >>> 13;
          d7 &= 8191;
          d7 += h5 * r2;
          d7 += h6 * r1;
          d7 += h7 * r0;
          d7 += h8 * (5 * r9);
          d7 += h9 * (5 * r8);
          c += d7 >>> 13;
          d7 &= 8191;
          d8 = c;
          d8 += h0 * r8;
          d8 += h1 * r7;
          d8 += h2 * r6;
          d8 += h3 * r5;
          d8 += h4 * r4;
          c = d8 >>> 13;
          d8 &= 8191;
          d8 += h5 * r3;
          d8 += h6 * r2;
          d8 += h7 * r1;
          d8 += h8 * r0;
          d8 += h9 * (5 * r9);
          c += d8 >>> 13;
          d8 &= 8191;
          d9 = c;
          d9 += h0 * r9;
          d9 += h1 * r8;
          d9 += h2 * r7;
          d9 += h3 * r6;
          d9 += h4 * r5;
          c = d9 >>> 13;
          d9 &= 8191;
          d9 += h5 * r4;
          d9 += h6 * r3;
          d9 += h7 * r2;
          d9 += h8 * r1;
          d9 += h9 * r0;
          c += d9 >>> 13;
          d9 &= 8191;
          c = (c << 2) + c | 0;
          c = c + d0 | 0;
          d0 = c & 8191;
          c = c >>> 13;
          d1 += c;
          h0 = d0;
          h1 = d1;
          h2 = d2;
          h3 = d3;
          h4 = d4;
          h5 = d5;
          h6 = d6;
          h7 = d7;
          h8 = d8;
          h9 = d9;
          mpos += 16;
          bytes -= 16;
        }
        this.h[0] = h0;
        this.h[1] = h1;
        this.h[2] = h2;
        this.h[3] = h3;
        this.h[4] = h4;
        this.h[5] = h5;
        this.h[6] = h6;
        this.h[7] = h7;
        this.h[8] = h8;
        this.h[9] = h9;
      };
      poly1305.prototype.finish = function(mac, macpos) {
        var g = new Uint16Array(10);
        var c, mask, f, i;
        if (this.leftover) {
          i = this.leftover;
          this.buffer[i++] = 1;
          for (; i < 16; i++) this.buffer[i] = 0;
          this.fin = 1;
          this.blocks(this.buffer, 0, 16);
        }
        c = this.h[1] >>> 13;
        this.h[1] &= 8191;
        for (i = 2; i < 10; i++) {
          this.h[i] += c;
          c = this.h[i] >>> 13;
          this.h[i] &= 8191;
        }
        this.h[0] += c * 5;
        c = this.h[0] >>> 13;
        this.h[0] &= 8191;
        this.h[1] += c;
        c = this.h[1] >>> 13;
        this.h[1] &= 8191;
        this.h[2] += c;
        g[0] = this.h[0] + 5;
        c = g[0] >>> 13;
        g[0] &= 8191;
        for (i = 1; i < 10; i++) {
          g[i] = this.h[i] + c;
          c = g[i] >>> 13;
          g[i] &= 8191;
        }
        g[9] -= 1 << 13;
        mask = (c ^ 1) - 1;
        for (i = 0; i < 10; i++) g[i] &= mask;
        mask = ~mask;
        for (i = 0; i < 10; i++) this.h[i] = this.h[i] & mask | g[i];
        this.h[0] = (this.h[0] | this.h[1] << 13) & 65535;
        this.h[1] = (this.h[1] >>> 3 | this.h[2] << 10) & 65535;
        this.h[2] = (this.h[2] >>> 6 | this.h[3] << 7) & 65535;
        this.h[3] = (this.h[3] >>> 9 | this.h[4] << 4) & 65535;
        this.h[4] = (this.h[4] >>> 12 | this.h[5] << 1 | this.h[6] << 14) & 65535;
        this.h[5] = (this.h[6] >>> 2 | this.h[7] << 11) & 65535;
        this.h[6] = (this.h[7] >>> 5 | this.h[8] << 8) & 65535;
        this.h[7] = (this.h[8] >>> 8 | this.h[9] << 5) & 65535;
        f = this.h[0] + this.pad[0];
        this.h[0] = f & 65535;
        for (i = 1; i < 8; i++) {
          f = (this.h[i] + this.pad[i] | 0) + (f >>> 16) | 0;
          this.h[i] = f & 65535;
        }
        mac[macpos + 0] = this.h[0] >>> 0 & 255;
        mac[macpos + 1] = this.h[0] >>> 8 & 255;
        mac[macpos + 2] = this.h[1] >>> 0 & 255;
        mac[macpos + 3] = this.h[1] >>> 8 & 255;
        mac[macpos + 4] = this.h[2] >>> 0 & 255;
        mac[macpos + 5] = this.h[2] >>> 8 & 255;
        mac[macpos + 6] = this.h[3] >>> 0 & 255;
        mac[macpos + 7] = this.h[3] >>> 8 & 255;
        mac[macpos + 8] = this.h[4] >>> 0 & 255;
        mac[macpos + 9] = this.h[4] >>> 8 & 255;
        mac[macpos + 10] = this.h[5] >>> 0 & 255;
        mac[macpos + 11] = this.h[5] >>> 8 & 255;
        mac[macpos + 12] = this.h[6] >>> 0 & 255;
        mac[macpos + 13] = this.h[6] >>> 8 & 255;
        mac[macpos + 14] = this.h[7] >>> 0 & 255;
        mac[macpos + 15] = this.h[7] >>> 8 & 255;
      };
      poly1305.prototype.update = function(m, mpos, bytes) {
        var i, want;
        if (this.leftover) {
          want = 16 - this.leftover;
          if (want > bytes)
            want = bytes;
          for (i = 0; i < want; i++)
            this.buffer[this.leftover + i] = m[mpos + i];
          bytes -= want;
          mpos += want;
          this.leftover += want;
          if (this.leftover < 16)
            return;
          this.blocks(this.buffer, 0, 16);
          this.leftover = 0;
        }
        if (bytes >= 16) {
          want = bytes - bytes % 16;
          this.blocks(m, mpos, want);
          mpos += want;
          bytes -= want;
        }
        if (bytes) {
          for (i = 0; i < bytes; i++)
            this.buffer[this.leftover + i] = m[mpos + i];
          this.leftover += bytes;
        }
      };
      function crypto_onetimeauth(out, outpos, m, mpos, n, k) {
        var s = new poly1305(k);
        s.update(m, mpos, n);
        s.finish(out, outpos);
        return 0;
      }
      function crypto_onetimeauth_verify(h, hpos, m, mpos, n, k) {
        var x = new Uint8Array(16);
        crypto_onetimeauth(x, 0, m, mpos, n, k);
        return crypto_verify_16(h, hpos, x, 0);
      }
      function crypto_secretbox(c, m, d, n, k) {
        var i;
        if (d < 32) return -1;
        crypto_stream_xor(c, 0, m, 0, d, n, k);
        crypto_onetimeauth(c, 16, c, 32, d - 32, c);
        for (i = 0; i < 16; i++) c[i] = 0;
        return 0;
      }
      function crypto_secretbox_open(m, c, d, n, k) {
        var i;
        var x = new Uint8Array(32);
        if (d < 32) return -1;
        crypto_stream(x, 0, 32, n, k);
        if (crypto_onetimeauth_verify(c, 16, c, 32, d - 32, x) !== 0) return -1;
        crypto_stream_xor(m, 0, c, 0, d, n, k);
        for (i = 0; i < 32; i++) m[i] = 0;
        return 0;
      }
      function set25519(r, a) {
        var i;
        for (i = 0; i < 16; i++) r[i] = a[i] | 0;
      }
      function car25519(o) {
        var i, v, c = 1;
        for (i = 0; i < 16; i++) {
          v = o[i] + c + 65535;
          c = Math.floor(v / 65536);
          o[i] = v - c * 65536;
        }
        o[0] += c - 1 + 37 * (c - 1);
      }
      function sel25519(p, q, b) {
        var t, c = ~(b - 1);
        for (var i = 0; i < 16; i++) {
          t = c & (p[i] ^ q[i]);
          p[i] ^= t;
          q[i] ^= t;
        }
      }
      function pack25519(o, n) {
        var i, j, b;
        var m = gf(), t = gf();
        for (i = 0; i < 16; i++) t[i] = n[i];
        car25519(t);
        car25519(t);
        car25519(t);
        for (j = 0; j < 2; j++) {
          m[0] = t[0] - 65517;
          for (i = 1; i < 15; i++) {
            m[i] = t[i] - 65535 - (m[i - 1] >> 16 & 1);
            m[i - 1] &= 65535;
          }
          m[15] = t[15] - 32767 - (m[14] >> 16 & 1);
          b = m[15] >> 16 & 1;
          m[14] &= 65535;
          sel25519(t, m, 1 - b);
        }
        for (i = 0; i < 16; i++) {
          o[2 * i] = t[i] & 255;
          o[2 * i + 1] = t[i] >> 8;
        }
      }
      function neq25519(a, b) {
        var c = new Uint8Array(32), d = new Uint8Array(32);
        pack25519(c, a);
        pack25519(d, b);
        return crypto_verify_32(c, 0, d, 0);
      }
      function par25519(a) {
        var d = new Uint8Array(32);
        pack25519(d, a);
        return d[0] & 1;
      }
      function unpack25519(o, n) {
        var i;
        for (i = 0; i < 16; i++) o[i] = n[2 * i] + (n[2 * i + 1] << 8);
        o[15] &= 32767;
      }
      function A(o, a, b) {
        for (var i = 0; i < 16; i++) o[i] = a[i] + b[i];
      }
      function Z(o, a, b) {
        for (var i = 0; i < 16; i++) o[i] = a[i] - b[i];
      }
      function M(o, a, b) {
        var v, c, t0 = 0, t1 = 0, t2 = 0, t3 = 0, t4 = 0, t5 = 0, t6 = 0, t7 = 0, t8 = 0, t9 = 0, t10 = 0, t11 = 0, t12 = 0, t13 = 0, t14 = 0, t15 = 0, t16 = 0, t17 = 0, t18 = 0, t19 = 0, t20 = 0, t21 = 0, t22 = 0, t23 = 0, t24 = 0, t25 = 0, t26 = 0, t27 = 0, t28 = 0, t29 = 0, t30 = 0, b0 = b[0], b1 = b[1], b2 = b[2], b3 = b[3], b4 = b[4], b5 = b[5], b6 = b[6], b7 = b[7], b8 = b[8], b9 = b[9], b10 = b[10], b11 = b[11], b12 = b[12], b13 = b[13], b14 = b[14], b15 = b[15];
        v = a[0];
        t0 += v * b0;
        t1 += v * b1;
        t2 += v * b2;
        t3 += v * b3;
        t4 += v * b4;
        t5 += v * b5;
        t6 += v * b6;
        t7 += v * b7;
        t8 += v * b8;
        t9 += v * b9;
        t10 += v * b10;
        t11 += v * b11;
        t12 += v * b12;
        t13 += v * b13;
        t14 += v * b14;
        t15 += v * b15;
        v = a[1];
        t1 += v * b0;
        t2 += v * b1;
        t3 += v * b2;
        t4 += v * b3;
        t5 += v * b4;
        t6 += v * b5;
        t7 += v * b6;
        t8 += v * b7;
        t9 += v * b8;
        t10 += v * b9;
        t11 += v * b10;
        t12 += v * b11;
        t13 += v * b12;
        t14 += v * b13;
        t15 += v * b14;
        t16 += v * b15;
        v = a[2];
        t2 += v * b0;
        t3 += v * b1;
        t4 += v * b2;
        t5 += v * b3;
        t6 += v * b4;
        t7 += v * b5;
        t8 += v * b6;
        t9 += v * b7;
        t10 += v * b8;
        t11 += v * b9;
        t12 += v * b10;
        t13 += v * b11;
        t14 += v * b12;
        t15 += v * b13;
        t16 += v * b14;
        t17 += v * b15;
        v = a[3];
        t3 += v * b0;
        t4 += v * b1;
        t5 += v * b2;
        t6 += v * b3;
        t7 += v * b4;
        t8 += v * b5;
        t9 += v * b6;
        t10 += v * b7;
        t11 += v * b8;
        t12 += v * b9;
        t13 += v * b10;
        t14 += v * b11;
        t15 += v * b12;
        t16 += v * b13;
        t17 += v * b14;
        t18 += v * b15;
        v = a[4];
        t4 += v * b0;
        t5 += v * b1;
        t6 += v * b2;
        t7 += v * b3;
        t8 += v * b4;
        t9 += v * b5;
        t10 += v * b6;
        t11 += v * b7;
        t12 += v * b8;
        t13 += v * b9;
        t14 += v * b10;
        t15 += v * b11;
        t16 += v * b12;
        t17 += v * b13;
        t18 += v * b14;
        t19 += v * b15;
        v = a[5];
        t5 += v * b0;
        t6 += v * b1;
        t7 += v * b2;
        t8 += v * b3;
        t9 += v * b4;
        t10 += v * b5;
        t11 += v * b6;
        t12 += v * b7;
        t13 += v * b8;
        t14 += v * b9;
        t15 += v * b10;
        t16 += v * b11;
        t17 += v * b12;
        t18 += v * b13;
        t19 += v * b14;
        t20 += v * b15;
        v = a[6];
        t6 += v * b0;
        t7 += v * b1;
        t8 += v * b2;
        t9 += v * b3;
        t10 += v * b4;
        t11 += v * b5;
        t12 += v * b6;
        t13 += v * b7;
        t14 += v * b8;
        t15 += v * b9;
        t16 += v * b10;
        t17 += v * b11;
        t18 += v * b12;
        t19 += v * b13;
        t20 += v * b14;
        t21 += v * b15;
        v = a[7];
        t7 += v * b0;
        t8 += v * b1;
        t9 += v * b2;
        t10 += v * b3;
        t11 += v * b4;
        t12 += v * b5;
        t13 += v * b6;
        t14 += v * b7;
        t15 += v * b8;
        t16 += v * b9;
        t17 += v * b10;
        t18 += v * b11;
        t19 += v * b12;
        t20 += v * b13;
        t21 += v * b14;
        t22 += v * b15;
        v = a[8];
        t8 += v * b0;
        t9 += v * b1;
        t10 += v * b2;
        t11 += v * b3;
        t12 += v * b4;
        t13 += v * b5;
        t14 += v * b6;
        t15 += v * b7;
        t16 += v * b8;
        t17 += v * b9;
        t18 += v * b10;
        t19 += v * b11;
        t20 += v * b12;
        t21 += v * b13;
        t22 += v * b14;
        t23 += v * b15;
        v = a[9];
        t9 += v * b0;
        t10 += v * b1;
        t11 += v * b2;
        t12 += v * b3;
        t13 += v * b4;
        t14 += v * b5;
        t15 += v * b6;
        t16 += v * b7;
        t17 += v * b8;
        t18 += v * b9;
        t19 += v * b10;
        t20 += v * b11;
        t21 += v * b12;
        t22 += v * b13;
        t23 += v * b14;
        t24 += v * b15;
        v = a[10];
        t10 += v * b0;
        t11 += v * b1;
        t12 += v * b2;
        t13 += v * b3;
        t14 += v * b4;
        t15 += v * b5;
        t16 += v * b6;
        t17 += v * b7;
        t18 += v * b8;
        t19 += v * b9;
        t20 += v * b10;
        t21 += v * b11;
        t22 += v * b12;
        t23 += v * b13;
        t24 += v * b14;
        t25 += v * b15;
        v = a[11];
        t11 += v * b0;
        t12 += v * b1;
        t13 += v * b2;
        t14 += v * b3;
        t15 += v * b4;
        t16 += v * b5;
        t17 += v * b6;
        t18 += v * b7;
        t19 += v * b8;
        t20 += v * b9;
        t21 += v * b10;
        t22 += v * b11;
        t23 += v * b12;
        t24 += v * b13;
        t25 += v * b14;
        t26 += v * b15;
        v = a[12];
        t12 += v * b0;
        t13 += v * b1;
        t14 += v * b2;
        t15 += v * b3;
        t16 += v * b4;
        t17 += v * b5;
        t18 += v * b6;
        t19 += v * b7;
        t20 += v * b8;
        t21 += v * b9;
        t22 += v * b10;
        t23 += v * b11;
        t24 += v * b12;
        t25 += v * b13;
        t26 += v * b14;
        t27 += v * b15;
        v = a[13];
        t13 += v * b0;
        t14 += v * b1;
        t15 += v * b2;
        t16 += v * b3;
        t17 += v * b4;
        t18 += v * b5;
        t19 += v * b6;
        t20 += v * b7;
        t21 += v * b8;
        t22 += v * b9;
        t23 += v * b10;
        t24 += v * b11;
        t25 += v * b12;
        t26 += v * b13;
        t27 += v * b14;
        t28 += v * b15;
        v = a[14];
        t14 += v * b0;
        t15 += v * b1;
        t16 += v * b2;
        t17 += v * b3;
        t18 += v * b4;
        t19 += v * b5;
        t20 += v * b6;
        t21 += v * b7;
        t22 += v * b8;
        t23 += v * b9;
        t24 += v * b10;
        t25 += v * b11;
        t26 += v * b12;
        t27 += v * b13;
        t28 += v * b14;
        t29 += v * b15;
        v = a[15];
        t15 += v * b0;
        t16 += v * b1;
        t17 += v * b2;
        t18 += v * b3;
        t19 += v * b4;
        t20 += v * b5;
        t21 += v * b6;
        t22 += v * b7;
        t23 += v * b8;
        t24 += v * b9;
        t25 += v * b10;
        t26 += v * b11;
        t27 += v * b12;
        t28 += v * b13;
        t29 += v * b14;
        t30 += v * b15;
        t0 += 38 * t16;
        t1 += 38 * t17;
        t2 += 38 * t18;
        t3 += 38 * t19;
        t4 += 38 * t20;
        t5 += 38 * t21;
        t6 += 38 * t22;
        t7 += 38 * t23;
        t8 += 38 * t24;
        t9 += 38 * t25;
        t10 += 38 * t26;
        t11 += 38 * t27;
        t12 += 38 * t28;
        t13 += 38 * t29;
        t14 += 38 * t30;
        c = 1;
        v = t0 + c + 65535;
        c = Math.floor(v / 65536);
        t0 = v - c * 65536;
        v = t1 + c + 65535;
        c = Math.floor(v / 65536);
        t1 = v - c * 65536;
        v = t2 + c + 65535;
        c = Math.floor(v / 65536);
        t2 = v - c * 65536;
        v = t3 + c + 65535;
        c = Math.floor(v / 65536);
        t3 = v - c * 65536;
        v = t4 + c + 65535;
        c = Math.floor(v / 65536);
        t4 = v - c * 65536;
        v = t5 + c + 65535;
        c = Math.floor(v / 65536);
        t5 = v - c * 65536;
        v = t6 + c + 65535;
        c = Math.floor(v / 65536);
        t6 = v - c * 65536;
        v = t7 + c + 65535;
        c = Math.floor(v / 65536);
        t7 = v - c * 65536;
        v = t8 + c + 65535;
        c = Math.floor(v / 65536);
        t8 = v - c * 65536;
        v = t9 + c + 65535;
        c = Math.floor(v / 65536);
        t9 = v - c * 65536;
        v = t10 + c + 65535;
        c = Math.floor(v / 65536);
        t10 = v - c * 65536;
        v = t11 + c + 65535;
        c = Math.floor(v / 65536);
        t11 = v - c * 65536;
        v = t12 + c + 65535;
        c = Math.floor(v / 65536);
        t12 = v - c * 65536;
        v = t13 + c + 65535;
        c = Math.floor(v / 65536);
        t13 = v - c * 65536;
        v = t14 + c + 65535;
        c = Math.floor(v / 65536);
        t14 = v - c * 65536;
        v = t15 + c + 65535;
        c = Math.floor(v / 65536);
        t15 = v - c * 65536;
        t0 += c - 1 + 37 * (c - 1);
        c = 1;
        v = t0 + c + 65535;
        c = Math.floor(v / 65536);
        t0 = v - c * 65536;
        v = t1 + c + 65535;
        c = Math.floor(v / 65536);
        t1 = v - c * 65536;
        v = t2 + c + 65535;
        c = Math.floor(v / 65536);
        t2 = v - c * 65536;
        v = t3 + c + 65535;
        c = Math.floor(v / 65536);
        t3 = v - c * 65536;
        v = t4 + c + 65535;
        c = Math.floor(v / 65536);
        t4 = v - c * 65536;
        v = t5 + c + 65535;
        c = Math.floor(v / 65536);
        t5 = v - c * 65536;
        v = t6 + c + 65535;
        c = Math.floor(v / 65536);
        t6 = v - c * 65536;
        v = t7 + c + 65535;
        c = Math.floor(v / 65536);
        t7 = v - c * 65536;
        v = t8 + c + 65535;
        c = Math.floor(v / 65536);
        t8 = v - c * 65536;
        v = t9 + c + 65535;
        c = Math.floor(v / 65536);
        t9 = v - c * 65536;
        v = t10 + c + 65535;
        c = Math.floor(v / 65536);
        t10 = v - c * 65536;
        v = t11 + c + 65535;
        c = Math.floor(v / 65536);
        t11 = v - c * 65536;
        v = t12 + c + 65535;
        c = Math.floor(v / 65536);
        t12 = v - c * 65536;
        v = t13 + c + 65535;
        c = Math.floor(v / 65536);
        t13 = v - c * 65536;
        v = t14 + c + 65535;
        c = Math.floor(v / 65536);
        t14 = v - c * 65536;
        v = t15 + c + 65535;
        c = Math.floor(v / 65536);
        t15 = v - c * 65536;
        t0 += c - 1 + 37 * (c - 1);
        o[0] = t0;
        o[1] = t1;
        o[2] = t2;
        o[3] = t3;
        o[4] = t4;
        o[5] = t5;
        o[6] = t6;
        o[7] = t7;
        o[8] = t8;
        o[9] = t9;
        o[10] = t10;
        o[11] = t11;
        o[12] = t12;
        o[13] = t13;
        o[14] = t14;
        o[15] = t15;
      }
      function S(o, a) {
        M(o, a, a);
      }
      function inv25519(o, i) {
        var c = gf();
        var a;
        for (a = 0; a < 16; a++) c[a] = i[a];
        for (a = 253; a >= 0; a--) {
          S(c, c);
          if (a !== 2 && a !== 4) M(c, c, i);
        }
        for (a = 0; a < 16; a++) o[a] = c[a];
      }
      function pow2523(o, i) {
        var c = gf();
        var a;
        for (a = 0; a < 16; a++) c[a] = i[a];
        for (a = 250; a >= 0; a--) {
          S(c, c);
          if (a !== 1) M(c, c, i);
        }
        for (a = 0; a < 16; a++) o[a] = c[a];
      }
      function crypto_scalarmult(q, n, p) {
        var z = new Uint8Array(32);
        var x = new Float64Array(80), r, i;
        var a = gf(), b = gf(), c = gf(), d = gf(), e = gf(), f = gf();
        for (i = 0; i < 31; i++) z[i] = n[i];
        z[31] = n[31] & 127 | 64;
        z[0] &= 248;
        unpack25519(x, p);
        for (i = 0; i < 16; i++) {
          b[i] = x[i];
          d[i] = a[i] = c[i] = 0;
        }
        a[0] = d[0] = 1;
        for (i = 254; i >= 0; --i) {
          r = z[i >>> 3] >>> (i & 7) & 1;
          sel25519(a, b, r);
          sel25519(c, d, r);
          A(e, a, c);
          Z(a, a, c);
          A(c, b, d);
          Z(b, b, d);
          S(d, e);
          S(f, a);
          M(a, c, a);
          M(c, b, e);
          A(e, a, c);
          Z(a, a, c);
          S(b, a);
          Z(c, d, f);
          M(a, c, _121665);
          A(a, a, d);
          M(c, c, a);
          M(a, d, f);
          M(d, b, x);
          S(b, e);
          sel25519(a, b, r);
          sel25519(c, d, r);
        }
        for (i = 0; i < 16; i++) {
          x[i + 16] = a[i];
          x[i + 32] = c[i];
          x[i + 48] = b[i];
          x[i + 64] = d[i];
        }
        var x32 = x.subarray(32);
        var x16 = x.subarray(16);
        inv25519(x32, x32);
        M(x16, x16, x32);
        pack25519(q, x16);
        return 0;
      }
      function crypto_scalarmult_base(q, n) {
        return crypto_scalarmult(q, n, _9);
      }
      function crypto_box_keypair(y, x) {
        randombytes(x, 32);
        return crypto_scalarmult_base(y, x);
      }
      function crypto_box_beforenm(k, y, x) {
        var s = new Uint8Array(32);
        crypto_scalarmult(s, x, y);
        return crypto_core_hsalsa20(k, _0, s, sigma);
      }
      var crypto_box_afternm = crypto_secretbox;
      var crypto_box_open_afternm = crypto_secretbox_open;
      function crypto_box(c, m, d, n, y, x) {
        var k = new Uint8Array(32);
        crypto_box_beforenm(k, y, x);
        return crypto_box_afternm(c, m, d, n, k);
      }
      function crypto_box_open(m, c, d, n, y, x) {
        var k = new Uint8Array(32);
        crypto_box_beforenm(k, y, x);
        return crypto_box_open_afternm(m, c, d, n, k);
      }
      var K = [
        1116352408,
        3609767458,
        1899447441,
        602891725,
        3049323471,
        3964484399,
        3921009573,
        2173295548,
        961987163,
        4081628472,
        1508970993,
        3053834265,
        2453635748,
        2937671579,
        2870763221,
        3664609560,
        3624381080,
        2734883394,
        310598401,
        1164996542,
        607225278,
        1323610764,
        1426881987,
        3590304994,
        1925078388,
        4068182383,
        2162078206,
        991336113,
        2614888103,
        633803317,
        3248222580,
        3479774868,
        3835390401,
        2666613458,
        4022224774,
        944711139,
        264347078,
        2341262773,
        604807628,
        2007800933,
        770255983,
        1495990901,
        1249150122,
        1856431235,
        1555081692,
        3175218132,
        1996064986,
        2198950837,
        2554220882,
        3999719339,
        2821834349,
        766784016,
        2952996808,
        2566594879,
        3210313671,
        3203337956,
        3336571891,
        1034457026,
        3584528711,
        2466948901,
        113926993,
        3758326383,
        338241895,
        168717936,
        666307205,
        1188179964,
        773529912,
        1546045734,
        1294757372,
        1522805485,
        1396182291,
        2643833823,
        1695183700,
        2343527390,
        1986661051,
        1014477480,
        2177026350,
        1206759142,
        2456956037,
        344077627,
        2730485921,
        1290863460,
        2820302411,
        3158454273,
        3259730800,
        3505952657,
        3345764771,
        106217008,
        3516065817,
        3606008344,
        3600352804,
        1432725776,
        4094571909,
        1467031594,
        275423344,
        851169720,
        430227734,
        3100823752,
        506948616,
        1363258195,
        659060556,
        3750685593,
        883997877,
        3785050280,
        958139571,
        3318307427,
        1322822218,
        3812723403,
        1537002063,
        2003034995,
        1747873779,
        3602036899,
        1955562222,
        1575990012,
        2024104815,
        1125592928,
        2227730452,
        2716904306,
        2361852424,
        442776044,
        2428436474,
        593698344,
        2756734187,
        3733110249,
        3204031479,
        2999351573,
        3329325298,
        3815920427,
        3391569614,
        3928383900,
        3515267271,
        566280711,
        3940187606,
        3454069534,
        4118630271,
        4000239992,
        116418474,
        1914138554,
        174292421,
        2731055270,
        289380356,
        3203993006,
        460393269,
        320620315,
        685471733,
        587496836,
        852142971,
        1086792851,
        1017036298,
        365543100,
        1126000580,
        2618297676,
        1288033470,
        3409855158,
        1501505948,
        4234509866,
        1607167915,
        987167468,
        1816402316,
        1246189591
      ];
      function crypto_hashblocks_hl(hh, hl, m, n) {
        var wh = new Int32Array(16), wl = new Int32Array(16), bh0, bh1, bh2, bh3, bh4, bh5, bh6, bh7, bl0, bl1, bl2, bl3, bl4, bl5, bl6, bl7, th, tl, i, j, h, l, a, b, c, d;
        var ah0 = hh[0], ah1 = hh[1], ah2 = hh[2], ah3 = hh[3], ah4 = hh[4], ah5 = hh[5], ah6 = hh[6], ah7 = hh[7], al0 = hl[0], al1 = hl[1], al2 = hl[2], al3 = hl[3], al4 = hl[4], al5 = hl[5], al6 = hl[6], al7 = hl[7];
        var pos = 0;
        while (n >= 128) {
          for (i = 0; i < 16; i++) {
            j = 8 * i + pos;
            wh[i] = m[j + 0] << 24 | m[j + 1] << 16 | m[j + 2] << 8 | m[j + 3];
            wl[i] = m[j + 4] << 24 | m[j + 5] << 16 | m[j + 6] << 8 | m[j + 7];
          }
          for (i = 0; i < 80; i++) {
            bh0 = ah0;
            bh1 = ah1;
            bh2 = ah2;
            bh3 = ah3;
            bh4 = ah4;
            bh5 = ah5;
            bh6 = ah6;
            bh7 = ah7;
            bl0 = al0;
            bl1 = al1;
            bl2 = al2;
            bl3 = al3;
            bl4 = al4;
            bl5 = al5;
            bl6 = al6;
            bl7 = al7;
            h = ah7;
            l = al7;
            a = l & 65535;
            b = l >>> 16;
            c = h & 65535;
            d = h >>> 16;
            h = (ah4 >>> 14 | al4 << 32 - 14) ^ (ah4 >>> 18 | al4 << 32 - 18) ^ (al4 >>> 41 - 32 | ah4 << 32 - (41 - 32));
            l = (al4 >>> 14 | ah4 << 32 - 14) ^ (al4 >>> 18 | ah4 << 32 - 18) ^ (ah4 >>> 41 - 32 | al4 << 32 - (41 - 32));
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = ah4 & ah5 ^ ~ah4 & ah6;
            l = al4 & al5 ^ ~al4 & al6;
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = K[i * 2];
            l = K[i * 2 + 1];
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = wh[i % 16];
            l = wl[i % 16];
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            b += a >>> 16;
            c += b >>> 16;
            d += c >>> 16;
            th = c & 65535 | d << 16;
            tl = a & 65535 | b << 16;
            h = th;
            l = tl;
            a = l & 65535;
            b = l >>> 16;
            c = h & 65535;
            d = h >>> 16;
            h = (ah0 >>> 28 | al0 << 32 - 28) ^ (al0 >>> 34 - 32 | ah0 << 32 - (34 - 32)) ^ (al0 >>> 39 - 32 | ah0 << 32 - (39 - 32));
            l = (al0 >>> 28 | ah0 << 32 - 28) ^ (ah0 >>> 34 - 32 | al0 << 32 - (34 - 32)) ^ (ah0 >>> 39 - 32 | al0 << 32 - (39 - 32));
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = ah0 & ah1 ^ ah0 & ah2 ^ ah1 & ah2;
            l = al0 & al1 ^ al0 & al2 ^ al1 & al2;
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            b += a >>> 16;
            c += b >>> 16;
            d += c >>> 16;
            bh7 = c & 65535 | d << 16;
            bl7 = a & 65535 | b << 16;
            h = bh3;
            l = bl3;
            a = l & 65535;
            b = l >>> 16;
            c = h & 65535;
            d = h >>> 16;
            h = th;
            l = tl;
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            b += a >>> 16;
            c += b >>> 16;
            d += c >>> 16;
            bh3 = c & 65535 | d << 16;
            bl3 = a & 65535 | b << 16;
            ah1 = bh0;
            ah2 = bh1;
            ah3 = bh2;
            ah4 = bh3;
            ah5 = bh4;
            ah6 = bh5;
            ah7 = bh6;
            ah0 = bh7;
            al1 = bl0;
            al2 = bl1;
            al3 = bl2;
            al4 = bl3;
            al5 = bl4;
            al6 = bl5;
            al7 = bl6;
            al0 = bl7;
            if (i % 16 === 15) {
              for (j = 0; j < 16; j++) {
                h = wh[j];
                l = wl[j];
                a = l & 65535;
                b = l >>> 16;
                c = h & 65535;
                d = h >>> 16;
                h = wh[(j + 9) % 16];
                l = wl[(j + 9) % 16];
                a += l & 65535;
                b += l >>> 16;
                c += h & 65535;
                d += h >>> 16;
                th = wh[(j + 1) % 16];
                tl = wl[(j + 1) % 16];
                h = (th >>> 1 | tl << 32 - 1) ^ (th >>> 8 | tl << 32 - 8) ^ th >>> 7;
                l = (tl >>> 1 | th << 32 - 1) ^ (tl >>> 8 | th << 32 - 8) ^ (tl >>> 7 | th << 32 - 7);
                a += l & 65535;
                b += l >>> 16;
                c += h & 65535;
                d += h >>> 16;
                th = wh[(j + 14) % 16];
                tl = wl[(j + 14) % 16];
                h = (th >>> 19 | tl << 32 - 19) ^ (tl >>> 61 - 32 | th << 32 - (61 - 32)) ^ th >>> 6;
                l = (tl >>> 19 | th << 32 - 19) ^ (th >>> 61 - 32 | tl << 32 - (61 - 32)) ^ (tl >>> 6 | th << 32 - 6);
                a += l & 65535;
                b += l >>> 16;
                c += h & 65535;
                d += h >>> 16;
                b += a >>> 16;
                c += b >>> 16;
                d += c >>> 16;
                wh[j] = c & 65535 | d << 16;
                wl[j] = a & 65535 | b << 16;
              }
            }
          }
          h = ah0;
          l = al0;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[0];
          l = hl[0];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[0] = ah0 = c & 65535 | d << 16;
          hl[0] = al0 = a & 65535 | b << 16;
          h = ah1;
          l = al1;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[1];
          l = hl[1];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[1] = ah1 = c & 65535 | d << 16;
          hl[1] = al1 = a & 65535 | b << 16;
          h = ah2;
          l = al2;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[2];
          l = hl[2];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[2] = ah2 = c & 65535 | d << 16;
          hl[2] = al2 = a & 65535 | b << 16;
          h = ah3;
          l = al3;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[3];
          l = hl[3];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[3] = ah3 = c & 65535 | d << 16;
          hl[3] = al3 = a & 65535 | b << 16;
          h = ah4;
          l = al4;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[4];
          l = hl[4];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[4] = ah4 = c & 65535 | d << 16;
          hl[4] = al4 = a & 65535 | b << 16;
          h = ah5;
          l = al5;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[5];
          l = hl[5];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[5] = ah5 = c & 65535 | d << 16;
          hl[5] = al5 = a & 65535 | b << 16;
          h = ah6;
          l = al6;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[6];
          l = hl[6];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[6] = ah6 = c & 65535 | d << 16;
          hl[6] = al6 = a & 65535 | b << 16;
          h = ah7;
          l = al7;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[7];
          l = hl[7];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[7] = ah7 = c & 65535 | d << 16;
          hl[7] = al7 = a & 65535 | b << 16;
          pos += 128;
          n -= 128;
        }
        return n;
      }
      function crypto_hash(out, m, n) {
        var hh = new Int32Array(8), hl = new Int32Array(8), x = new Uint8Array(256), i, b = n;
        hh[0] = 1779033703;
        hh[1] = 3144134277;
        hh[2] = 1013904242;
        hh[3] = 2773480762;
        hh[4] = 1359893119;
        hh[5] = 2600822924;
        hh[6] = 528734635;
        hh[7] = 1541459225;
        hl[0] = 4089235720;
        hl[1] = 2227873595;
        hl[2] = 4271175723;
        hl[3] = 1595750129;
        hl[4] = 2917565137;
        hl[5] = 725511199;
        hl[6] = 4215389547;
        hl[7] = 327033209;
        crypto_hashblocks_hl(hh, hl, m, n);
        n %= 128;
        for (i = 0; i < n; i++) x[i] = m[b - n + i];
        x[n] = 128;
        n = 256 - 128 * (n < 112 ? 1 : 0);
        x[n - 9] = 0;
        ts64(x, n - 8, b / 536870912 | 0, b << 3);
        crypto_hashblocks_hl(hh, hl, x, n);
        for (i = 0; i < 8; i++) ts64(out, 8 * i, hh[i], hl[i]);
        return 0;
      }
      function add(p, q) {
        var a = gf(), b = gf(), c = gf(), d = gf(), e = gf(), f = gf(), g = gf(), h = gf(), t = gf();
        Z(a, p[1], p[0]);
        Z(t, q[1], q[0]);
        M(a, a, t);
        A(b, p[0], p[1]);
        A(t, q[0], q[1]);
        M(b, b, t);
        M(c, p[3], q[3]);
        M(c, c, D2);
        M(d, p[2], q[2]);
        A(d, d, d);
        Z(e, b, a);
        Z(f, d, c);
        A(g, d, c);
        A(h, b, a);
        M(p[0], e, f);
        M(p[1], h, g);
        M(p[2], g, f);
        M(p[3], e, h);
      }
      function cswap(p, q, b) {
        var i;
        for (i = 0; i < 4; i++) {
          sel25519(p[i], q[i], b);
        }
      }
      function pack(r, p) {
        var tx = gf(), ty = gf(), zi = gf();
        inv25519(zi, p[2]);
        M(tx, p[0], zi);
        M(ty, p[1], zi);
        pack25519(r, ty);
        r[31] ^= par25519(tx) << 7;
      }
      function scalarmult(p, q, s) {
        var b, i;
        set25519(p[0], gf0);
        set25519(p[1], gf1);
        set25519(p[2], gf1);
        set25519(p[3], gf0);
        for (i = 255; i >= 0; --i) {
          b = s[i / 8 | 0] >> (i & 7) & 1;
          cswap(p, q, b);
          add(q, p);
          add(p, p);
          cswap(p, q, b);
        }
      }
      function scalarbase(p, s) {
        var q = [gf(), gf(), gf(), gf()];
        set25519(q[0], X);
        set25519(q[1], Y);
        set25519(q[2], gf1);
        M(q[3], X, Y);
        scalarmult(p, q, s);
      }
      function crypto_sign_keypair(pk, sk, seeded) {
        var d = new Uint8Array(64);
        var p = [gf(), gf(), gf(), gf()];
        var i;
        if (!seeded) randombytes(sk, 32);
        crypto_hash(d, sk, 32);
        d[0] &= 248;
        d[31] &= 127;
        d[31] |= 64;
        scalarbase(p, d);
        pack(pk, p);
        for (i = 0; i < 32; i++) sk[i + 32] = pk[i];
        return 0;
      }
      var L = new Float64Array([237, 211, 245, 92, 26, 99, 18, 88, 214, 156, 247, 162, 222, 249, 222, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16]);
      function modL(r, x) {
        var carry, i, j, k;
        for (i = 63; i >= 32; --i) {
          carry = 0;
          for (j = i - 32, k = i - 12; j < k; ++j) {
            x[j] += carry - 16 * x[i] * L[j - (i - 32)];
            carry = Math.floor((x[j] + 128) / 256);
            x[j] -= carry * 256;
          }
          x[j] += carry;
          x[i] = 0;
        }
        carry = 0;
        for (j = 0; j < 32; j++) {
          x[j] += carry - (x[31] >> 4) * L[j];
          carry = x[j] >> 8;
          x[j] &= 255;
        }
        for (j = 0; j < 32; j++) x[j] -= carry * L[j];
        for (i = 0; i < 32; i++) {
          x[i + 1] += x[i] >> 8;
          r[i] = x[i] & 255;
        }
      }
      function reduce(r) {
        var x = new Float64Array(64), i;
        for (i = 0; i < 64; i++) x[i] = r[i];
        for (i = 0; i < 64; i++) r[i] = 0;
        modL(r, x);
      }
      function crypto_sign(sm, m, n, sk) {
        var d = new Uint8Array(64), h = new Uint8Array(64), r = new Uint8Array(64);
        var i, j, x = new Float64Array(64);
        var p = [gf(), gf(), gf(), gf()];
        crypto_hash(d, sk, 32);
        d[0] &= 248;
        d[31] &= 127;
        d[31] |= 64;
        var smlen = n + 64;
        for (i = 0; i < n; i++) sm[64 + i] = m[i];
        for (i = 0; i < 32; i++) sm[32 + i] = d[32 + i];
        crypto_hash(r, sm.subarray(32), n + 32);
        reduce(r);
        scalarbase(p, r);
        pack(sm, p);
        for (i = 32; i < 64; i++) sm[i] = sk[i];
        crypto_hash(h, sm, n + 64);
        reduce(h);
        for (i = 0; i < 64; i++) x[i] = 0;
        for (i = 0; i < 32; i++) x[i] = r[i];
        for (i = 0; i < 32; i++) {
          for (j = 0; j < 32; j++) {
            x[i + j] += h[i] * d[j];
          }
        }
        modL(sm.subarray(32), x);
        return smlen;
      }
      function unpackneg(r, p) {
        var t = gf(), chk = gf(), num = gf(), den = gf(), den2 = gf(), den4 = gf(), den6 = gf();
        set25519(r[2], gf1);
        unpack25519(r[1], p);
        S(num, r[1]);
        M(den, num, D);
        Z(num, num, r[2]);
        A(den, r[2], den);
        S(den2, den);
        S(den4, den2);
        M(den6, den4, den2);
        M(t, den6, num);
        M(t, t, den);
        pow2523(t, t);
        M(t, t, num);
        M(t, t, den);
        M(t, t, den);
        M(r[0], t, den);
        S(chk, r[0]);
        M(chk, chk, den);
        if (neq25519(chk, num)) M(r[0], r[0], I);
        S(chk, r[0]);
        M(chk, chk, den);
        if (neq25519(chk, num)) return -1;
        if (par25519(r[0]) === p[31] >> 7) Z(r[0], gf0, r[0]);
        M(r[3], r[0], r[1]);
        return 0;
      }
      function crypto_sign_open(m, sm, n, pk) {
        var i;
        var t = new Uint8Array(32), h = new Uint8Array(64);
        var p = [gf(), gf(), gf(), gf()], q = [gf(), gf(), gf(), gf()];
        if (n < 64) return -1;
        if (unpackneg(q, pk)) return -1;
        for (i = 0; i < n; i++) m[i] = sm[i];
        for (i = 0; i < 32; i++) m[i + 32] = pk[i];
        crypto_hash(h, m, n);
        reduce(h);
        scalarmult(p, q, h);
        scalarbase(q, sm.subarray(32));
        add(p, q);
        pack(t, p);
        n -= 64;
        if (crypto_verify_32(sm, 0, t, 0)) {
          for (i = 0; i < n; i++) m[i] = 0;
          return -1;
        }
        for (i = 0; i < n; i++) m[i] = sm[i + 64];
        return n;
      }
      var crypto_secretbox_KEYBYTES = 32, crypto_secretbox_NONCEBYTES = 24, crypto_secretbox_ZEROBYTES = 32, crypto_secretbox_BOXZEROBYTES = 16, crypto_scalarmult_BYTES = 32, crypto_scalarmult_SCALARBYTES = 32, crypto_box_PUBLICKEYBYTES = 32, crypto_box_SECRETKEYBYTES = 32, crypto_box_BEFORENMBYTES = 32, crypto_box_NONCEBYTES = crypto_secretbox_NONCEBYTES, crypto_box_ZEROBYTES = crypto_secretbox_ZEROBYTES, crypto_box_BOXZEROBYTES = crypto_secretbox_BOXZEROBYTES, crypto_sign_BYTES = 64, crypto_sign_PUBLICKEYBYTES = 32, crypto_sign_SECRETKEYBYTES = 64, crypto_sign_SEEDBYTES = 32, crypto_hash_BYTES = 64;
      nacl2.lowlevel = {
        crypto_core_hsalsa20,
        crypto_stream_xor,
        crypto_stream,
        crypto_stream_salsa20_xor,
        crypto_stream_salsa20,
        crypto_onetimeauth,
        crypto_onetimeauth_verify,
        crypto_verify_16,
        crypto_verify_32,
        crypto_secretbox,
        crypto_secretbox_open,
        crypto_scalarmult,
        crypto_scalarmult_base,
        crypto_box_beforenm,
        crypto_box_afternm,
        crypto_box,
        crypto_box_open,
        crypto_box_keypair,
        crypto_hash,
        crypto_sign,
        crypto_sign_keypair,
        crypto_sign_open,
        crypto_secretbox_KEYBYTES,
        crypto_secretbox_NONCEBYTES,
        crypto_secretbox_ZEROBYTES,
        crypto_secretbox_BOXZEROBYTES,
        crypto_scalarmult_BYTES,
        crypto_scalarmult_SCALARBYTES,
        crypto_box_PUBLICKEYBYTES,
        crypto_box_SECRETKEYBYTES,
        crypto_box_BEFORENMBYTES,
        crypto_box_NONCEBYTES,
        crypto_box_ZEROBYTES,
        crypto_box_BOXZEROBYTES,
        crypto_sign_BYTES,
        crypto_sign_PUBLICKEYBYTES,
        crypto_sign_SECRETKEYBYTES,
        crypto_sign_SEEDBYTES,
        crypto_hash_BYTES,
        gf,
        D,
        L,
        pack25519,
        unpack25519,
        M,
        A,
        S,
        Z,
        pow2523,
        add,
        set25519,
        modL,
        scalarmult,
        scalarbase
      };
      function checkLengths(k, n) {
        if (k.length !== crypto_secretbox_KEYBYTES) throw new Error("bad key size");
        if (n.length !== crypto_secretbox_NONCEBYTES) throw new Error("bad nonce size");
      }
      function checkBoxLengths(pk, sk) {
        if (pk.length !== crypto_box_PUBLICKEYBYTES) throw new Error("bad public key size");
        if (sk.length !== crypto_box_SECRETKEYBYTES) throw new Error("bad secret key size");
      }
      function checkArrayTypes() {
        for (var i = 0; i < arguments.length; i++) {
          if (!(arguments[i] instanceof Uint8Array))
            throw new TypeError("unexpected type, use Uint8Array");
        }
      }
      function cleanup(arr) {
        for (var i = 0; i < arr.length; i++) arr[i] = 0;
      }
      nacl2.randomBytes = function(n) {
        var b = new Uint8Array(n);
        randombytes(b, n);
        return b;
      };
      nacl2.secretbox = function(msg, nonce, key2) {
        checkArrayTypes(msg, nonce, key2);
        checkLengths(key2, nonce);
        var m = new Uint8Array(crypto_secretbox_ZEROBYTES + msg.length);
        var c = new Uint8Array(m.length);
        for (var i = 0; i < msg.length; i++) m[i + crypto_secretbox_ZEROBYTES] = msg[i];
        crypto_secretbox(c, m, m.length, nonce, key2);
        return c.subarray(crypto_secretbox_BOXZEROBYTES);
      };
      nacl2.secretbox.open = function(box, nonce, key2) {
        checkArrayTypes(box, nonce, key2);
        checkLengths(key2, nonce);
        var c = new Uint8Array(crypto_secretbox_BOXZEROBYTES + box.length);
        var m = new Uint8Array(c.length);
        for (var i = 0; i < box.length; i++) c[i + crypto_secretbox_BOXZEROBYTES] = box[i];
        if (c.length < 32) return null;
        if (crypto_secretbox_open(m, c, c.length, nonce, key2) !== 0) return null;
        return m.subarray(crypto_secretbox_ZEROBYTES);
      };
      nacl2.secretbox.keyLength = crypto_secretbox_KEYBYTES;
      nacl2.secretbox.nonceLength = crypto_secretbox_NONCEBYTES;
      nacl2.secretbox.overheadLength = crypto_secretbox_BOXZEROBYTES;
      nacl2.scalarMult = function(n, p) {
        checkArrayTypes(n, p);
        if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error("bad n size");
        if (p.length !== crypto_scalarmult_BYTES) throw new Error("bad p size");
        var q = new Uint8Array(crypto_scalarmult_BYTES);
        crypto_scalarmult(q, n, p);
        return q;
      };
      nacl2.scalarMult.base = function(n) {
        checkArrayTypes(n);
        if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error("bad n size");
        var q = new Uint8Array(crypto_scalarmult_BYTES);
        crypto_scalarmult_base(q, n);
        return q;
      };
      nacl2.scalarMult.scalarLength = crypto_scalarmult_SCALARBYTES;
      nacl2.scalarMult.groupElementLength = crypto_scalarmult_BYTES;
      nacl2.box = function(msg, nonce, publicKey, secretKey) {
        var k = nacl2.box.before(publicKey, secretKey);
        return nacl2.secretbox(msg, nonce, k);
      };
      nacl2.box.before = function(publicKey, secretKey) {
        checkArrayTypes(publicKey, secretKey);
        checkBoxLengths(publicKey, secretKey);
        var k = new Uint8Array(crypto_box_BEFORENMBYTES);
        crypto_box_beforenm(k, publicKey, secretKey);
        return k;
      };
      nacl2.box.after = nacl2.secretbox;
      nacl2.box.open = function(msg, nonce, publicKey, secretKey) {
        var k = nacl2.box.before(publicKey, secretKey);
        return nacl2.secretbox.open(msg, nonce, k);
      };
      nacl2.box.open.after = nacl2.secretbox.open;
      nacl2.box.keyPair = function() {
        var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
        var sk = new Uint8Array(crypto_box_SECRETKEYBYTES);
        crypto_box_keypair(pk, sk);
        return { publicKey: pk, secretKey: sk };
      };
      nacl2.box.keyPair.fromSecretKey = function(secretKey) {
        checkArrayTypes(secretKey);
        if (secretKey.length !== crypto_box_SECRETKEYBYTES)
          throw new Error("bad secret key size");
        var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
        crypto_scalarmult_base(pk, secretKey);
        return { publicKey: pk, secretKey: new Uint8Array(secretKey) };
      };
      nacl2.box.publicKeyLength = crypto_box_PUBLICKEYBYTES;
      nacl2.box.secretKeyLength = crypto_box_SECRETKEYBYTES;
      nacl2.box.sharedKeyLength = crypto_box_BEFORENMBYTES;
      nacl2.box.nonceLength = crypto_box_NONCEBYTES;
      nacl2.box.overheadLength = nacl2.secretbox.overheadLength;
      nacl2.sign = function(msg, secretKey) {
        checkArrayTypes(msg, secretKey);
        if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
          throw new Error("bad secret key size");
        var signedMsg = new Uint8Array(crypto_sign_BYTES + msg.length);
        crypto_sign(signedMsg, msg, msg.length, secretKey);
        return signedMsg;
      };
      nacl2.sign.open = function(signedMsg, publicKey) {
        checkArrayTypes(signedMsg, publicKey);
        if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
          throw new Error("bad public key size");
        var tmp = new Uint8Array(signedMsg.length);
        var mlen = crypto_sign_open(tmp, signedMsg, signedMsg.length, publicKey);
        if (mlen < 0) return null;
        var m = new Uint8Array(mlen);
        for (var i = 0; i < m.length; i++) m[i] = tmp[i];
        return m;
      };
      nacl2.sign.detached = function(msg, secretKey) {
        var signedMsg = nacl2.sign(msg, secretKey);
        var sig = new Uint8Array(crypto_sign_BYTES);
        for (var i = 0; i < sig.length; i++) sig[i] = signedMsg[i];
        return sig;
      };
      nacl2.sign.detached.verify = function(msg, sig, publicKey) {
        checkArrayTypes(msg, sig, publicKey);
        if (sig.length !== crypto_sign_BYTES)
          throw new Error("bad signature size");
        if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
          throw new Error("bad public key size");
        var sm = new Uint8Array(crypto_sign_BYTES + msg.length);
        var m = new Uint8Array(crypto_sign_BYTES + msg.length);
        var i;
        for (i = 0; i < crypto_sign_BYTES; i++) sm[i] = sig[i];
        for (i = 0; i < msg.length; i++) sm[i + crypto_sign_BYTES] = msg[i];
        return crypto_sign_open(m, sm, sm.length, publicKey) >= 0;
      };
      nacl2.sign.keyPair = function() {
        var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
        var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
        crypto_sign_keypair(pk, sk);
        return { publicKey: pk, secretKey: sk };
      };
      nacl2.sign.keyPair.fromSecretKey = function(secretKey) {
        checkArrayTypes(secretKey);
        if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
          throw new Error("bad secret key size");
        var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
        for (var i = 0; i < pk.length; i++) pk[i] = secretKey[32 + i];
        return { publicKey: pk, secretKey: new Uint8Array(secretKey) };
      };
      nacl2.sign.keyPair.fromSeed = function(seed) {
        checkArrayTypes(seed);
        if (seed.length !== crypto_sign_SEEDBYTES)
          throw new Error("bad seed size");
        var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
        var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
        for (var i = 0; i < 32; i++) sk[i] = seed[i];
        crypto_sign_keypair(pk, sk, true);
        return { publicKey: pk, secretKey: sk };
      };
      nacl2.sign.publicKeyLength = crypto_sign_PUBLICKEYBYTES;
      nacl2.sign.secretKeyLength = crypto_sign_SECRETKEYBYTES;
      nacl2.sign.seedLength = crypto_sign_SEEDBYTES;
      nacl2.sign.signatureLength = crypto_sign_BYTES;
      nacl2.hash = function(msg) {
        checkArrayTypes(msg);
        var h = new Uint8Array(crypto_hash_BYTES);
        crypto_hash(h, msg, msg.length);
        return h;
      };
      nacl2.hash.hashLength = crypto_hash_BYTES;
      nacl2.verify = function(x, y) {
        checkArrayTypes(x, y);
        if (x.length === 0 || y.length === 0) return false;
        if (x.length !== y.length) return false;
        return vn(x, 0, y, 0, x.length) === 0 ? true : false;
      };
      nacl2.setPRNG = function(fn) {
        randombytes = fn;
      };
      (function() {
        var crypto2 = typeof self !== "undefined" ? self.crypto || self.msCrypto : null;
        if (crypto2 && crypto2.getRandomValues) {
          var QUOTA = 65536;
          nacl2.setPRNG(function(x, n) {
            var i, v = new Uint8Array(n);
            for (i = 0; i < n; i += QUOTA) {
              crypto2.getRandomValues(v.subarray(i, i + Math.min(n - i, QUOTA)));
            }
            for (i = 0; i < n; i++) x[i] = v[i];
            cleanup(v);
          });
        } else if (typeof require !== "undefined") {
          crypto2 = require("crypto");
          if (crypto2 && crypto2.randomBytes) {
            nacl2.setPRNG(function(x, n) {
              var i, v = crypto2.randomBytes(n);
              for (i = 0; i < n; i++) x[i] = v[i];
              cleanup(v);
            });
          }
        }
      })();
    })(typeof module2 !== "undefined" && module2.exports ? module2.exports : self.nacl = self.nacl || {});
  }
});

// node_modules/blakejs/util.js
var require_util = __commonJS({
  "node_modules/blakejs/util.js"(exports2, module2) {
    var ERROR_MSG_INPUT = "Input must be an string, Buffer or Uint8Array";
    function normalizeInput(input) {
      let ret;
      if (input instanceof Uint8Array) {
        ret = input;
      } else if (typeof input === "string") {
        const encoder = new TextEncoder();
        ret = encoder.encode(input);
      } else {
        throw new Error(ERROR_MSG_INPUT);
      }
      return ret;
    }
    function toHex(bytes) {
      return Array.prototype.map.call(bytes, function(n) {
        return (n < 16 ? "0" : "") + n.toString(16);
      }).join("");
    }
    function uint32ToHex(val) {
      return (4294967296 + val).toString(16).substring(1);
    }
    function debugPrint(label, arr, size) {
      let msg = "\n" + label + " = ";
      for (let i = 0; i < arr.length; i += 2) {
        if (size === 32) {
          msg += uint32ToHex(arr[i]).toUpperCase();
          msg += " ";
          msg += uint32ToHex(arr[i + 1]).toUpperCase();
        } else if (size === 64) {
          msg += uint32ToHex(arr[i + 1]).toUpperCase();
          msg += uint32ToHex(arr[i]).toUpperCase();
        } else throw new Error("Invalid size " + size);
        if (i % 6 === 4) {
          msg += "\n" + new Array(label.length + 4).join(" ");
        } else if (i < arr.length - 2) {
          msg += " ";
        }
      }
      console.log(msg);
    }
    function testSpeed(hashFn, N, M) {
      let startMs = (/* @__PURE__ */ new Date()).getTime();
      const input = new Uint8Array(N);
      for (let i = 0; i < N; i++) {
        input[i] = i % 256;
      }
      const genMs = (/* @__PURE__ */ new Date()).getTime();
      console.log("Generated random input in " + (genMs - startMs) + "ms");
      startMs = genMs;
      for (let i = 0; i < M; i++) {
        const hashHex = hashFn(input);
        const hashMs = (/* @__PURE__ */ new Date()).getTime();
        const ms = hashMs - startMs;
        startMs = hashMs;
        console.log("Hashed in " + ms + "ms: " + hashHex.substring(0, 20) + "...");
        console.log(
          Math.round(N / (1 << 20) / (ms / 1e3) * 100) / 100 + " MB PER SECOND"
        );
      }
    }
    module2.exports = {
      normalizeInput,
      toHex,
      debugPrint,
      testSpeed
    };
  }
});

// node_modules/blakejs/blake2b.js
var require_blake2b = __commonJS({
  "node_modules/blakejs/blake2b.js"(exports2, module2) {
    var util = require_util();
    function ADD64AA(v2, a, b) {
      const o0 = v2[a] + v2[b];
      let o1 = v2[a + 1] + v2[b + 1];
      if (o0 >= 4294967296) {
        o1++;
      }
      v2[a] = o0;
      v2[a + 1] = o1;
    }
    function ADD64AC(v2, a, b0, b1) {
      let o0 = v2[a] + b0;
      if (b0 < 0) {
        o0 += 4294967296;
      }
      let o1 = v2[a + 1] + b1;
      if (o0 >= 4294967296) {
        o1++;
      }
      v2[a] = o0;
      v2[a + 1] = o1;
    }
    function B2B_GET32(arr, i) {
      return arr[i] ^ arr[i + 1] << 8 ^ arr[i + 2] << 16 ^ arr[i + 3] << 24;
    }
    function B2B_G(a, b, c, d, ix, iy) {
      const x0 = m[ix];
      const x1 = m[ix + 1];
      const y0 = m[iy];
      const y1 = m[iy + 1];
      ADD64AA(v, a, b);
      ADD64AC(v, a, x0, x1);
      let xor0 = v[d] ^ v[a];
      let xor1 = v[d + 1] ^ v[a + 1];
      v[d] = xor1;
      v[d + 1] = xor0;
      ADD64AA(v, c, d);
      xor0 = v[b] ^ v[c];
      xor1 = v[b + 1] ^ v[c + 1];
      v[b] = xor0 >>> 24 ^ xor1 << 8;
      v[b + 1] = xor1 >>> 24 ^ xor0 << 8;
      ADD64AA(v, a, b);
      ADD64AC(v, a, y0, y1);
      xor0 = v[d] ^ v[a];
      xor1 = v[d + 1] ^ v[a + 1];
      v[d] = xor0 >>> 16 ^ xor1 << 16;
      v[d + 1] = xor1 >>> 16 ^ xor0 << 16;
      ADD64AA(v, c, d);
      xor0 = v[b] ^ v[c];
      xor1 = v[b + 1] ^ v[c + 1];
      v[b] = xor1 >>> 31 ^ xor0 << 1;
      v[b + 1] = xor0 >>> 31 ^ xor1 << 1;
    }
    var BLAKE2B_IV32 = new Uint32Array([
      4089235720,
      1779033703,
      2227873595,
      3144134277,
      4271175723,
      1013904242,
      1595750129,
      2773480762,
      2917565137,
      1359893119,
      725511199,
      2600822924,
      4215389547,
      528734635,
      327033209,
      1541459225
    ]);
    var SIGMA8 = [
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      10,
      11,
      12,
      13,
      14,
      15,
      14,
      10,
      4,
      8,
      9,
      15,
      13,
      6,
      1,
      12,
      0,
      2,
      11,
      7,
      5,
      3,
      11,
      8,
      12,
      0,
      5,
      2,
      15,
      13,
      10,
      14,
      3,
      6,
      7,
      1,
      9,
      4,
      7,
      9,
      3,
      1,
      13,
      12,
      11,
      14,
      2,
      6,
      5,
      10,
      4,
      0,
      15,
      8,
      9,
      0,
      5,
      7,
      2,
      4,
      10,
      15,
      14,
      1,
      11,
      12,
      6,
      8,
      3,
      13,
      2,
      12,
      6,
      10,
      0,
      11,
      8,
      3,
      4,
      13,
      7,
      5,
      15,
      14,
      1,
      9,
      12,
      5,
      1,
      15,
      14,
      13,
      4,
      10,
      0,
      7,
      6,
      3,
      9,
      2,
      8,
      11,
      13,
      11,
      7,
      14,
      12,
      1,
      3,
      9,
      5,
      0,
      15,
      4,
      8,
      6,
      2,
      10,
      6,
      15,
      14,
      9,
      11,
      3,
      0,
      8,
      12,
      2,
      13,
      7,
      1,
      4,
      10,
      5,
      10,
      2,
      8,
      4,
      7,
      6,
      1,
      5,
      15,
      11,
      9,
      14,
      3,
      12,
      13,
      0,
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      10,
      11,
      12,
      13,
      14,
      15,
      14,
      10,
      4,
      8,
      9,
      15,
      13,
      6,
      1,
      12,
      0,
      2,
      11,
      7,
      5,
      3
    ];
    var SIGMA82 = new Uint8Array(
      SIGMA8.map(function(x) {
        return x * 2;
      })
    );
    var v = new Uint32Array(32);
    var m = new Uint32Array(32);
    function blake2bCompress(ctx, last) {
      let i = 0;
      for (i = 0; i < 16; i++) {
        v[i] = ctx.h[i];
        v[i + 16] = BLAKE2B_IV32[i];
      }
      v[24] = v[24] ^ ctx.t;
      v[25] = v[25] ^ ctx.t / 4294967296;
      if (last) {
        v[28] = ~v[28];
        v[29] = ~v[29];
      }
      for (i = 0; i < 32; i++) {
        m[i] = B2B_GET32(ctx.b, 4 * i);
      }
      for (i = 0; i < 12; i++) {
        B2B_G(0, 8, 16, 24, SIGMA82[i * 16 + 0], SIGMA82[i * 16 + 1]);
        B2B_G(2, 10, 18, 26, SIGMA82[i * 16 + 2], SIGMA82[i * 16 + 3]);
        B2B_G(4, 12, 20, 28, SIGMA82[i * 16 + 4], SIGMA82[i * 16 + 5]);
        B2B_G(6, 14, 22, 30, SIGMA82[i * 16 + 6], SIGMA82[i * 16 + 7]);
        B2B_G(0, 10, 20, 30, SIGMA82[i * 16 + 8], SIGMA82[i * 16 + 9]);
        B2B_G(2, 12, 22, 24, SIGMA82[i * 16 + 10], SIGMA82[i * 16 + 11]);
        B2B_G(4, 14, 16, 26, SIGMA82[i * 16 + 12], SIGMA82[i * 16 + 13]);
        B2B_G(6, 8, 18, 28, SIGMA82[i * 16 + 14], SIGMA82[i * 16 + 15]);
      }
      for (i = 0; i < 16; i++) {
        ctx.h[i] = ctx.h[i] ^ v[i] ^ v[i + 16];
      }
    }
    var parameterBlock = new Uint8Array([
      0,
      0,
      0,
      0,
      //  0: outlen, keylen, fanout, depth
      0,
      0,
      0,
      0,
      //  4: leaf length, sequential mode
      0,
      0,
      0,
      0,
      //  8: node offset
      0,
      0,
      0,
      0,
      // 12: node offset
      0,
      0,
      0,
      0,
      // 16: node depth, inner length, rfu
      0,
      0,
      0,
      0,
      // 20: rfu
      0,
      0,
      0,
      0,
      // 24: rfu
      0,
      0,
      0,
      0,
      // 28: rfu
      0,
      0,
      0,
      0,
      // 32: salt
      0,
      0,
      0,
      0,
      // 36: salt
      0,
      0,
      0,
      0,
      // 40: salt
      0,
      0,
      0,
      0,
      // 44: salt
      0,
      0,
      0,
      0,
      // 48: personal
      0,
      0,
      0,
      0,
      // 52: personal
      0,
      0,
      0,
      0,
      // 56: personal
      0,
      0,
      0,
      0
      // 60: personal
    ]);
    function blake2bInit(outlen, key2, salt, personal) {
      if (outlen === 0 || outlen > 64) {
        throw new Error("Illegal output length, expected 0 < length <= 64");
      }
      if (key2 && key2.length > 64) {
        throw new Error("Illegal key, expected Uint8Array with 0 < length <= 64");
      }
      if (salt && salt.length !== 16) {
        throw new Error("Illegal salt, expected Uint8Array with length is 16");
      }
      if (personal && personal.length !== 16) {
        throw new Error("Illegal personal, expected Uint8Array with length is 16");
      }
      const ctx = {
        b: new Uint8Array(128),
        h: new Uint32Array(16),
        t: 0,
        // input count
        c: 0,
        // pointer within buffer
        outlen
        // output length in bytes
      };
      parameterBlock.fill(0);
      parameterBlock[0] = outlen;
      if (key2) parameterBlock[1] = key2.length;
      parameterBlock[2] = 1;
      parameterBlock[3] = 1;
      if (salt) parameterBlock.set(salt, 32);
      if (personal) parameterBlock.set(personal, 48);
      for (let i = 0; i < 16; i++) {
        ctx.h[i] = BLAKE2B_IV32[i] ^ B2B_GET32(parameterBlock, i * 4);
      }
      if (key2) {
        blake2bUpdate(ctx, key2);
        ctx.c = 128;
      }
      return ctx;
    }
    function blake2bUpdate(ctx, input) {
      for (let i = 0; i < input.length; i++) {
        if (ctx.c === 128) {
          ctx.t += ctx.c;
          blake2bCompress(ctx, false);
          ctx.c = 0;
        }
        ctx.b[ctx.c++] = input[i];
      }
    }
    function blake2bFinal(ctx) {
      ctx.t += ctx.c;
      while (ctx.c < 128) {
        ctx.b[ctx.c++] = 0;
      }
      blake2bCompress(ctx, true);
      const out = new Uint8Array(ctx.outlen);
      for (let i = 0; i < ctx.outlen; i++) {
        out[i] = ctx.h[i >> 2] >> 8 * (i & 3);
      }
      return out;
    }
    function blake2b2(input, key2, outlen, salt, personal) {
      outlen = outlen || 64;
      input = util.normalizeInput(input);
      if (salt) {
        salt = util.normalizeInput(salt);
      }
      if (personal) {
        personal = util.normalizeInput(personal);
      }
      const ctx = blake2bInit(outlen, key2, salt, personal);
      blake2bUpdate(ctx, input);
      return blake2bFinal(ctx);
    }
    function blake2bHex(input, key2, outlen, salt, personal) {
      const output = blake2b2(input, key2, outlen, salt, personal);
      return util.toHex(output);
    }
    module2.exports = {
      blake2b: blake2b2,
      blake2bHex,
      blake2bInit,
      blake2bUpdate,
      blake2bFinal
    };
  }
});

// node_modules/blakejs/blake2s.js
var require_blake2s = __commonJS({
  "node_modules/blakejs/blake2s.js"(exports2, module2) {
    var util = require_util();
    function B2S_GET32(v2, i) {
      return v2[i] ^ v2[i + 1] << 8 ^ v2[i + 2] << 16 ^ v2[i + 3] << 24;
    }
    function B2S_G(a, b, c, d, x, y) {
      v[a] = v[a] + v[b] + x;
      v[d] = ROTR32(v[d] ^ v[a], 16);
      v[c] = v[c] + v[d];
      v[b] = ROTR32(v[b] ^ v[c], 12);
      v[a] = v[a] + v[b] + y;
      v[d] = ROTR32(v[d] ^ v[a], 8);
      v[c] = v[c] + v[d];
      v[b] = ROTR32(v[b] ^ v[c], 7);
    }
    function ROTR32(x, y) {
      return x >>> y ^ x << 32 - y;
    }
    var BLAKE2S_IV = new Uint32Array([
      1779033703,
      3144134277,
      1013904242,
      2773480762,
      1359893119,
      2600822924,
      528734635,
      1541459225
    ]);
    var SIGMA = new Uint8Array([
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      10,
      11,
      12,
      13,
      14,
      15,
      14,
      10,
      4,
      8,
      9,
      15,
      13,
      6,
      1,
      12,
      0,
      2,
      11,
      7,
      5,
      3,
      11,
      8,
      12,
      0,
      5,
      2,
      15,
      13,
      10,
      14,
      3,
      6,
      7,
      1,
      9,
      4,
      7,
      9,
      3,
      1,
      13,
      12,
      11,
      14,
      2,
      6,
      5,
      10,
      4,
      0,
      15,
      8,
      9,
      0,
      5,
      7,
      2,
      4,
      10,
      15,
      14,
      1,
      11,
      12,
      6,
      8,
      3,
      13,
      2,
      12,
      6,
      10,
      0,
      11,
      8,
      3,
      4,
      13,
      7,
      5,
      15,
      14,
      1,
      9,
      12,
      5,
      1,
      15,
      14,
      13,
      4,
      10,
      0,
      7,
      6,
      3,
      9,
      2,
      8,
      11,
      13,
      11,
      7,
      14,
      12,
      1,
      3,
      9,
      5,
      0,
      15,
      4,
      8,
      6,
      2,
      10,
      6,
      15,
      14,
      9,
      11,
      3,
      0,
      8,
      12,
      2,
      13,
      7,
      1,
      4,
      10,
      5,
      10,
      2,
      8,
      4,
      7,
      6,
      1,
      5,
      15,
      11,
      9,
      14,
      3,
      12,
      13,
      0
    ]);
    var v = new Uint32Array(16);
    var m = new Uint32Array(16);
    function blake2sCompress(ctx, last) {
      let i = 0;
      for (i = 0; i < 8; i++) {
        v[i] = ctx.h[i];
        v[i + 8] = BLAKE2S_IV[i];
      }
      v[12] ^= ctx.t;
      v[13] ^= ctx.t / 4294967296;
      if (last) {
        v[14] = ~v[14];
      }
      for (i = 0; i < 16; i++) {
        m[i] = B2S_GET32(ctx.b, 4 * i);
      }
      for (i = 0; i < 10; i++) {
        B2S_G(0, 4, 8, 12, m[SIGMA[i * 16 + 0]], m[SIGMA[i * 16 + 1]]);
        B2S_G(1, 5, 9, 13, m[SIGMA[i * 16 + 2]], m[SIGMA[i * 16 + 3]]);
        B2S_G(2, 6, 10, 14, m[SIGMA[i * 16 + 4]], m[SIGMA[i * 16 + 5]]);
        B2S_G(3, 7, 11, 15, m[SIGMA[i * 16 + 6]], m[SIGMA[i * 16 + 7]]);
        B2S_G(0, 5, 10, 15, m[SIGMA[i * 16 + 8]], m[SIGMA[i * 16 + 9]]);
        B2S_G(1, 6, 11, 12, m[SIGMA[i * 16 + 10]], m[SIGMA[i * 16 + 11]]);
        B2S_G(2, 7, 8, 13, m[SIGMA[i * 16 + 12]], m[SIGMA[i * 16 + 13]]);
        B2S_G(3, 4, 9, 14, m[SIGMA[i * 16 + 14]], m[SIGMA[i * 16 + 15]]);
      }
      for (i = 0; i < 8; i++) {
        ctx.h[i] ^= v[i] ^ v[i + 8];
      }
    }
    function blake2sInit(outlen, key2) {
      if (!(outlen > 0 && outlen <= 32)) {
        throw new Error("Incorrect output length, should be in [1, 32]");
      }
      const keylen = key2 ? key2.length : 0;
      if (key2 && !(keylen > 0 && keylen <= 32)) {
        throw new Error("Incorrect key length, should be in [1, 32]");
      }
      const ctx = {
        h: new Uint32Array(BLAKE2S_IV),
        // hash state
        b: new Uint8Array(64),
        // input block
        c: 0,
        // pointer within block
        t: 0,
        // input count
        outlen
        // output length in bytes
      };
      ctx.h[0] ^= 16842752 ^ keylen << 8 ^ outlen;
      if (keylen > 0) {
        blake2sUpdate(ctx, key2);
        ctx.c = 64;
      }
      return ctx;
    }
    function blake2sUpdate(ctx, input) {
      for (let i = 0; i < input.length; i++) {
        if (ctx.c === 64) {
          ctx.t += ctx.c;
          blake2sCompress(ctx, false);
          ctx.c = 0;
        }
        ctx.b[ctx.c++] = input[i];
      }
    }
    function blake2sFinal(ctx) {
      ctx.t += ctx.c;
      while (ctx.c < 64) {
        ctx.b[ctx.c++] = 0;
      }
      blake2sCompress(ctx, true);
      const out = new Uint8Array(ctx.outlen);
      for (let i = 0; i < ctx.outlen; i++) {
        out[i] = ctx.h[i >> 2] >> 8 * (i & 3) & 255;
      }
      return out;
    }
    function blake2s(input, key2, outlen) {
      outlen = outlen || 32;
      input = util.normalizeInput(input);
      const ctx = blake2sInit(outlen, key2);
      blake2sUpdate(ctx, input);
      return blake2sFinal(ctx);
    }
    function blake2sHex(input, key2, outlen) {
      const output = blake2s(input, key2, outlen);
      return util.toHex(output);
    }
    module2.exports = {
      blake2s,
      blake2sHex,
      blake2sInit,
      blake2sUpdate,
      blake2sFinal
    };
  }
});

// node_modules/blakejs/index.js
var require_blakejs = __commonJS({
  "node_modules/blakejs/index.js"(exports2, module2) {
    var b2b = require_blake2b();
    var b2s = require_blake2s();
    module2.exports = {
      blake2b: b2b.blake2b,
      blake2bHex: b2b.blake2bHex,
      blake2bInit: b2b.blake2bInit,
      blake2bUpdate: b2b.blake2bUpdate,
      blake2bFinal: b2b.blake2bFinal,
      blake2s: b2s.blake2s,
      blake2sHex: b2s.blake2sHex,
      blake2sInit: b2s.blake2sInit,
      blake2sUpdate: b2s.blake2sUpdate,
      blake2sFinal: b2s.blake2sFinal
    };
  }
});

// src/cloud-keys.ts
function gh3(p, init = {}) {
  const token = getSecret("github");
  if (!token) throw new Error("Save a GitHub token first (Settings \u2192 Memory \u2192 GitHub token).");
  return fetch(`${GH3}${p}`, { ...init, headers: { authorization: `Bearer ${token}`, accept: "application/vnd.github+json", "user-agent": "MausDroid-improver", "content-type": "application/json", ...init.headers ?? {} }, signal: AbortSignal.timeout(3e4) });
}
function sealedBox(message, publicKeyB64) {
  const pk = new Uint8Array(Buffer.from(publicKeyB64, "base64"));
  const eph = import_tweetnacl.default.box.keyPair();
  const both = new Uint8Array(64);
  both.set(eph.publicKey, 0);
  both.set(pk, 32);
  const nonce = (0, import_blakejs.blake2b)(both, void 0, 24);
  const boxed = import_tweetnacl.default.box(new Uint8Array(Buffer.from(message, "utf8")), nonce, pk, eph.secretKey);
  const out = new Uint8Array(32 + boxed.length);
  out.set(eph.publicKey, 0);
  out.set(boxed, 32);
  return Buffer.from(out).toString("base64");
}
async function saveRepoSecret(name, value) {
  const k = await gh3(`/repos/${CODE_REPO}/actions/secrets/public-key`);
  if (k.status === 403 || k.status === 404) throw new Error(`GitHub refused (HTTP ${k.status}). ${permissionHelp}`);
  if (!k.ok) throw new Error(`GitHub said HTTP ${k.status}.`);
  const { key: key2, key_id } = await k.json();
  const r = await gh3(`/repos/${CODE_REPO}/actions/secrets/${name}`, { method: "PUT", body: JSON.stringify({ encrypted_value: sealedBox(value, key2), key_id }) });
  if (r.status === 403 || r.status === 404) throw new Error(`GitHub refused (HTTP ${r.status}). ${permissionHelp}`);
  if (!r.ok) throw new Error(`GitHub said HTTP ${r.status} saving ${name}.`);
}
async function checklist() {
  const out = { githubToken: Boolean(getSecret("github")), secrets: null, repo: CODE_REPO };
  if (!out.githubToken) return { ...out, problem: "No GitHub token saved yet (Settings \u2192 Memory \u2192 GitHub token)." };
  try {
    const r = await gh3(`/repos/${CODE_REPO}/actions/secrets?per_page=100`);
    if (r.status === 403 || r.status === 404) return { ...out, problem: permissionHelp };
    if (!r.ok) return { ...out, problem: `GitHub said HTTP ${r.status}.` };
    const names = new Set(((await r.json()).secrets ?? []).map((s) => s.name));
    out.secrets = Object.fromEntries(NEEDED.map((n) => [n, names.has(n)]));
  } catch (e) {
    out.problem = e.message;
  }
  return out;
}
async function startConnect(openUrl) {
  if (!getSecret("github")) throw new Error("Save a GitHub token first (Settings \u2192 Memory \u2192 GitHub token).");
  child?.kill();
  set2({ stage: "signing-in", message: "Opening Claude's sign-in page\u2026", loginUrl: void 0, needsCode: false });
  try {
    await install("claude");
  } catch (e) {
    return set2({ stage: "error", message: `The Claude program couldn't be set up on this phone: ${e.message}` });
  }
  const [cmd, args] = programCommand("claude", ["setup-token"]);
  const helper = process.env.MAUSDROID_NATIVE_DIR ? import_node_path9.default.join(process.env.MAUSDROID_NATIVE_DIR, "libtsbridge.so") : process.env.MAUSDROID_PTY_HELPER;
  inTerminal = Boolean(helper && import_node_fs10.default.existsSync(helper));
  const c = inTerminal ? (0, import_node_child_process3.spawn)(helper, ["pty", cmd, ...args], { cwd: workDir(), env: { ...programEnv("claude"), TERM: "xterm-256color" } }) : (0, import_node_child_process3.spawn)(cmd, args, { cwd: workDir(), env: programEnv("claude") });
  if (inTerminal) {
    let nudges = 0;
    const nudge = setInterval(() => {
      if (state.stage !== "signing-in" || state.loginUrl || child !== c || ++nudges > 8) return clearInterval(nudge);
      c.stdin?.write("\r");
    }, Number(process.env.MAUSDROID_CONNECT_NUDGE_MS ?? 3e3));
  }
  if (noLinkTimer) clearTimeout(noLinkTimer);
  noLinkTimer = setTimeout(() => {
    if (state.stage !== "signing-in" || state.loginUrl) return;
    const said = log2.split("\n").map((l) => l.trim()).filter((l) => /[A-Za-z]{3}/.test(l)).slice(-4).join(" \xB7 ");
    c.kill();
    set2({ stage: "error", message: `Claude's program didn't show a sign-in link${said ? ` (it said: ${said.slice(0, 300)})` : " (it printed nothing)"}. Tap Connect to try again, and send this message to your developer session if it keeps happening.` });
  }, Number(process.env.MAUSDROID_CONNECT_LINK_MS ?? 25e3));
  child = c;
  let log2 = "";
  let opened = false;
  let saved = false;
  afterCode = "";
  codeSent = false;
  const onData = (d) => {
    const text = stripAnsi2(d.toString("utf8"));
    log2 = (log2 + text).slice(-8e3);
    lastLog = log2;
    if (codeSent) afterCode = (afterCode + text).slice(-8e3);
    const compact = log2.replace(/\n(?=\S)/g, (m, off) => /[A-Za-z0-9%&=._~:/?#-]$/.test(log2.slice(0, off)) ? "" : m);
    const tok = findClaudeKey(log2);
    if (tok && !saved) {
      saved = true;
      if (watchdog) clearTimeout(watchdog);
      set2({ stage: "saving", message: "Saving the key to GitHub\u2026", needsCode: false, loginUrl: void 0 });
      void saveRepoSecret("CLAUDE_CODE_OAUTH_TOKEN", tok).then(() => set2({ stage: "done", message: "Connected \u2713 \u2014 cloud builds can use your Claude subscription." })).catch((e) => set2({ stage: "error", message: e.message })).finally(() => c.kill());
      return;
    }
    if (codeSent && !saved && state.stage === "signing-in") {
      const err = afterCode.split("\n").map((l) => l.trim()).find((l) => /✘|OAuth error|error:|wasn't accepted|expired|invalid code|denied/i.test(l));
      if (err) {
        if (watchdog) clearTimeout(watchdog);
        set2({ stage: "error", message: `${hideKeys(err).replace(/^✘\s*/, "")} Tap Connect to try again (each code works once).`, loginUrl: void 0, needsCode: false });
        c.kill();
        return;
      }
    }
    const url = compact.match(/https:\/\/[^\s"'<>]+(oauth|authorize)[^\s"'<>]*/)?.[0];
    const needsCode = /paste|authorization code|enter.*code/i.test(log2);
    if (url) set2({ loginUrl: url, needsCode });
    if (url && !opened) {
      opened = true;
      set2({ message: "Sign in on Claude's page that opened, then paste the code here." });
      void openUrl(url).catch(() => {
      });
    }
  };
  c.stdout?.on("data", onData);
  c.stderr?.on("data", onData);
  c.on("error", (e) => set2({ stage: "error", message: `The Claude program couldn't start on this phone (${e.message}).` }));
  c.on("close", (code) => {
    if (child === c) child = null;
    if (state.stage === "signing-in") {
      const reason = log2.split("\n").map((l) => l.trim()).filter(Boolean).reverse().find((l) => /error|couldn't|failed|invalid|expired|denied|not accepted|wasn't/i.test(l));
      set2({ stage: "error", message: `${reason ?? `It didn't finish (exit ${code}).`} Tap Connect to try again.`, loginUrl: void 0, needsCode: false });
    }
  });
}
function connectCode(code) {
  if (!child?.stdin) throw new Error("Nothing is waiting for a code. Tap Connect again.");
  const c = child;
  afterCode = "";
  codeSent = true;
  c.stdin.write(`${code.trim()}${inTerminal ? "\r" : "\n"}`);
  set2({ message: "Checking the code\u2026", needsCode: false });
  if (watchdog) clearTimeout(watchdog);
  const nudge = setTimeout(() => {
    if (state.stage === "signing-in" && child === c && inTerminal) c.stdin?.write("\r");
  }, Number(process.env.MAUSDROID_CONNECT_AFTER_NUDGE_MS ?? 4e4));
  watchdog = setTimeout(() => {
    clearTimeout(nudge);
    if (state.stage !== "signing-in") return;
    const said = lastLines(afterCode || lastLog);
    console.log(`[connect-claude] no key after the code; Claude's screen said: ${said}`);
    child?.kill();
    set2({ stage: "error", message: `Claude didn't finish within 2 minutes${said ? ` \u2014 its screen said: \u201C${said}\u201D` : " and printed nothing after the code"}. Tap Connect to try again with a new code, and send this message to your developer session if it happens again.` });
  }, Number(process.env.MAUSDROID_CONNECT_CODE_MS ?? 12e4));
}
function cancelConnect() {
  child?.kill();
  child = null;
  set2({ stage: "idle", message: void 0, loginUrl: void 0, needsCode: false });
}
async function addSecret(name, value) {
  if (!NEEDED.includes(name) || name === "CLAUDE_CODE_OAUTH_TOKEN") throw new Error("That key can't be added here.");
  const v = value.trim();
  if (name === "MAUSDROID_UPDATE_KEY_PEM" && !/^-----BEGIN (EC )?PRIVATE KEY-----[\s\S]+-----END (EC )?PRIVATE KEY-----$/.test(v)) throw new Error("That isn't the update signing key file (update-signing-key.pem).");
  if (name === "CODEX_AUTH_JSON") {
    try {
      JSON.parse(v);
    } catch {
      throw new Error("That isn't a Codex auth.json file.");
    }
  }
  if (name === "OPENAI_API_KEY" && !/^sk-[A-Za-z0-9_-]{20,}$/.test(v)) throw new Error("That doesn't look like an OpenAI API key (they start with sk-).");
  if (!v) throw new Error("Empty.");
  await saveRepoSecret(name, `${v}
`);
}
async function startCodexConnect(openUrl) {
  if (!getSecret("github")) throw new Error("Save a GitHub token first (Settings \u2192 Memory \u2192 GitHub token).");
  codexChild?.kill();
  setCodex({ stage: "signing-in", message: "Opening the ChatGPT sign-in page\u2026", loginUrl: void 0, needsCode: false });
  try {
    await install("chatgpt");
  } catch (e) {
    return setCodex({ stage: "error", message: `The Codex program couldn't be set up on this phone: ${e.message}` });
  }
  const home = codexCloudHome();
  import_node_fs10.default.mkdirSync(home, { recursive: true });
  import_node_fs10.default.rmSync(import_node_path9.default.join(home, "auth.json"), { force: true });
  const [cmd, args] = programCommand("chatgpt", ["login"]);
  const c = (0, import_node_child_process3.spawn)(cmd, args, { cwd: workDir(), env: { ...programEnv("chatgpt"), CODEX_HOME: home } });
  codexChild = c;
  let log2 = "";
  let opened = false;
  const giveUp = setTimeout(() => {
    if (codexState.stage !== "signing-in") return;
    c.kill();
    setCodex({ stage: "error", message: `The ChatGPT sign-in didn't finish within 5 minutes${lastLines(log2) ? ` (Codex said: \u201C${lastLines(log2)}\u201D)` : ""}. Tap Connect with ChatGPT to try again.`, loginUrl: void 0 });
  }, Number(process.env.MAUSDROID_CODEX_CONNECT_MS ?? 3e5));
  const onData = (d) => {
    log2 = (log2 + terminalText(d.toString("utf8"))).slice(-8e3);
    const url = log2.match(/https:\/\/auth\.openai\.com\/[^\s"'<>]+/)?.[0];
    if (url && !opened) {
      opened = true;
      setCodex({ loginUrl: url, message: "Sign in on the ChatGPT page that opened. MausDroid finishes by itself when you're done." });
      void openUrl(url).catch(() => {
      });
    }
  };
  c.stdout?.on("data", onData);
  c.stderr?.on("data", onData);
  c.on("error", (e) => setCodex({ stage: "error", message: `The Codex program couldn't start on this phone (${e.message}).` }));
  c.on("close", (code) => {
    clearTimeout(giveUp);
    if (codexChild === c) codexChild = null;
    if (codexState.stage !== "signing-in") return;
    const auth2 = import_node_path9.default.join(home, "auth.json");
    if (code === 0 && import_node_fs10.default.existsSync(auth2)) {
      setCodex({ stage: "saving", message: "Saving the ChatGPT login to GitHub\u2026", loginUrl: void 0 });
      void saveRepoSecret("CODEX_AUTH_JSON", import_node_fs10.default.readFileSync(auth2, "utf8")).then(() => setCodex({ stage: "done", message: "Connected \u2713 \u2014 cloud builds can use Codex with your ChatGPT subscription." })).catch((e) => setCodex({ stage: "error", message: e.message }));
    } else setCodex({ stage: "error", message: `The ChatGPT sign-in didn't finish${lastLines(log2) ? ` (Codex said: \u201C${lastLines(log2)}\u201D)` : ` (exit ${code})`}. Tap Connect with ChatGPT to try again.`, loginUrl: void 0 });
  });
}
function cancelCodexConnect() {
  codexChild?.kill();
  codexChild = null;
  setCodex({ stage: "idle", message: void 0, loginUrl: void 0 });
}
async function refreshCodexSecret() {
  const auth2 = import_node_path9.default.join(codexCloudHome(), "auth.json");
  if (import_node_fs10.default.existsSync(auth2)) await saveRepoSecret("CODEX_AUTH_JSON", import_node_fs10.default.readFileSync(auth2, "utf8")).catch(() => {
  });
}
var import_node_child_process3, import_node_fs10, import_node_path9, import_tweetnacl, import_blakejs, GH3, permissionHelp, NEEDED, state, child, inTerminal, afterCode, codeSent, lastLog, hideKeys, lastLines, noLinkTimer, watchdog, connectState, set2, stripAnsi2, codexState, codexChild, codexConnectState, setCodex, codexCloudHome;
var init_cloud_keys = __esm({
  "src/cloud-keys.ts"() {
    "use strict";
    import_node_child_process3 = require("node:child_process");
    import_node_fs10 = __toESM(require("node:fs"), 1);
    import_node_path9 = __toESM(require("node:path"), 1);
    import_tweetnacl = __toESM(require_nacl_fast(), 1);
    import_blakejs = __toESM(require_blakejs(), 1);
    init_events();
    init_secrets();
    init_subscriptions();
    init_selfupdate();
    init_util();
    init_store();
    GH3 = process.env.MAUSDROID_GITHUB_API ?? "https://api.github.com";
    permissionHelp = "Your GitHub token needs \u201CSecrets: Read and write\u201D for the MausDroid repository (github.com \u2192 Settings \u2192 Developer settings \u2192 Fine-grained tokens \u2192 edit the token).";
    NEEDED = ["CLAUDE_CODE_OAUTH_TOKEN", "CODEX_AUTH_JSON", "OPENAI_API_KEY", "MAUSDROID_UPDATE_KEY_PEM"];
    state = { stage: "idle" };
    child = null;
    inTerminal = false;
    afterCode = "";
    codeSent = false;
    lastLog = "";
    hideKeys = (t) => t.replace(/sk-ant-[0-9A-Za-z_-]{6,}/g, "sk-ant-\u2026(hidden)");
    lastLines = (t, n = 5) => hideKeys(t).split("\n").map((l) => l.trim()).filter((l) => /[A-Za-z]{3}/.test(l) && !/^[╭╰│─\s]+$/.test(l)).slice(-n).join(" \xB7 ").slice(0, 400);
    noLinkTimer = null;
    watchdog = null;
    connectState = () => state;
    set2 = (p) => {
      state = { ...state, ...p };
      emit("improve.changed", {});
    };
    stripAnsi2 = terminalText;
    codexState = { stage: "idle" };
    codexChild = null;
    codexConnectState = () => codexState;
    setCodex = (p) => {
      codexState = { ...codexState, ...p };
      emit("improve.changed", {});
    };
    codexCloudHome = () => import_node_path9.default.dirname(dataPath("subs", "codex-cloud", ".keep"));
  }
});

// src/improve.ts
var improve_exports = {};
__export(improve_exports, {
  IMPROVER_MODEL: () => IMPROVER_MODEL,
  IMPROVER_PERSONA: () => IMPROVER_PERSONA,
  IMPROVE_PROMPT: () => IMPROVE_PROMPT,
  IMPROVE_SYSTEM: () => IMPROVE_SYSTEM,
  MAX_PER_NIGHT: () => MAX_PER_NIGHT,
  OLD_IMPROVER_PERSONA: () => OLD_IMPROVER_PERSONA,
  addSuggestions: () => addSuggestions,
  answerBuild: () => answerBuild,
  applyPrompt: () => applyPrompt,
  approve: () => approve,
  beginNight: () => beginNight,
  checkBuilds: () => checkBuilds,
  codingAgent: () => codingAgent,
  collectEvidence: () => collectEvidence,
  dismiss: () => dismiss,
  ensureImprover: () => ensureImprover,
  finishNight: () => finishNight,
  getProposal: () => getProposal,
  improveRoutine: () => improveRoutine,
  improveSettings: () => improveSettings,
  improverBot: () => improverBot,
  isImprover: () => isImprover,
  listNights: () => listNights,
  listProposals: () => listProposals,
  nightFor: () => nightFor,
  overview: () => overview,
  recordApplied: () => recordApplied,
  requestBuild: () => requestBuild,
  revealDue: () => revealDue,
  saveImproveSettings: () => saveImproveSettings,
  showDateFor: () => showDateFor,
  snooze: () => snooze,
  startImprover: () => startImprover,
  watchBuilds: () => watchBuilds,
  withdraw: () => withdraw
});
function patch2(pid, p) {
  let out;
  proposals.update((l) => {
    const x = l.find((y) => y.id === pid);
    if (x) out = Object.assign(x, p);
  });
  emit("improve.changed", {});
  return out ? { ...out } : void 0;
}
function routineSchedule(s) {
  return { kind: "daily", time: s.nightTime, missedPolicy: "run-once", catchUpHours: 9 };
}
function ensureImprover() {
  addRunValidator(IMPROVE_SYSTEM, (run) => nightFor(run.id)?.finishedAt ? null : "The nightly check ended without recording its result (improve_finish), so it's incomplete.");
  let s = settingsFile2.get();
  let bot = s.botId ? getBot(s.botId) : void 0;
  if (bot && bot.persona === OLD_IMPROVER_PERSONA) updateBot(bot.id, { persona: IMPROVER_PERSONA });
  if (!bot) {
    bot = listBots().find((b) => b.name === "Improver") ?? createBot({ name: "Improver", emoji: "\u{1F6E0}\uFE0F", color: "#8e44ad", persona: IMPROVER_PERSONA, providerId: "claude", model: IMPROVER_MODEL, tools: { web: true, browser: false, apps: false, phone: false } });
    settingsFile2.update((x) => void (x.botId = bot.id));
    s = settingsFile2.get();
  }
  const existing = listRoutines().find((r) => r.system === IMPROVE_SYSTEM);
  if (!existing) {
    createRoutine({
      botId: bot.id,
      title: "Nightly self-improvement check",
      prompt: IMPROVE_PROMPT,
      schedule: routineSchedule(s),
      timeoutMinutes: 10,
      researchCutoffMinutes: 5,
      retry: { max: 1, delayMinutes: 5 },
      system: IMPROVE_SYSTEM,
      enabled: s.enabled
    });
  }
}
function saveImproveSettings(input) {
  if (input.nightTime !== void 0 && !HM2.test(input.nightTime)) throw new Error("Night time must be HH:MM.");
  if (input.showTime !== void 0 && !HM2.test(input.showTime)) throw new Error("Show time must be HH:MM.");
  if (input.botId !== void 0 && input.botId !== null && !getBot(input.botId)) throw new Error("No such bot.");
  settingsFile2.update((s2) => {
    for (const k of ["enabled", "nightTime", "showTime", "botId", "askBeforeInstall", "codingPlatform"]) if (input[k] !== void 0) s2[k] = input[k];
  });
  const s = settingsFile2.get();
  const r = improveRoutine();
  if (r) {
    const changes2 = {};
    if (r.schedule.time !== s.nightTime) changes2.schedule = { ...r.schedule, time: s.nightTime };
    if (Object.keys(changes2).length) updateRoutine(r.id, changes2);
    if (s.botId && r.botId !== s.botId) {
      createRoutine({ botId: s.botId, title: r.title, prompt: r.prompt, schedule: r.schedule, timeoutMinutes: r.timeoutMinutes, researchCutoffMinutes: r.researchCutoffMinutes, retry: r.retry, system: IMPROVE_SYSTEM, enabled: r.enabled });
      deleteRoutine(r.id);
    }
    const cur = improveRoutine();
    if (cur && cur.enabled !== s.enabled) s.enabled ? resumeRoutine(cur.id) : pauseRoutine(cur.id);
  }
  emit("improve.changed", {});
  return s;
}
function collectEvidence() {
  const runs = listRuns(void 0, 400).filter((r) => since(r.finishedAt ?? r.queuedAt, 48));
  const problems = runs.filter((r) => ["failed", "timed_out", "missed", "skipped"].includes(r.status)).slice(0, 30).map((r) => ({ routine: getRoutine(r.routineId)?.title ?? r.routineId, routineId: r.routineId, status: r.status, at: r.finishedAt ?? r.queuedAt, error: clip(r.error ?? "", 400) }));
  const routines = listRoutines().map((r) => ({
    id: r.id,
    title: r.title,
    bot: getBot(r.botId)?.name ?? "(missing bot)",
    enabled: r.enabled,
    schedule: r.schedule,
    nextRunAt: r.nextRunAt ?? null,
    timeoutMinutes: r.timeoutMinutes,
    system: r.system ?? null,
    prompt: clip(r.prompt, 1200),
    lastResult: r.lastResult ?? null,
    issues: [
      !getBot(r.botId) ? "its bot no longer exists" : "",
      r.enabled && !r.nextRunAt && r.schedule.kind !== "alert" ? "enabled but has no next run" : ""
    ].filter(Boolean)
  }));
  const skills = listSkills().map((s) => ({
    name: s.name,
    description: s.description,
    source: s.source ?? "hand-made",
    issues: [!s.description ? "no description (bots can't tell when to use it)" : "", s.description.length > 400 ? "very long description" : ""].filter(Boolean)
  }));
  const botErrors = [];
  for (const b of listBots()) {
    for (const m of messages(b.id, void 0, 150)) {
      if (!since(m.at, 48)) continue;
      if (m.status === "error" || m.tool?.isError) botErrors.push({ bot: b.name, at: m.at, text: clip(m.tool ? `${m.tool.name}: ${m.tool.result ?? ""}` : m.text, 300) });
    }
  }
  let engine = null;
  try {
    const st = JSON.parse(import_node_fs11.default.readFileSync(import_node_path10.default.join(config.dataDir, "engine-status.json"), "utf8"));
    engine = { version: config.version, startupProblems: (st.steps ?? []).filter((x) => x.ok === false).map((x) => `${x.step}: ${clip(String(x.error ?? "failed").split("\n")[0], 300)}`) };
  } catch {
    engine = { version: config.version };
  }
  const earlier = proposals.get().filter((p) => since(p.createdAt, 24 * 21)).map((p) => ({ id: p.id, title: p.title, status: p.status }));
  return { now: (/* @__PURE__ */ new Date()).toISOString(), engine, routineProblems: problems, routines, skills, botErrors: botErrors.slice(-25), earlierSuggestions: earlier, assistantExamples: assistantExamples(7) };
}
function beginNight(runId) {
  let n;
  nights.update((l) => {
    n = l.find((x) => x.runId === runId);
    if (!n) {
      n = { runId, startedAt: now(), count: 0 };
      l.push(n);
      if (l.length > 90) l.splice(0, l.length - 90);
    }
  });
  return n;
}
function finishNight(runId, summary) {
  beginNight(runId);
  let n;
  nights.update((l) => {
    n = l.find((x) => x.runId === runId);
    n.finishedAt = now();
    n.summary = clip(summary || "", 500);
  });
  emit("improve.changed", {});
  return n;
}
function showDateFor(at, showTime) {
  const p = localParts(at);
  if (p.hm < showTime) return p.ymd;
  const t = new Date(at.getFullYear(), at.getMonth(), at.getDate() + 1, 12);
  return localParts(t).ymd;
}
function buildProposal(runId, s) {
  const title = String(s.title ?? "").trim();
  const problem = String(s.problem ?? "").trim();
  const change = String(s.change ?? "").trim();
  if (!title || !problem || !change) throw new Error("each suggestion needs a title, the problem and the change");
  const area = ["routine", "skill", "code", "other"].includes(String(s.area)) ? s.area : "other";
  const risk = ["low", "medium", "high"].includes(String(s.risk)) ? s.risk : "medium";
  if (looksSecret(JSON.stringify(s))) throw new Error("it looks like it contains a credential or card number");
  const p = { id: id("imp"), runId, createdAt: now(), showFrom: showDateFor(/* @__PURE__ */ new Date(), settingsFile2.get().showTime), title: clip(title, 120), problem: clip(problem, 1200), change: clip(change, 2e3), area, risk, evidence: s.evidence ? clip(String(s.evidence), 800) : void 0, status: "waiting" };
  if (area === "routine") {
    const rp = s.routine_patch;
    const r = rp?.routine_id ? getRoutine(String(rp.routine_id)) : void 0;
    if (!r) throw new Error("a routine fix needs routine_patch.routine_id of an existing routine");
    const before = {};
    const after = {};
    for (const [inKey, key2] of ROUTINE_FIELDS) {
      if (rp[inKey] === void 0) continue;
      before[key2] = r[key2] ?? null;
      after[key2] = rp[inKey];
    }
    if (!Object.keys(after).length) throw new Error("routine_patch changes nothing");
    if (after.schedule) {
      const errs = validateSchedule(after.schedule);
      if (errs.length) throw new Error(`schedule: ${errs.join(" ")}`);
    }
    if (after.timeoutMinutes !== void 0) {
      const t = Number(after.timeoutMinutes);
      if (!(t >= 1 && t <= 60)) throw new Error("timeout_minutes must be 1\u201360");
      if (r.system === IMPROVE_SYSTEM && t > 10) throw new Error("the nightly check stays at 10 minutes or less");
    }
    if (after.title !== void 0 && !String(after.title).trim()) throw new Error("title can't be empty");
    p.routinePatch = { routineId: r.id, routineTitle: r.title, before, after };
  }
  if (area === "skill") {
    const name = String(s.skill?.name ?? "").trim();
    const content = String(s.skill?.content ?? "");
    const fm = parseFrontmatter(content);
    if (!name || !fm.name || !fm.description) throw new Error("a skill fix needs skill.name and a complete SKILL.md with name and description");
    const cur = listSkills().find((x) => x.name === name);
    p.skill = { name, before: cur ? import_node_fs11.default.readFileSync(import_node_path10.default.join(cur.dir, "SKILL.md"), "utf8") : null, after: content };
  }
  return p;
}
function addSuggestions(runId, list) {
  beginNight(runId);
  const added = [];
  const refused = [];
  const all = proposals.get();
  let count = all.filter((p) => p.runId === runId).length;
  const compare = all.filter((p) => ["waiting", "shown", "applying"].includes(p.status) || (p.status === "declined" || p.status === "applied") && since(p.decidedAt, 24 * 21));
  for (const s of Array.isArray(list) ? list : []) {
    const title = String(s?.title ?? "(untitled)");
    if (count >= MAX_PER_NIGHT) {
      refused.push({ title, reason: `only ${MAX_PER_NIGHT} suggestions a night` });
      continue;
    }
    try {
      const p = buildProposal(runId, s ?? {});
      const dup = [...compare, ...added].find((x) => similar(x.title, p.title) || x.title.toLowerCase() === p.title.toLowerCase() || p.routinePatch && x.routinePatch?.routineId === p.routinePatch.routineId && x.status !== "declined" && x.status !== "applied");
      if (dup) {
        refused.push({ title, reason: `repeats "${dup.title}" (${dup.status})` });
        continue;
      }
      added.push(p);
      count++;
    } catch (e) {
      refused.push({ title, reason: e.message });
    }
  }
  proposals.update((l) => {
    l.push(...added);
    if (l.length > 400) l.splice(0, l.length - 400);
  });
  nights.update((l) => {
    const n = l.find((x) => x.runId === runId);
    if (n) n.count = count;
  });
  emit("improve.changed", {});
  return { added, refused };
}
async function revealDue(at = /* @__PURE__ */ new Date(), force = false) {
  const s = settingsFile2.get();
  const p = localParts(at);
  if (!force && p.hm < s.showTime) return [];
  const due = proposals.get().filter((x) => x.status === "waiting" && (force || x.showFrom <= p.ymd));
  for (const x of proposals.get()) if (x.status === "shown" && !since(x.createdAt, 24 * 7)) patch2(x.id, { status: "expired", decidedAt: now() });
  if (!due.length) return [];
  for (const x of due) patch2(x.id, { status: "shown" });
  const bot = improverBot();
  if (force) emit("improve.changed", {});
  else if (s.lastRevealDate !== p.ymd) {
    settingsFile2.update((x) => void (x.lastRevealDate = p.ymd));
    await notifyUser({
      title: `${bot?.emoji ?? "\u{1F6E0}\uFE0F"} ${due.length} improvement${due.length === 1 ? "" : "s"} to review`,
      body: due.map((x) => `\u2022 ${x.title}`).join("\n").slice(0, 300),
      botId: bot?.id,
      priority: "normal",
      type: "improvement",
      source: bot?.name ?? "Improver",
      link: "improve:"
    });
  }
  return due;
}
function startImprover() {
  listen2();
  if (proposals.get().some((p) => p.status === "building")) watchBuilds();
  if (ticker) return;
  void revealDue().catch(() => {
  });
  ticker = setInterval(() => void revealDue().catch(() => {
  }), 6e4);
}
async function approve(pid) {
  const p = getProposal(pid);
  if (!p) throw new Error("No such suggestion");
  if (p.status !== "shown" && p.status !== "waiting") throw new Error(`This suggestion is already ${p.status}.`);
  const decided = { decidedAt: now() };
  if (p.area === "routine" && p.routinePatch) {
    const r = getRoutine(p.routinePatch.routineId);
    if (!r) return patch2(pid, { ...decided, status: "failed", result: "The routine no longer exists." });
    const stale = Object.entries(p.routinePatch.before).find(([k, v]) => !same(r[k] ?? null, v));
    if (stale) return patch2(pid, { ...decided, status: "failed", result: `The routine's ${stale[0]} changed since this was suggested, so nothing was changed. It'll be looked at again tonight.` });
    try {
      updateRoutine(r.id, p.routinePatch.after);
      return patch2(pid, { ...decided, status: "applied", result: `Routine "${r.title}" updated.` });
    } catch (e) {
      return patch2(pid, { ...decided, status: "failed", result: e.message });
    }
  }
  if (p.area === "skill" && p.skill) {
    const cur = listSkills().find((x) => x.name === p.skill.name);
    const now_ = cur ? import_node_fs11.default.readFileSync(import_node_path10.default.join(cur.dir, "SKILL.md"), "utf8") : null;
    if (now_ !== p.skill.before) return patch2(pid, { ...decided, status: "failed", result: "The skill changed since this was suggested, so nothing was changed." });
    if (cur) import_node_fs11.default.writeFileSync(import_node_path10.default.join(cur.dir, "SKILL.md"), p.skill.after);
    else saveSkill(p.skill.name, p.skill.after);
    return patch2(pid, { ...decided, status: "applied", result: `Skill "${p.skill.name}" ${cur ? "updated" : "added"}.` });
  }
  if (p.area === "code") {
    if (p.build?.prNumber && p.status === "shown") return installBuild(p);
    return startCodeBuild(p, false);
  }
  const bot = improverBot();
  if (!bot) return patch2(pid, { ...decided, status: "failed", result: "No Improver bot is set." });
  const out = patch2(pid, { ...decided, status: "applying" });
  sendToBot(bot.id, applyPrompt(p), "improvement", [], p.id);
  return out;
}
function applyPrompt(p) {
  return `The person APPROVED this improvement. Do exactly this, nothing more:

Title: ${p.title}
Problem: ${p.problem}
Change: ${p.change}
Area: ${p.area} \xB7 Risk: ${p.risk}

Rules: ${p.area === "code" ? "make the change in the MausDroid source (github.com/DanGeo13/MausDroid) on a new branch named improve/<short-name>, with tests where possible. Never push to main or the updates branch, never publish a release or APK, never touch signing keys. Any push or pull request goes through an approval card. " : ""}Every action that needs approval still asks. Never store credentials anywhere. If you can't finish it from here, say exactly what's left. End with a short summary of what changed.`;
}
function snooze(pid) {
  const p = getProposal(pid);
  if (!p || !["shown", "waiting"].includes(p.status)) throw new Error("This suggestion can't be postponed.");
  const t = /* @__PURE__ */ new Date();
  const tomorrow = localParts(new Date(t.getFullYear(), t.getMonth(), t.getDate() + 1, 12)).ymd;
  return patch2(pid, { status: "waiting", showFrom: tomorrow });
}
function dismiss(pid) {
  const p = getProposal(pid);
  if (!p || !["shown", "waiting", "building"].includes(p.status)) throw new Error("This suggestion is already decided.");
  if (p.build?.prNumber) void closeBuild(p.build.prNumber).catch(() => {
  });
  return patch2(pid, { status: "declined", decidedAt: now() });
}
async function requestBuild(title, request) {
  const p = { id: id("imp"), runId: "direct", createdAt: now(), showFrom: localParts(/* @__PURE__ */ new Date()).ymd, title: clip(title, 120), problem: "Asked for directly.", change: clip(request, 6e3), area: "code", risk: "medium", status: "shown" };
  if (looksSecret(request)) throw new Error("That request looks like it contains a credential \u2014 leave secrets out.");
  proposals.update((l) => void l.push(p));
  return startCodeBuild(p, true);
}
function codingAgent() {
  const c = settingsFile2.get().codingPlatform ?? "github-claude";
  return c === "off" ? null : c === "github-codex" ? "codex" : "claude";
}
async function startCodeBuild(p, direct) {
  const agent = codingAgent();
  if (!agent) return patch2(p.id, { status: "shown", result: "Building is switched off (Improvements \u2192 Settings \u2192 Coding platform), so this is kept as a suggestion." });
  try {
    if (agent === "codex") await refreshCodexSecret();
    await startBuild(p.id, requestText(p), "", 1, agent);
  } catch (e) {
    return patch2(p.id, { status: "failed", decidedAt: now(), result: `Couldn't start the cloud build: ${e.message}` });
  }
  const out = patch2(p.id, { status: "building", decidedAt: now(), build: { startedAt: now(), direct, attempt: 1, progress: "Starting", answers: [], agent }, result: `Building in the cloud: ${AGENT_NAMES[agent]} is making the change and running every test (usually 5\u201320 minutes).` });
  progressNote(out, `Started in the cloud with ${AGENT_NAMES[agent]} on GitHub \u2014 I'll keep you posted.`);
  watchBuilds();
  return out;
}
function progressNote(p, text) {
  const bot = improverBot();
  if (!bot) return;
  const m = addMessage(bot.id, { role: "note", text: `\u{1F6E0}\uFE0F ${p.title}: ${text}`, status: "done", source: "build" });
  emit("message", { botId: bot.id, message: m });
}
async function answerBuild(pid, answers) {
  const p = getProposal(pid);
  if (!p || p.status !== "building" || !p.build?.questions) throw new Error("That build isn't waiting for answers.");
  if (!answers.trim()) throw new Error("Write your answers first.");
  if (looksSecret(answers)) throw new Error("Leave passwords and keys out of answers.");
  const all = [...p.build.answers ?? [], `Questions:
${p.build.questions}

Answers:
${answers.trim()}`];
  const attempt = (p.build.attempt ?? 1) + 1;
  try {
    await startBuild(p.id, requestText(p), all.join("\n\n---\n\n"), attempt, p.build.agent ?? codingAgent() ?? "claude");
  } catch (e) {
    throw new Error(`Couldn't send the answers: ${e.message}`);
  }
  const out = patch2(pid, { build: { ...p.build, attempt, questions: void 0, answers: all, progress: "Carrying on with your answers", startedAt: now() } });
  progressNote(out, "Got your answers \u2014 carrying on.");
  watchBuilds();
  return out;
}
async function installBuild(p) {
  try {
    await mergeBuild(p.build.prNumber);
  } catch (e) {
    return patch2(p.id, { status: "failed", result: `Couldn't install: ${e.message}` });
  }
  const out = patch2(p.id, { status: "applied", decidedAt: now(), result: "Installed: publishing the update now; MausDroid restarts with it in a few minutes. If anything's wrong, roll back in Improvements." });
  followUpdate(p.title);
  return out;
}
function watchBuilds() {
  if (buildTimer) return;
  buildTimer = setInterval(() => void checkBuilds(), Number(process.env.MAUSDROID_BUILD_POLL_MS ?? 12e4));
}
async function checkBuilds() {
  const building = proposals.get().filter((p) => p.status === "building");
  if (!building.length && buildTimer) {
    clearInterval(buildTimer);
    buildTimer = null;
    return;
  }
  const bot = improverBot();
  for (const p of building) {
    let st;
    try {
      st = await buildState(p.id, p.build?.attempt ?? 1);
    } catch {
      continue;
    }
    const build = { ...p.build, prNumber: st.prNumber, prUrl: st.prUrl, runUrl: st.runUrl ?? p.build?.runUrl };
    if (st.state === "question") {
      if (p.build?.questions) continue;
      patch2(p.id, { build: { ...build, questions: st.questions, progress: "Waiting for your answers" } });
      progressNote(p, "the developer needs a few answers before carrying on.");
      void notifyUser({ title: `${bot?.emoji ?? "\u{1F6E0}\uFE0F"} Question about "${p.title}"`, body: (st.questions ?? "").slice(0, 300), botId: bot?.id, type: "improvement", priority: "high", link: "improve:" });
      if (bot)
        sendToBot(
          bot.id,
          `[Cloud build "${p.title}" (id ${p.id}) needs answers before it can carry on. Ask the person these questions briefly in your own words, with the suggested defaults. When they answer, call improve_build_answer with id ${p.id} and their answers.]

${st.questions}`,
          "build"
        );
      continue;
    }
    if (st.state === "building" && st.progress && st.progress !== p.build?.progress) {
      patch2(p.id, { build: { ...build, progress: st.progress } });
      progressNote(p, st.progress);
      continue;
    }
    if (st.state === "ready") {
      const auto = p.build?.direct && !settingsFile2.get().askBeforeInstall;
      const ready = patch2(p.id, { build: { ...build, progress: "Ready" }, status: "shown", result: "Built and every test passed." });
      progressNote(p, auto ? "built and every test passed \u2014 installing." : "built and every test passed \u2014 tap Install in Improvements.");
      if (auto) await installBuild(ready);
      else void notifyUser({ title: `${bot?.emoji ?? "\u{1F6E0}\uFE0F"} Improvement ready to install`, body: p.title, botId: bot?.id, type: "improvement", link: "improve:" });
    } else if (st.state === "failed") {
      patch2(p.id, { build, status: "failed", result: st.detail ?? "The cloud build failed." });
      progressNote(p, `couldn't be built \u2014 ${st.detail ?? "the cloud build failed"}`);
      void notifyUser({ title: `${bot?.emoji ?? "\u{1F6E0}\uFE0F"} Improvement couldn't be built`, body: `${p.title} \u2014 ${st.detail ?? ""}`.slice(0, 300), botId: bot?.id, type: "improvement", link: "improve:" });
    } else if (st.state === "merged") patch2(p.id, { build, status: "applied", result: "Installed." });
    else if (st.state === "closed") patch2(p.id, { build, status: "declined", result: "The change was closed without installing." });
    else if (build.runUrl !== p.build?.runUrl) patch2(p.id, { build });
    if (st.state === "building" && Date.now() - new Date(p.build.startedAt).getTime() > 90 * 6e4) patch2(p.id, { build, status: "failed", result: "The cloud build took longer than 90 minutes." });
  }
}
function followUpdate(title) {
  if (!bridgeAvailable()) return;
  let tries = 0;
  const t = setInterval(async () => {
    if (++tries > 15) return clearInterval(t);
    const s = await bridge("/update/check", {}, 3e5).catch(() => null);
    if (s?.state === "ready") {
      clearInterval(t);
      const bot = improverBot();
      await notifyUser({ title: `${bot?.emoji ?? "\u{1F6E0}\uFE0F"} Installing ${s.available}`, body: `${title} \u2014 MausDroid restarts for a moment.`, botId: bot?.id, type: "improvement", priority: "low" });
      await bridge("/update/apply", {}).catch(() => {
      });
    }
  }, Number(process.env.MAUSDROID_UPDATE_POLL_MS ?? 18e4));
}
function listen2() {
  if (listening) return;
  listening = true;
  onTurnEnd((_botId, reply, info) => {
    for (const t of info?.tags ?? []) {
      const p = getProposal(t);
      if (!p || p.status !== "applying") continue;
      patch2(t, { status: info.failed || info.aborted ? "failed" : "applied", result: clip(reply || (info.aborted ? "Stopped before it finished." : ""), 2e3) });
    }
  });
}
function recordApplied(title, change, area = "other") {
  const p = { id: id("imp"), runId: "direct", createdAt: now(), showFrom: localParts(/* @__PURE__ */ new Date()).ymd, title: clip(title, 120), problem: "Asked for directly.", change: clip(change, 2e3), area, risk: "low", status: "applied", decidedAt: now(), result: "Done at your request." };
  proposals.update((l) => void l.push(p));
  emit("improve.changed", {});
  return p;
}
function withdraw(refs) {
  const open2 = proposals.get().filter((p) => p.status === "waiting" || p.status === "shown");
  const hit = open2.filter((p) => refs.some((r) => r === p.id || r.length > 2 && p.title.toLowerCase().includes(r.toLowerCase())));
  for (const p of hit) patch2(p.id, { status: "declined", decidedAt: now(), result: "Withdrawn at your request." });
  return hit.map((p) => ({ ...p, status: "declined" }));
}
function overview() {
  const s = settingsFile2.get();
  const r = improveRoutine();
  const all = listProposals();
  return {
    settings: s,
    bot: improverBot() ? { id: improverBot().id, name: improverBot().name, emoji: improverBot().emoji, model: improverBot().model, providerId: improverBot().providerId } : null,
    routine: r ? { id: r.id, enabled: r.enabled, nextRunAt: r.nextRunAt ?? null, lastResult: r.lastResult ?? null } : null,
    shown: all.filter((p) => p.status === "shown"),
    waiting: all.filter((p) => p.status === "waiting").length,
    history: all.filter((p) => !["shown", "waiting", "building"].includes(p.status)).slice(0, 30),
    lastNight: listNights()[0] ?? null,
    building: all.filter((p) => p.status === "building"),
    versions: engineVersions()
  };
}
var import_node_fs11, import_node_path10, IMPROVE_SYSTEM, MAX_PER_NIGHT, IMPROVER_MODEL, settingsFile2, proposals, nights, improveSettings, listProposals, getProposal, nightFor, listNights, improverBot, isImprover, OLD_IMPROVER_PERSONA, IMPROVER_PERSONA, IMPROVE_PROMPT, improveRoutine, HM2, since, ROUTINE_FIELDS, ticker, same, requestText, buildTimer, listening;
var init_improve = __esm({
  "src/improve.ts"() {
    "use strict";
    import_node_fs11 = __toESM(require("node:fs"), 1);
    import_node_path10 = __toESM(require("node:path"), 1);
    init_store();
    init_events();
    init_util();
    init_config();
    init_time();
    init_bots();
    init_routines();
    init_schedule();
    init_skills();
    init_notify();
    init_agent();
    init_bots();
    init_scheduler();
    init_audit();
    init_selfupdate();
    init_phone_notifications();
    init_cloud_keys();
    init_bridge();
    IMPROVE_SYSTEM = "self-improve";
    MAX_PER_NIGHT = 5;
    IMPROVER_MODEL = "claude-opus-5-5";
    settingsFile2 = collection("improve-settings", { enabled: true, botId: null, nightTime: "02:30", showTime: "12:00" });
    proposals = collection("improvements", []);
    nights = collection("improve-nights", []);
    settingsFile2.update((s) => {
      if (s.codingPlatform === "github") s.codingPlatform = "github-claude";
    });
    improveSettings = () => settingsFile2.get();
    listProposals = () => proposals.get().slice().reverse();
    getProposal = (pid) => proposals.get().find((p) => p.id === pid);
    nightFor = (runId) => nights.get().find((n) => n.runId === runId);
    listNights = () => nights.get().slice().reverse();
    improverBot = () => {
      const s = settingsFile2.get();
      return s.botId ? getBot(s.botId) : void 0;
    };
    isImprover = (botId) => settingsFile2.get().botId === botId;
    OLD_IMPROVER_PERSONA = "You are Improver, MausDroid's self-improvement bot. Each night you look for the few changes that would most help right now: errors, failing or missed routines, unclear or broken skills, and small code fixes. You are brief, concrete and never exhaustive. You never change anything yourself without the person's approval.";
    IMPROVER_PERSONA = `You are Improver, MausDroid's self-improvement bot, with admin rights over MausDroid's set-up.
- When the person asks you directly for a change, do it now \u2014 don't make a suggestion card. You can change any bot (bot_list, bot_edit: instructions, AI and model, tool switches, single tools, skills, approvals of other bots), any routine (routine_admin_list, routine_admin_update), skills (skill_save) and see every tool (tool_list). After changing something, call improve_record so it shows in Improvements history, and say briefly what you changed (bot changes can be undone in Settings \u2192 Tools).
- If they ask to remove or cancel a suggestion, call improve_withdraw.
- Changes to MausDroid's own program (new screens, features, fixes in its code): call improve_build with a short title and a clear, complete spec. The coding agent of the chosen platform (GitHub + Claude Code or GitHub + Codex, in Improvements \u2192 Settings) makes the change in the cloud, runs every test, and \u2014 if they pass \u2014 it installs by itself; MausDroid restarts with it. Tell them it usually takes 5\u201320 minutes and they'll get a notification.
- While it builds you'll get progress lines; if the developer asks questions, you'll be told \u2014 ask the person and pass their answers on with improve_build_answer.
- If something is wrong after an update, or they ask to go back: improve_versions shows the versions kept on the phone, improve_rollback switches back at once (MausDroid restarts).
- In the nightly check (a routine), only suggest (improve_propose, at most 5); nothing changes until approved.
Be brief and concrete.`;
    IMPROVE_PROMPT = `Nightly self-check. You have 10 minutes at most; research tools stop after 5, so be quick and don't be exhaustive.
1. Call improve_evidence to see recent errors, routine runs, routines, skills and earlier suggestions.
2. Pick the few changes that would help most right now: errors, failing / missed / timed-out routines and the prompts or schedules causing them, skills that are missing, broken or unclear, and \u2014 only if clearly worthwhile \u2014 small code fixes to MausDroid. A quick web_search or skills_market_search is fine if it helps find a fix.
   assistantExamples (if any) are recent notifications from Meta's Muse assistant: they show what a good assistant anticipates for the person. If MausDroid doesn't anticipate a need Muse does, a new or better routine is a good suggestion.
3. Call improve_propose ONCE with at most ${MAX_PER_NIGHT} suggestions (fewer is better; none if nothing is worth changing). Don't repeat earlier suggestions. For a routine fix include routine_patch with the exact new values; for a skill fix include the complete new SKILL.md. Never include passwords, tokens, card numbers or other credentials.
4. Call improve_finish with a one-line summary.
Don't notify the person: the suggestions are shown at midday as cards, and nothing changes until they approve.`;
    improveRoutine = () => listRoutines().find((r) => r.system === IMPROVE_SYSTEM);
    HM2 = /^([01]\d|2[0-3]):[0-5]\d$/;
    since = (iso, hours) => Boolean(iso) && Date.now() - new Date(iso).getTime() < hours * 36e5;
    ROUTINE_FIELDS = [
      ["title", "title"],
      ["prompt", "prompt"],
      ["schedule", "schedule"],
      ["timeout_minutes", "timeoutMinutes"],
      ["enabled", "enabled"]
    ];
    ticker = null;
    same = (a, b) => JSON.stringify(a ?? null) === JSON.stringify(b ?? null);
    requestText = (p) => `${p.title}

${p.problem}

${p.change}`;
    buildTimer = null;
    listening = false;
  }
});

// src/share.ts
function shareKind(text, attachments = []) {
  const url = text.match(/https?:\/\/[^\s<>"']+/)?.[0];
  if (url) {
    try {
      const host = new URL(url).hostname.toLowerCase().replace(/^www\.|^m\./, "");
      for (const [re, kind] of SITES) if (re.test(host)) return kind;
      return "web page";
    } catch {
      return "link";
    }
  }
  const a = attachments[0];
  if (a) {
    const m = a.mime ?? "";
    if (m.startsWith("image/")) return attachments.length > 1 ? "photos" : "photo";
    if (m.startsWith("video/")) return "video";
    if (m.startsWith("audio/")) return "audio";
    return attachments.length > 1 ? "files" : "file";
  }
  return "text";
}
function shareBot() {
  const bots = listBots().filter((b) => !b.hidden);
  return bots.find((b) => b.name.trim().toLowerCase() === "maus") ?? bots.find((b) => b.pinned) ?? bots[0];
}
function alertFor(s) {
  return { id: s.id, title: `Shared: ${s.kind}`, body: [s.text, ...s.attachments.map((a) => a.name)].filter(Boolean).join("\n"), priority: "normal", at: s.at, read: true, type: "share", source: s.kind, eventId: s.id };
}
function receiveShare(input) {
  const bot = shareBot();
  if (!bot) throw new Error("Create a bot first.");
  const text = clip(String(input.text ?? "").trim(), 4e3);
  const atts = input.attachments ?? [];
  if (!text && !atts.length) throw new Error("Nothing was shared.");
  const rec = {
    id: id("share"),
    at: now(),
    kind: shareKind(text, atts),
    text,
    urls: text.match(/https?:\/\/[^\s<>"']+/g) ?? [],
    attachments: atts.map((a) => ({ id: a.id, name: a.name, mime: a.mime })),
    botId: bot.id,
    forwarded: []
  };
  shares.update((l) => {
    l.push(rec);
    if (l.length > 300) l.splice(0, l.length - 300);
  });
  const alert = alertFor(rec);
  const auto = listRoutines().filter((r) => matchesAlert(r, alert));
  void notifyUser({ title: alert.title, body: alert.body.slice(0, 300), type: "share", source: rec.kind, eventId: rec.id, silentRecord: true });
  const candidates = listRoutines().filter((r) => r.enabled && r.system !== "self-improve");
  const lines2 = candidates.map((r) => `- ${r.id}: "${r.title}" (${getBot(r.botId)?.name ?? "?"}; ${describeSchedule(r.schedule)})${auto.some((a) => a.id === r.id) ? " \u2014 already runs automatically for shares" : ""} \u2014 ${clip(r.prompt.replace(/\s+/g, " "), 160)}`);
  sendToBot(
    bot.id,
    `\u{1F4E5} Shared with you from another app \u2014 ${rec.kind} (share id ${rec.id}):
${text || "(no text)"}${describeFiles(rec)}

[How to handle a share: work out what it is \u2014 open the link with web_fetch or the browser if you need to (for videos use the title, description or captions; don't download them). Then, if it fits one or more of the routines below, call routine_forward with share_id ${rec.id}, the routine id and a one-line reason. Only forward where it clearly fits; skip routines that already run automatically. If nothing fits, deal with it yourself briefly (summarise it, or save it to memory if it's worth keeping) and say what you did. Reply in a sentence or two.
Routines:
${lines2.join("\n") || "(none yet \u2014 you could suggest one if this kind of share will come up often)"}]`,
    "share",
    atts
  );
  emit("share", { share: rec });
  return rec;
}
function forwardShare(sid, routineId, note = "") {
  const s = getShare(sid);
  if (!s) throw new Error("No share with that id.");
  if (Date.now() - new Date(s.at).getTime() > 24 * 36e5) throw new Error("That share is more than a day old.");
  const r = getRoutine(routineId);
  if (!r) throw new Error("No routine with that id. Use the ids from the share message.");
  if (!r.enabled) throw new Error(`"${r.title}" is paused.`);
  if (matchesAlert(r, alertFor(s))) return { already: true, title: r.title };
  if (s.forwarded.some((f) => f.routineId === r.id)) return { already: true, title: r.title };
  const bot = getBot(s.botId);
  const run = execute(r, `share@${s.id}`, "share", {
    extra: `
The person shared this (forwarded to this routine by ${bot?.name ?? "Maus"}): ${s.kind}
${s.text || "(no text)"}${describeFiles(s)}${note ? `
Why it came to this routine: ${note}` : ""}
Use it for this routine now.`
  });
  if (!run) throw new Error(`Couldn't start "${r.title}" (its bot is missing).`);
  shares.update((l) => {
    const x = l.find((y) => y.id === s.id);
    x?.forwarded.push({ routineId: r.id, title: r.title, at: now(), runId: run.id, note: clip(note, 200) });
  });
  emit("share", { shareId: s.id });
  return { already: false, title: r.title, runId: run.id, status: run.status };
}
var shares, listShares, getShare, SITES, describeFiles;
var init_share = __esm({
  "src/share.ts"() {
    "use strict";
    init_store();
    init_events();
    init_util();
    init_bots();
    init_agent();
    init_notify();
    init_routines();
    init_scheduler();
    init_schedule();
    shares = collection("shares", []);
    listShares = () => shares.get().slice().reverse().slice(0, 50);
    getShare = (sid) => shares.get().find((s) => s.id === sid);
    SITES = [
      [/(^|\.)(youtube\.com|youtu\.be)$/, "YouTube video"],
      [/(^|\.)tiktok\.com$/, "TikTok video"],
      [/(^|\.)instagram\.com$/, "Instagram post"],
      [/(^|\.)(facebook\.com|fb\.watch)$/, "Facebook post"],
      [/(^|\.)(x\.com|twitter\.com)$/, "X post"],
      [/(^|\.)reddit\.com$/, "Reddit post"],
      [/(^|\.)spotify\.com$/, "Spotify link"],
      [/(^|\.)google\.[a-z.]+$|(^|\.)goo\.gl$/, "Google link"]
    ];
    describeFiles = (s) => s.attachments.length ? `
Files: ${s.attachments.map((a) => `${a.name} (file id ${a.id} \u2014 open with file_read)`).join("; ")}` : "";
  }
});

// src/bot-admin.ts
function findBot(ref) {
  const r = String(ref ?? "").trim();
  return getBot(r) ?? listBots().find((b) => b.name.trim().toLowerCase() === r.toLowerCase());
}
function planBotEdit(editor, i) {
  const target = findBot(String(i.bot_id ?? ""));
  if (!target) throw new Error(`No bot "${i.bot_id}". Use bot_list to see them.`);
  const after = {};
  if (i.name !== void 0) {
    if (!String(i.name).trim()) throw new Error("A bot needs a name.");
    after.name = String(i.name).trim().slice(0, 60);
  }
  if (i.emoji !== void 0) after.emoji = String(i.emoji).slice(0, 8);
  if (i.persona !== void 0) after.persona = clip(String(i.persona), 8e3);
  if (i.provider_id !== void 0) after.providerId = i.provider_id || null;
  if (i.model !== void 0) after.model = i.model || null;
  if (i.tools) after.tools = { ...target.tools, ...Object.fromEntries(Object.entries(i.tools).filter(([k]) => ["web", "browser", "apps", "phone"].includes(k)).map(([k, v]) => [k, Boolean(v)])) };
  if (i.enable_tools?.length || i.disable_tools?.length) {
    const off = new Set(target.disabledTools ?? []);
    for (const t of i.enable_tools ?? []) off.delete(String(t));
    for (const t of i.disable_tools ?? []) off.add(String(t));
    after.disabledTools = [...off].sort();
  }
  if (i.skills !== void 0) after.skills = (i.skills ?? []).map(String);
  if (i.approval_mode !== void 0) {
    if (!["ask-risky", "ask-all", "auto"].includes(i.approval_mode)) throw new Error("approval_mode is ask-risky, ask-all or auto.");
    if (target.id === editor.id) throw new Error("A bot can't change its own approval settings \u2014 only you can, in the bot editor.");
    after.approvalMode = i.approval_mode;
  }
  if (!Object.keys(after).length) throw new Error("Nothing to change.");
  const before = {};
  for (const k of Object.keys(after)) before[k] = target[k] ?? null;
  return { target, before, after };
}
function describeEdit(target, before, after) {
  const show = (v) => clip(typeof v === "string" ? v : JSON.stringify(v ?? null), 160);
  return `Change ${target.emoji} ${target.name}: ${Object.keys(after).map((k) => `${k}: ${show(before[k])} \u2192 ${show(after[k])}`).join("; ")}`;
}
function applyBotEdit(editor, i) {
  const { target, before, after } = planBotEdit(editor, i);
  updateBot(target.id, after);
  const c = { id: id("bchg"), at: now(), botId: target.id, botName: after.name ?? target.name, by: editor.name, before, after };
  changes.update((l) => {
    l.push(c);
    if (l.length > 300) l.splice(0, l.length - 300);
  });
  emit("settings.changed");
  return c;
}
function undoBotChange(cid) {
  const c = changes.get().find((x) => x.id === cid);
  if (!c) throw new Error("No such change.");
  if (c.undoneAt) throw new Error("Already undone.");
  const bot = getBot(c.botId);
  if (!bot) throw new Error("That bot no longer exists.");
  const moved = Object.keys(c.after).find((k) => JSON.stringify(bot[k] ?? null) !== JSON.stringify(c.after[k] ?? null));
  if (moved) throw new Error(`The bot's ${moved} has changed again since, so this can't be undone automatically.`);
  updateBot(bot.id, c.before);
  changes.update((l) => {
    const x = l.find((y) => y.id === cid);
    if (x) x.undoneAt = now();
  });
  emit("settings.changed");
  return { ...c, undoneAt: now() };
}
function botSummary(b) {
  return { id: b.id, name: b.name, emoji: b.emoji, persona: clip(b.persona, 600), providerId: b.providerId, model: b.model, tools: b.tools, disabledTools: b.disabledTools ?? [], skills: b.skills, approvalMode: b.approvalMode, pinned: b.pinned };
}
function setToolForBots(tool, botIds, enabled) {
  for (const id2 of botIds) {
    const b = getBot(id2);
    if (!b) continue;
    const off = new Set(b.disabledTools ?? []);
    if (enabled) off.delete(tool);
    else off.add(tool);
    updateBot(id2, { disabledTools: [...off].sort() });
  }
  emit("settings.changed");
}
var changes, listBotChanges;
var init_bot_admin = __esm({
  "src/bot-admin.ts"() {
    "use strict";
    init_store();
    init_events();
    init_util();
    init_bots();
    changes = collection("bot-changes", []);
    listBotChanges = () => changes.get().slice().reverse().slice(0, 60);
  }
});

// src/tools/index.ts
function browserNeeded() {
  if (!bridgeAvailable()) throw new Error("The background browser needs the Android app.");
}
function mayHave(bot, name) {
  if (name === "call_user") return isCallBot(bot.id);
  if (ONLY_IMPROVER.test(name)) return isImprover(bot.id);
  if (ONLY_MAUS_OR_IMPROVER.test(name)) return isImprover(bot.id) || callBot()?.id === bot.id;
  return true;
}
function onlyFor(name) {
  if (name === "call_user") return "Maus";
  if (ONLY_IMPROVER.test(name)) return "Improver";
  if (ONLY_MAUS_OR_IMPROVER.test(name)) return "Maus and Improver";
  return null;
}
function toolCatalog() {
  return allBuiltins().map((t) => ({
    name: t.spec.name,
    description: t.spec.description,
    group: t.group,
    risky: Boolean(t.alwaysAsk || t.risk || WRITE_WORDS.test(t.spec.name.replace(/^(web|skill|memory|routine)_(read|list|search|fetch)$/, ""))),
    onlyFor: onlyFor(t.spec.name)
  }));
}
async function toolsFor(bot) {
  const list = allBuiltins().filter((t) => t.group === "core" || bot.tools[t.group]);
  const off = new Set(bot.disabledTools ?? []);
  const allowed = list.filter((t) => mayHave(bot, t.spec.name) && !off.has(t.spec.name));
  list.length = 0;
  list.push(...allowed);
  if (bot.tools.apps) {
    try {
      for (const spec of await composioTools())
        list.push({
          group: "apps",
          spec,
          risk: (i) => {
            const n = spec.name.toUpperCase();
            if (n.includes("SEARCH_TOOLS") || n.includes("GET_TOOL_SCHEMAS") || n.includes("MANAGE_CONNECTIONS")) return null;
            if (n.includes("WORKBENCH") || n.includes("BASH")) return "Run code in Composio's cloud workbench";
            const slugs = (i?.tools ?? []).map((t) => String(t.tool_slug ?? ""));
            const writes = slugs.filter((s) => WRITE_WORDS.test(s));
            return writes.length ? `Use connected apps: ${writes.join(", ")}` : null;
          },
          run: async (_c, input) => callComposio(spec.name, input)
        });
      for (let i = list.length - 1; i >= 0; i--) if (off.has(list[i].spec.name)) list.splice(i, 1);
    } catch {
    }
  }
  return list;
}
function describeSkills(names) {
  const skills = listSkills().filter((s) => !names.length || names.includes(s.name));
  if (!skills.length) return "";
  return `

# Skills
Open a skill with skill_read before a task it covers:
${skills.map((s) => `- ${s.name}: ${s.description}`).join("\n")}`;
}
function memoryContext(botId) {
  const me = readMemory("about-me").slice(-6e3);
  const mine = readMemory(botId).slice(-4e3);
  return `${me ? `

# What you know about the person
${me}` : ""}${mine ? `

# Your own notes
${mine}` : ""}`;
}
function scheduleFrom(i) {
  return {
    kind: i.kind,
    time: i.time,
    days: i.days,
    timeZone: i.time_zone,
    custom: i.custom,
    window: i.window,
    conditions: i.conditions,
    alert: i.alert,
    missedPolicy: i.missed_policy,
    at: i.at,
    minutes: i.minutes
  };
}
function ownRoutine(bot, rid) {
  const r = getRoutine(String(rid));
  if (!r || r.botId !== bot.id) throw new Error("No routine with that id belongs to you. Use routine_list to see yours.");
  return r;
}
function routineTools() {
  return [
    {
      group: "core",
      spec: {
        name: "routine_create",
        description: "Create a routine: Once a Day, Once a Week, Upon Alert, or Custom (intervals of 15+ minutes, specific dates, recurring). Write the prompt as instructions to yourself, including when to call notify_user.",
        inputSchema: obj({ title: str("Short name"), prompt: str("What to do each time"), ...scheduleSchema }, ["title", "prompt", "kind"])
      },
      run: async (c, i) => {
        const r = createRoutine({ botId: c.bot.id, title: i.title, prompt: i.prompt, schedule: scheduleFrom(i) });
        return `Created routine "${r.title}" (id ${r.id}): ${describeSchedule(r.schedule)}. Next run: ${r.nextRunAt ?? (r.schedule.kind === "alert" ? "when a matching alert arrives" : "none")}.`;
      }
    },
    {
      group: "core",
      spec: { name: "routine_list", description: "List your routines with their full prompt, schedule, state, next/last run, last result and history summary.", inputSchema: obj({}) },
      run: async (c) => JSON.stringify(listRoutines(c.bot.id).map(routineDetails), null, 1)
    },
    {
      group: "core",
      spec: {
        name: "routine_update",
        description: "Change one of your routines (keeps its id). Give only what changes: title, prompt and/or schedule fields. The person approves the change.",
        inputSchema: obj({ id: str("Routine id"), title: str("New title"), prompt: str("New prompt"), ...scheduleSchema, kind: { ...scheduleSchema.kind, description: "New schedule kind (only when changing the schedule)" } }, ["id"])
      },
      alwaysAsk: true,
      risk: (i) => `Change routine ${getRoutine(String(i.id))?.title ?? i.id}`,
      permission: () => routinePermission,
      run: async (c, i) => {
        const r = ownRoutine(c.bot, i.id);
        const patch3 = {};
        if (i.title) patch3.title = i.title;
        if (i.prompt) patch3.prompt = i.prompt;
        if (i.kind) patch3.schedule = scheduleFrom(i);
        const u = updateRoutine(r.id, patch3);
        return `Updated "${u.title}" (id ${u.id}): ${describeSchedule(u.schedule)}. Next run: ${u.nextRunAt ?? "\u2014"}.`;
      }
    },
    {
      group: "core",
      spec: { name: "routine_delete", description: "Delete one of your routines. The person approves it.", inputSchema: obj({ id: str("Routine id") }, ["id"]) },
      alwaysAsk: true,
      risk: (i) => `Delete routine ${getRoutine(String(i.id))?.title ?? i.id}`,
      permission: () => routinePermission,
      run: async (c, i) => {
        const r = ownRoutine(c.bot, i.id);
        deleteRoutine(r.id);
        return `Deleted "${r.title}".`;
      }
    },
    {
      group: "core",
      spec: { name: "routine_run_now", description: "Start one of your routines now (it's queued and reported when it actually finishes).", inputSchema: obj({ id: str("Routine id") }, ["id"]) },
      run: async (c, i) => {
        const r = ownRoutine(c.bot, i.id);
        const run = runRoutineNow(r.id);
        return `Queued run ${run.id} of "${r.title}" (status: ${run.status}). Check routine_history for the result.`;
      }
    },
    {
      group: "core",
      spec: { name: "routine_history", description: "Recent runs of one of your routines: status, times, result or error.", inputSchema: obj({ id: str("Routine id"), limit: { type: "number" } }, ["id"]) },
      run: async (c, i) => {
        const r = ownRoutine(c.bot, i.id);
        return JSON.stringify(listRuns(r.id, Math.min(50, Number(i.limit ?? 10))).map(({ botId, routineId, ...run }) => run), null, 1);
      }
    },
    {
      group: "core",
      spec: { name: "routine_pause", description: "Pause one of your routines (it won't run until resumed).", inputSchema: obj({ id: str("Routine id") }, ["id"]) },
      run: async (c, i) => `Paused "${pauseRoutine(ownRoutine(c.bot, i.id).id).title}".`
    },
    {
      group: "core",
      spec: { name: "routine_resume", description: "Resume a paused routine of yours.", inputSchema: obj({ id: str("Routine id") }, ["id"]) },
      run: async (c, i) => {
        const u = resumeRoutine(ownRoutine(c.bot, i.id).id);
        return `Resumed "${u.title}". Next run: ${u.nextRunAt ?? "when triggered"}.`;
      }
    }
  ];
}
function calendarTools() {
  return [
    {
      group: "apps",
      spec: {
        name: "calendar_list",
        description: "List every Google calendar across the person's connected accounts: account alias, calendar name, id, access (owner/writer can add events; reader is read-only), and which one is the chosen destination. Also lists accounts that couldn't be read and why.",
        inputSchema: obj({})
      },
      run: async () => {
        const d = await discoverCalendars();
        return JSON.stringify({ destination: getDestination(), calendars: d.calendars, problems: d.problems }, null, 1);
      }
    },
    {
      group: "apps",
      spec: {
        name: "calendar_create_event",
        description: "Add an event to Google Calendar. Goes to the chosen destination calendar unless you name one (calendar). Checks for an identical event first and confirms the event exists afterwards. The person approves it.",
        inputSchema: obj(
          {
            summary: str("Title"),
            start: str('Local start "YYYY-MM-DDTHH:MM"'),
            duration_minutes: { type: "number", description: "Default 60" },
            calendar: str("Calendar name or id (optional; default = the chosen destination)"),
            description: str("Notes"),
            location: str("Place"),
            time_zone: str("e.g. Australia/Sydney")
          },
          ["summary", "start"]
        )
      },
      alwaysAsk: true,
      risk: (i) => `Add "${i.summary}" on ${String(i.start).replace("T", " ")} to ${i.calendar ?? getDestination()?.name ?? "your calendar"}`,
      permission: () => ({ key: "calendar:write", label: "adding events to your calendars" }),
      run: async (_c, i) => {
        const r = await createEvent(
          { summary: i.summary, start: i.start, durationMinutes: i.duration_minutes, description: i.description, location: i.location, timeZone: i.time_zone },
          i.calendar ? { name: i.calendar } : void 0
        );
        return { text: JSON.stringify(r, null, 1), isError: r.status === "failed" };
      }
    }
  ];
}
function briefTools() {
  return [
    {
      group: "core",
      spec: {
        name: "morning_brief_prepare",
        description: "Gather today's Morning Brief facts: school day / term week (from confirmed term dates), today's calendar events, this week's Staff Update (found in Google Drive by title and content, with its link), Thursday sport rows from this week's sport-matrix tab, recent notices, the calendar destination status, the person's brief preferences (with which are confirmed vs assumed), plus warnings and source links. Never substitutes older documents.",
        inputSchema: obj({ date: str("YYYY-MM-DD (default today)") })
      },
      run: async (_c, i) => JSON.stringify(await prepareBrief(i.date), null, 1)
    },
    {
      group: "core",
      spec: {
        name: "morning_brief_publish",
        description: "Save the finished Morning Brief to the Briefing screen and send the 'Morning Brief ready' notification linking to it. Proposed calendar events wait for the person's approval on that screen.",
        inputSchema: obj(
          {
            date: str("YYYY-MM-DD (default today)"),
            summary: str("The brief, in plain words (Markdown ok)"),
            staff_update_summary: str("Key Staff Update items"),
            notices: { type: "array", items: { type: "string" } },
            proposed_events: { type: "array", items: { type: "object", properties: { summary: { type: "string" }, start: { type: "string", description: "YYYY-MM-DDTHH:MM" }, duration_minutes: { type: "number" }, reason: { type: "string" } }, required: ["summary", "start"] } },
            extra_warnings: { type: "array", items: { type: "string" } }
          },
          ["summary"]
        )
      },
      run: async (c, i) => {
        const b = await publishBrief(i, c.bot.id);
        return `Published briefing ${b.id} for ${b.date} (${b.warnings.length} warnings, ${b.proposedEvents.length} proposed events). The person was notified.`;
      }
    }
  ];
}
function auditRunId(bot) {
  return currentRunTags(bot.id).find((t) => t.startsWith("run_")) ?? `chat-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}-${bot.id}`;
}
function auditTools() {
  return [
    {
      group: "web",
      spec: { name: "skills_market_search", description: "Search GitHub for agent skills (claude-skills / agent-skills repos) installable through MausDroid's Skills marketplace. Returns owner/repo, description, stars.", inputSchema: obj({ query: str("Search words") }) },
      run: async (_c, i) => JSON.stringify(await searchMarketplace(String(i.query ?? "")), null, 1)
    },
    {
      group: "core",
      spec: { name: "audit_begin", description: "Start the weekly audit: records the research window (5-minute cutoff) and checks the private wiki.", inputSchema: obj({}) },
      run: async (c) => {
        const runId = auditRunId(c.bot);
        const run = getRun(runId);
        const start = run?.startedAt ? new Date(run.startedAt) : /* @__PURE__ */ new Date();
        const r = run ? getRoutine(run.routineId) : void 0;
        const cutoff = new Date(start.getTime() + (r?.researchCutoffMinutes ?? 5) * 6e4);
        const wiki = await checkWiki();
        upsertAudit(runId, { startedAt: start.toISOString(), researchCutoffAt: cutoff.toISOString(), wiki });
        return `Audit started. Research tools stop at ${cutoff.toISOString()} (in ${Math.max(0, Math.round((cutoff.getTime() - Date.now()) / 1e3))} s). Wiki: ${wiki.detail}`;
      }
    },
    {
      group: "core",
      spec: {
        name: "audit_score",
        description: "Score audit candidates (/25; safety is a hard gate), remove duplicates (this audit and the wiki), rank them. Call once with all candidates.",
        inputSchema: obj({ candidates: { type: "array", items: { type: "object" }, description: "Each: name, source_ecosystem, source_url, summary, utility, adoption, scope_fit, setup, privacy (1-5), phase, primitives[], composio[], account_alias, github_repo?, action_type, safety{flag:bool}, alignment{what,why,integrations,implementation,workaround,upgrade_path,privacy}" } }, ["candidates"])
      },
      run: async (c, i) => {
        const runId = auditRunId(c.bot);
        const scored = (Array.isArray(i.candidates) ? i.candidates : []).map((x) => scoreCandidate({ primitives: [], ...x }));
        let wikiList = [];
        let wikiErr = "";
        try {
          wikiList = await wikiEntries();
        } catch (e) {
          wikiErr = e.message;
        }
        const accepted = scored.filter((x) => x.accepted);
        const { kept, duplicates } = dedupe(accepted, wikiList);
        const all = [...kept, ...scored.filter((x) => !x.accepted)];
        upsertAudit(runId, { scored: all, duplicates });
        const ranked = rank(all);
        return JSON.stringify({ accepted: ranked.map((x) => ({ rank: x.rank, name: x.name, total: x.total, phase: x.phase, slug: x.slug })), rejected: all.filter((x) => !x.accepted).map((x) => ({ name: x.name, reasons: x.reasons })), duplicates, wikiCheck: wikiErr || "ok", overflowToFile: Math.max(0, ranked.length - 20) }, null, 1);
      }
    },
    {
      group: "core",
      spec: { name: "audit_file_overflow", description: "File every accepted candidate ranked 21 or lower in the private wiki (verified by reading back). Refuses if the wiki isn't private.", inputSchema: obj({}) },
      run: async (c) => {
        const runId = auditRunId(c.bot);
        const rec = auditFor(runId);
        if (!rec) return { text: "Call audit_score first.", isError: true };
        const overflow = rank(rec.scored).slice(20);
        if (!overflow.length) return "Nothing ranked 21 or lower: no wiki filing needed.";
        const wiki = await checkWiki();
        if (!wiki.ok) {
          upsertAudit(runId, { wiki });
          return { text: `Wiki unavailable: ${wiki.detail} (Notion fallback isn't set up.) Nothing filed.`, isError: true };
        }
        const date = rec.startedAt.slice(0, 10);
        const filings = [];
        for (const x of overflow) filings.push({ ...await fileEntry(x, date), phase: x.phase });
        upsertAudit(runId, { filings, wiki });
        const ok = filings.filter((f) => f.ok && f.verified).length;
        return `Filed ${ok} of ${overflow.length} (verified). ${filings.filter((f) => !f.ok || !f.verified).map((f) => `${f.slug}: ${f.detail}`).join("; ")}`;
      }
    },
    {
      group: "core",
      spec: {
        name: "audit_finish",
        description: "Finish the audit: builds the report from the recorded scores and verified filings (no invented results) and saves it. Then call memory_save and notify_user.",
        inputSchema: obj({ unavailable_sources: { type: "array", items: { type: "string" } }, notes: str("Short notes") })
      },
      run: async (c, i) => {
        const runId = auditRunId(c.bot);
        const rec = auditFor(runId);
        if (!rec || !rec.scored.length) return { text: "No scored candidates recorded; the audit is incomplete. Tell the person.", isError: true };
        const updated = upsertAudit(runId, { unavailable: (i.unavailable_sources ?? []).map(String), finishedAt: (/* @__PURE__ */ new Date()).toISOString() });
        const report = buildReport(updated, i.notes ? String(i.notes) : "");
        upsertAudit(runId, { report });
        const ranked = rank(updated.scored);
        const p1 = ranked.find((x) => x.phase === "phase-1-ready");
        const filed = updated.filings.filter((f) => f.ok && f.verified).length;
        return `${report}

---
Next: memory_save (scope "bot") three lines; then notify_user titled "Sunday Routine Audit Ready": top Phase 1 = ${p1?.name ?? "none"}, wiki overflow filed = ${filed}.`;
      }
    }
  ];
}
function locationTools() {
  return [
    {
      group: "core",
      spec: {
        name: "device_location",
        description: "Get the phone's current location once (latitude, longitude, accuracy in metres, timestamp, provider). Only when needed for the task. The person approves; the app shows that you're using location. Never guess coordinates if this fails.",
        inputSchema: obj({ reason: str("Why you need it (shown to the person)"), max_age_minutes: { type: "number", description: "How old a known position may be (default 2)" } }, ["reason"])
      },
      alwaysAsk: true,
      risk: (i) => `Use your location: ${i.reason ?? "no reason given"}`,
      permission: () => ({ key: "location", label: "using your location" }),
      run: async (c, i) => {
        const runId = currentRunTags(c.bot.id).find((t) => t.startsWith("run_"));
        const rt = runId ? getRoutine(getRun(runId)?.routineId ?? "") : void 0;
        const requester = `${c.bot.emoji} ${c.bot.name}${rt ? ` (routine \u201C${rt.title}\u201D)` : ""}`;
        const r = await getLocation(requester, Math.round(Number(i.max_age_minutes ?? 2) * 6e4));
        const err = describeLocationError(r);
        return err ? { text: JSON.stringify({ ...r, message: err }), isError: true } : JSON.stringify(r);
      }
    }
  ];
}
function callTools() {
  return [
    {
      group: "core",
      spec: {
        name: "call_user",
        description: "Phone the person (a ringing call on their phone) when something is worth talking about now. It never rings during their calendar events or lock-out times, and at most a few times an hour \u2014 if it can't call, it tells you why and leaves a quiet note. Prefer notify_user for anything that can wait.",
        inputSchema: obj({ reason: str("Why you're calling (shown on the incoming-call screen)"), opening_line: str("What you'll say first when they answer") }, ["reason"])
      },
      run: async (_c, i) => {
        const c = await ringUser(String(i.reason), i.opening_line ? String(i.opening_line) : void 0);
        if (c.state === "blocked") return `Didn't call: ${c.detail} A quiet notification was left instead.`;
        if (c.state === "declined") return "The person declined the call. Send a message instead if it matters.";
        if (c.state === "missed") return "No answer. A missed-call notification was left.";
        return "They answered. The conversation continues by voice; their words will arrive as messages from the call.";
      }
    }
  ];
}
function shareTools() {
  return [
    {
      group: "core",
      spec: {
        name: "phone_notifications",
        description: "Read notifications MausDroid has captured from the apps the person chose (e.g. Meta's Muse) \u2014 newest first. Read-only: MausDroid never acts in those apps.",
        inputSchema: obj({ app: str("App name to filter by, e.g. Muse"), since_hours: { type: "number", description: "Only the last N hours" }, limit: { type: "number" } })
      },
      run: async (_c, i) => JSON.stringify(recent({ app: i.app ? String(i.app) : void 0, sinceHours: Number(i.since_hours) || void 0, limit: Math.min(200, Number(i.limit) || 50) }).map(({ id: id2, key: key2, pkg, ...n }) => n), null, 1)
    },
    {
      group: "core",
      spec: {
        name: "routine_forward",
        description: "Send something the person shared (a link, video, photo\u2026) to one of their routines, which runs now with it. Use the share id and routine ids from the share message.",
        inputSchema: obj({ share_id: str("The share id"), routine_id: str("The routine to send it to"), note: str("One line: why it belongs there") }, ["share_id", "routine_id"])
      },
      run: async (_c, i) => {
        const r = forwardShare(String(i.share_id), String(i.routine_id), i.note ? String(i.note) : "");
        return r.already ? `"${r.title}" already has it (it runs automatically for shares or was sent it before).` : `Sent to "${r.title}" \u2014 run ${r.runId} is ${r.status}.`;
      }
    }
  ];
}
function improveTools() {
  const runId = (bot) => currentRunTags(bot.id).find((t) => t.startsWith("run_")) ?? `chat-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}-${bot.id}`;
  return [
    {
      group: "core",
      spec: { name: "improve_evidence", description: "Tonight's evidence: recent errors, failed/missed/timed-out routine runs, all routines (with prompts), skills, start-up problems and earlier suggestions (don't repeat them).", inputSchema: obj({}) },
      run: async (c) => {
        beginNight(runId(c.bot));
        return JSON.stringify(collectEvidence(), null, 1);
      }
    },
    {
      group: "core",
      spec: {
        name: "improve_propose",
        description: `Record suggestions (at most ${MAX_PER_NIGHT} a night; fewer is better). Nothing changes now: each becomes a card shown at midday that the person approves or declines.`,
        inputSchema: obj(
          {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: str("Short title"),
                  problem: str("What's wrong or missing, in plain words"),
                  change: str("Exactly what would change"),
                  area: { type: "string", enum: ["routine", "skill", "code", "other"] },
                  risk: { type: "string", enum: ["low", "medium", "high"] },
                  evidence: str("What showed the problem (errors, run ids)"),
                  routine_patch: { type: "object", description: "area=routine: {routine_id, title?, prompt?, schedule?, timeout_minutes?, enabled?} with the exact NEW values" },
                  skill: { type: "object", description: "area=skill: {name, content} where content is the complete new SKILL.md (frontmatter name + description, then instructions)" }
                },
                required: ["title", "problem", "change", "area"]
              }
            }
          },
          ["suggestions"]
        )
      },
      run: async (c, i) => {
        const r = addSuggestions(runId(c.bot), i.suggestions);
        return `Recorded ${r.added.length}: ${r.added.map((p) => p.title).join("; ") || "none"}.${r.refused.length ? ` Not recorded: ${r.refused.map((x) => `${x.title} (${x.reason})`).join("; ")}.` : ""} They'll be shown at ${improveSettings().showTime}.`;
      }
    },
    {
      group: "core",
      spec: { name: "improve_finish", description: "End tonight's check with a one-line summary.", inputSchema: obj({ summary: str("One line") }, ["summary"]) },
      run: async (c, i) => {
        const n = finishNight(runId(c.bot), String(i.summary ?? ""));
        return `Done: ${n.count} suggestion(s) recorded.`;
      }
    }
  ];
}
function adminTools() {
  return [
    {
      group: "core",
      admin: true,
      spec: { name: "bot_list", description: "List all bots with their instructions, AI and model, tool switches, tools switched off, skills and approval setting.", inputSchema: obj({}) },
      run: async () => JSON.stringify(listBotsForTools().map(botSummary), null, 1)
    },
    {
      group: "core",
      admin: true,
      alwaysAsk: true,
      spec: {
        name: "bot_edit",
        description: "Change another bot (or yourself): name, emoji, instructions (persona), AI provider and model, tool switches, single tools on/off, skills, approval setting (not your own). Give only what changes. Every change can be undone in Settings \u2192 Tools.",
        inputSchema: obj(
          {
            bot_id: str("Bot id or name"),
            name: str("New name"),
            emoji: str("New emoji"),
            persona: str("New instructions (the whole text)"),
            provider_id: str("AI provider id (e.g. claude, chatgpt, local) or empty for the default"),
            model: str("Model id, or empty for the provider's default"),
            tools: { type: "object", description: "Tool switches: {web, browser, apps, phone} true/false" },
            enable_tools: { type: "array", items: { type: "string" }, description: "Single tools to switch on (names from tool_list / Settings \u2192 Tools)" },
            disable_tools: { type: "array", items: { type: "string" }, description: "Single tools to switch off" },
            skills: { type: "array", items: { type: "string" }, description: "Skills it may use (empty = all)" },
            approval_mode: { type: "string", enum: ["ask-risky", "ask-all", "auto"] }
          },
          ["bot_id"]
        )
      },
      risk: () => "Change a bot",
      // the approval card shows the exact before → after (see gate)
      permission: () => ({ key: "bots:edit", label: "changing other bots" }),
      run: async (c, i) => {
        const ch = applyBotEdit(c.bot, i);
        return `Changed ${ch.botName} (change ${ch.id}, can be undone): ${Object.keys(ch.after).join(", ")}.`;
      }
    },
    {
      group: "core",
      admin: true,
      spec: { name: "tool_list", description: "Every built-in tool with what it does, whether it can change things, and which bots have it switched off.", inputSchema: obj({}) },
      run: async () => JSON.stringify(toolCatalog().map((t) => ({ ...t, offFor: listBotsForTools().filter((b) => (b.disabledTools ?? []).includes(t.name)).map((b) => b.name) })), null, 1)
    },
    {
      group: "core",
      admin: true,
      spec: { name: "routine_admin_list", description: "All routines of every bot (full details).", inputSchema: obj({}) },
      run: async () => JSON.stringify(listRoutines().map((r) => ({ ...routineDetails(r), bot: getBotName(r.botId) })), null, 1)
    },
    {
      group: "core",
      admin: true,
      spec: {
        name: "routine_admin_update",
        description: "Change any bot's routine (keeps its id): title, prompt, schedule, enabled, timeout_minutes. Give only what changes.",
        inputSchema: obj({ id: str("Routine id"), title: str("New title"), prompt: str("New prompt"), enabled: { type: "boolean" }, timeout_minutes: { type: "number" }, ...scheduleSchema, kind: { ...scheduleSchema.kind, description: "New schedule kind (only when changing the schedule)" } }, ["id"])
      },
      run: async (_c, i) => {
        const r = getRoutine(String(i.id));
        if (!r) throw new Error("No routine with that id. Use routine_admin_list.");
        const patch3 = {};
        if (i.title) patch3.title = i.title;
        if (i.prompt) patch3.prompt = i.prompt;
        if (typeof i.enabled === "boolean") patch3.enabled = i.enabled;
        if (typeof i.timeout_minutes === "number") patch3.timeoutMinutes = Math.max(1, Math.min(60, i.timeout_minutes));
        if (i.kind) patch3.schedule = scheduleFrom(i);
        const u = updateRoutine(r.id, patch3);
        return `Updated "${u.title}" (${getBotName(u.botId)}): ${describeSchedule(u.schedule)}${u.enabled ? "" : " (paused)"}.`;
      }
    },
    {
      group: "core",
      admin: true,
      spec: { name: "skill_save", description: "Create or replace a skill: the complete SKILL.md (frontmatter with name and description, then instructions).", inputSchema: obj({ name: str("Skill name"), content: str("Complete SKILL.md") }, ["name", "content"]) },
      run: async (_c, i) => {
        if (!/^---[\s\S]*?name:[\s\S]*?description:[\s\S]*?---/.test(String(i.content))) throw new Error("SKILL.md needs frontmatter with name and description.");
        return `Saved skill "${saveSkill(String(i.name), String(i.content))}".`;
      }
    },
    {
      group: "core",
      admin: true,
      spec: { name: "improve_record", description: "Record a change you just made at the person's request, so it shows in Improvements history (applied).", inputSchema: obj({ title: str("Short title"), change: str("What you changed"), area: { type: "string", enum: ["routine", "skill", "code", "other"] } }, ["title", "change"]) },
      run: async (_c, i) => `Recorded: ${recordApplied(String(i.title), String(i.change), i.area ?? "other").title}`
    },
    {
      group: "core",
      admin: true,
      spec: {
        name: "improve_build",
        description: "Change MausDroid's own program (screens, features, fixes): the chosen coding platform (GitHub + Claude Code or GitHub + Codex) makes the change in the cloud from your spec, runs every test, and if they pass it's installed and MausDroid restarts with it (usually 5\u201320 minutes; the person gets a notification). Write a complete, specific spec.",
        inputSchema: obj({ title: str("Short title"), spec: str("What to change, in detail: behaviour, screens, edge cases") }, ["title", "spec"])
      },
      run: async (_c, i) => {
        const p = await requestBuild(String(i.title), String(i.spec));
        return p.status === "failed" ? `Couldn't start: ${p.result}` : `Building "${p.title}" in the cloud (id ${p.id}). ${p.result}`;
      }
    },
    {
      group: "core",
      admin: true,
      spec: { name: "improve_build_answer", description: "Pass the person's answers to a cloud build's questions; the build carries on with them.", inputSchema: obj({ id: str("The build's improvement id"), answers: str("Their answers, numbered like the questions") }, ["id", "answers"]) },
      run: async (_c, i) => {
        const p = await answerBuild(String(i.id), String(i.answers));
        return `Sent \u2014 "${p.title}" is carrying on (attempt ${p.build?.attempt}).`;
      }
    },
    {
      group: "core",
      admin: true,
      spec: { name: "improve_versions", description: "MausDroid program versions kept on the phone (which is running, which were set aside) and cloud builds in progress.", inputSchema: obj({}) },
      run: async () => JSON.stringify({ ...engineVersions(), building: listProposals().filter((p) => p.status === "building").map((p) => ({ id: p.id, title: p.title, since: p.build?.startedAt, progress: p.build?.runUrl })) }, null, 1)
    },
    {
      group: "core",
      admin: true,
      spec: { name: "improve_rollback", description: "Go back to an earlier MausDroid program version kept on the phone (default: the one before the running version). MausDroid restarts in a few seconds; the version you leave isn't installed again.", inputSchema: obj({ version: str("Version to go back to, e.g. 0.8.2 (optional)") }) },
      run: async (_c, i) => {
        const r = rollBack(i.version ? String(i.version) : void 0);
        recordApplied(`Rolled back ${r.from} \u2192 ${r.to}`, `Went back from ${r.from} to ${r.to}.`, "code");
        return `Going back from ${r.from} to ${r.to}; MausDroid restarts in a few seconds.`;
      }
    },
    {
      group: "core",
      admin: true,
      spec: { name: "improve_withdraw", description: "Withdraw waiting or shown suggestion cards the person no longer wants (by id or title words).", inputSchema: obj({ ids: { type: "array", items: { type: "string" }, description: "Suggestion ids or words from their titles" } }, ["ids"]) },
      run: async (_c, i) => {
        const r = withdraw((i.ids ?? []).map(String));
        return r.length ? `Withdrew: ${r.map((p) => p.title).join("; ")}.` : "No matching waiting suggestions.";
      }
    }
  ];
}
function permissionFor(tool, input) {
  if (tool.permission) return tool.permission(input);
  if (tool.spec.name.startsWith("composio__")) {
    const slugs = (input?.tools ?? []).map((t) => String(t.tool_slug ?? ""));
    const writes = slugs.filter((x) => WRITE_WORDS.test(x));
    const kits = [...new Set(writes.map((x) => x.split("_")[0].toLowerCase()))].sort();
    if (kits.length) return { key: `apps:${kits.join("+")}:write`, label: `changing things in ${kits.join(", ")}` };
    if (/WORKBENCH|BASH/i.test(tool.spec.name)) return { key: "apps:workbench", label: "running code in Composio's workbench" };
  }
  return { key: tool.spec.name, label: tool.spec.name.replace(/_/g, " ") };
}
async function gate(bot, tool, input, signal) {
  if (RESEARCH_TOOLS.test(tool.spec.name)) {
    const run = getRun(currentRunTags(bot.id).find((t) => t.startsWith("run_")) ?? "");
    const r = run ? getRoutine(run.routineId) : void 0;
    if (run?.startedAt && r?.researchCutoffMinutes && Date.now() > new Date(run.startedAt).getTime() + r.researchCutoffMinutes * 6e4)
      return { allow: false, reason: `Research cutoff reached (${r.researchCutoffMinutes} min). Stop researching and score, file and report what you have.` };
  }
  if (tool.admin && isImprover(bot.id)) return { allow: true };
  let reason = tool.risk?.(input) ?? null;
  if (tool.spec.name === "bot_edit") {
    try {
      const plan = planBotEdit(bot, input);
      reason = describeEdit(plan.target, plan.before, plan.after);
    } catch (e) {
      return { allow: false, reason: e.message };
    }
  }
  const ask = tool.alwaysAsk || bot.approvalMode === "ask-all" || bot.approvalMode === "ask-risky" && Boolean(reason);
  if (!ask) return { allow: true };
  if (tool.spec.name.startsWith("composio__") && COMPOSIO_READONLY.test(tool.spec.name)) return { allow: true };
  const perm = permissionFor(tool, input);
  return requestApproval(bot.id, perm.key, reason ?? `Use ${tool.spec.name}`, JSON.stringify(input, null, 1).slice(0, 1200), signal, perm.label);
}
var import_node_fs12, obj, str, WRITE_WORDS, builtins, ONLY_IMPROVER, ONLY_MAUS_OR_IMPROVER, extraTools, allBuiltins, scheduleSchema, routinePermission, listBotsForTools, getBotName, COMPOSIO_READONLY;
var init_tools = __esm({
  "src/tools/index.ts"() {
    "use strict";
    init_bots();
    init_bridge();
    init_web();
    init_notify();
    init_approvals();
    init_memory();
    init_routines();
    init_scheduler();
    init_schedule();
    init_agent();
    init_routines();
    init_approvals();
    init_calendar();
    init_brief();
    init_audit();
    init_skills();
    init_location();
    init_calls();
    init_improve();
    init_share();
    init_phone_notifications();
    init_bot_admin();
    init_selfupdate();
    init_skills();
    init_skills();
    init_composio();
    import_node_fs12 = __toESM(require("node:fs"), 1);
    init_files();
    obj = (props, required = []) => ({ type: "object", properties: props, required });
    str = (description) => ({ type: "string", description });
    WRITE_WORDS = /(SEND|CREATE|DELETE|REMOVE|UPDATE|POST|REPLY|INSERT|ADD|MOVE|PATCH|PUT|UPLOAD|SHARE|INVITE|PAY|PURCHASE|BUY|ARCHIVE|TRASH|MODIFY|SET_|EXECUTE|RUN|SUBMIT|ACCEPT|DECLINE|CANCEL|TRANSFER|FORWARD)/i;
    builtins = [
      {
        group: "web",
        spec: { name: "web_search", description: "Search the web. Returns titles, links and snippets.", inputSchema: obj({ query: str("What to search for") }, ["query"]) },
        run: (_c, i) => webSearch(i.query)
      },
      {
        group: "web",
        spec: {
          name: "web_fetch",
          description: "Get a web page or API URL as readable text. Pages that build their content with JavaScript are opened in the phone's background browser automatically (render 'auto'); use render 'always' to force that, e.g. for lists that load after the page. For logins or clicking, use the browser tools.",
          inputSchema: obj({ url: str("http(s) URL"), render: { type: "string", enum: ["auto", "always", "never"], description: "JavaScript pages: auto (default), always, never" }, wait_ms: { type: "number", description: "With JavaScript: extra wait for content to load (default 2500, max 15000)" } }, ["url"])
        },
        run: (_c, i) => webFetch(i.url, i.render ?? "auto", Number(i.wait_ms ?? 2500))
      },
      {
        group: "browser",
        spec: {
          name: "browser_open",
          description: "Open a page in the phone's background browser (keeps your logins, runs JavaScript, works while the screen is off). Returns a tab id and the page text.",
          inputSchema: obj({ url: str("URL to open"), tab: str("Existing tab id to reuse (optional)") }, ["url"])
        },
        run: async (_c, i) => {
          browserNeeded();
          const r = await bridge("/browser/open", i, 9e4);
          return `tab=${r.tab}
title=${r.title}
url=${r.url}

${r.text ?? ""}`;
        }
      },
      {
        group: "browser",
        spec: { name: "browser_read", description: "Read the current page of a tab: mode 'text' (default), 'links', or 'forms' (inputs and buttons with selectors).", inputSchema: obj({ tab: str("Tab id"), mode: { type: "string", enum: ["text", "links", "forms"] } }, ["tab"]) },
        run: async (_c, i) => {
          browserNeeded();
          return (await bridge("/browser/read", i)).text;
        }
      },
      {
        group: "browser",
        spec: { name: "browser_click", description: "Click an element by CSS selector, or by its visible text.", inputSchema: obj({ tab: str("Tab id"), selector: str("CSS selector"), text: str("Visible text of the element") }, ["tab"]) },
        risk: (i) => `Click ${i.text ? `"${i.text}"` : i.selector} in the background browser`,
        run: async (_c, i) => {
          browserNeeded();
          const r = await bridge("/browser/click", i, 6e4);
          return `${r.result}
url=${r.url}

${r.text ?? ""}`;
        }
      },
      {
        group: "browser",
        spec: { name: "browser_type", description: "Type into an input (CSS selector). submit=true presses Enter / submits the form.", inputSchema: obj({ tab: str("Tab id"), selector: str("CSS selector of the input"), text: str("Text to type"), submit: { type: "boolean" } }, ["tab", "selector", "text"]) },
        risk: (i) => i.submit ? `Type and submit "${String(i.text).slice(0, 80)}"` : null,
        run: async (_c, i) => {
          browserNeeded();
          const r = await bridge("/browser/type", i, 6e4);
          return `${r.result}
url=${r.url}

${r.text ?? ""}`;
        }
      },
      {
        group: "browser",
        spec: { name: "browser_screenshot", description: "See what a tab looks like (image).", inputSchema: obj({ tab: str("Tab id") }, ["tab"]) },
        run: async (_c, i) => {
          browserNeeded();
          const r = await bridge("/browser/screenshot", i, 6e4);
          return { text: `Screenshot of ${r.url}`, images: [{ mediaType: "image/jpeg", data: r.jpeg }] };
        }
      },
      {
        group: "browser",
        spec: { name: "browser_scroll", description: "Scroll a tab down or up one screen, returns the newly visible text.", inputSchema: obj({ tab: str("Tab id"), direction: { type: "string", enum: ["down", "up"] } }, ["tab"]) },
        run: async (_c, i) => {
          browserNeeded();
          return (await bridge("/browser/scroll", i)).text;
        }
      },
      {
        group: "browser",
        spec: { name: "browser_tabs", description: "List open background browser tabs, or close one (close=tab id).", inputSchema: obj({ close: str("Tab id to close (optional)") }) },
        run: async (_c, i) => {
          browserNeeded();
          if (i.close) await bridge("/browser/close", { tab: i.close });
          return JSON.stringify((await bridge("/browser/tabs")).tabs, null, 1);
        }
      },
      {
        group: "browser",
        spec: { name: "browser_ask_login", description: "When a site needs you (the person) to sign in, show them the page so they can log in themselves. Their login is then remembered for the background browser.", inputSchema: obj({ url: str("Sign-in page"), reason: str("Why") }, ["url"]) },
        run: async (c, i) => {
          browserNeeded();
          await bridge("/login/show", { url: i.url, reason: i.reason, bot: c.bot.name });
          return "The sign-in page is now showing for the person. Ask them to tell you when they've finished, then continue.";
        }
      },
      {
        group: "core",
        spec: { name: "notify_user", description: "Send the person a phone notification (smart alert). Use for things that matter; be brief. priority: low (silent), normal, high (breaks quiet hours).", inputSchema: obj({ title: str("Short title"), body: str("One or two sentences"), priority: { type: "string", enum: ["low", "normal", "high"] } }, ["title", "body"]) },
        run: async (c, i) => {
          const runId = currentRunTags(c.bot.id).find((t) => t.startsWith("run_"));
          await notifyUser({ title: `${c.bot.emoji} ${i.title}`, body: i.body, botId: c.bot.id, priority: i.priority, source: c.bot.name, routineId: runId ? getRun(runId)?.routineId : void 0, link: i.link });
          return "Notification sent.";
        }
      },
      {
        group: "core",
        spec: { name: "ask_user", description: "Ask the person a question and wait for the answer. Give options when there are clear choices.", inputSchema: obj({ question: str("The question"), options: { type: "array", items: { type: "string" } } }, ["question"]) },
        run: async (c, i) => {
          const r = await askQuestion(c.bot.id, i.question, i.options, c.signal);
          return r.answer ? `The person answered: ${r.answer}` : "The person did not answer.";
        }
      },
      {
        group: "core",
        spec: { name: "memory_save", description: "Remember a lasting fact or preference. scope 'me' = about the person (shared by all bots), 'bot' = only you.", inputSchema: obj({ note: str("What to remember"), scope: { type: "string", enum: ["me", "bot"] } }, ["note"]) },
        run: async (c, i) => {
          appendMemory(i.scope === "bot" ? c.bot.id : "about-me", i.note);
          return "Saved.";
        }
      },
      {
        group: "core",
        spec: { name: "skill_read", description: "Open an installed skill's instructions (or one of its files) before doing a task it covers.", inputSchema: obj({ name: str("Skill name"), file: str("Optional file inside the skill") }, ["name"]) },
        run: async (_c, i) => i.file ? readSkillFile(i.name, i.file) : readSkill(i.name)
      },
      {
        group: "core",
        spec: {
          name: "file_read",
          description: "Look inside a file the person attached (by its file id). Text-like files (txt, md, json, html, csv, code\u2026) return their text, pictures are shown to you; other types return their details.",
          inputSchema: obj({ file_id: str("The file id, e.g. file_0123abcd\u2026"), offset: { type: "number", description: "Character to start from, for long files" } }, ["file_id"])
        },
        run: async (_c, i) => {
          const a = getFile(String(i.file_id));
          if (!a) return { text: "No such file.", isError: true };
          if (a.kind === "text") {
            const t = readText(a, 2e6);
            const off = Math.max(0, Number(i.offset ?? 0));
            return `${describe(a)}

${t.slice(off, off + 3e4)}${t.length > off + 3e4 ? `

[More: call again with offset ${off + 3e4}]` : ""}`;
          }
          if (a.kind === "image" && a.size < 5e6 && /png|jpe?g|gif|webp/.test(a.mime))
            return { text: describe(a), images: [{ mediaType: a.mime, data: import_node_fs12.default.readFileSync(filePath(a)).toString("base64") }] };
          return `${describe(a)}. This type can't be read as text here. Claude Code and ChatGPT (Codex) bots can open it directly; you can also upload it to a connected app (e.g. Google Drive) or describe what to do with it.`;
        }
      },
      {
        group: "web",
        spec: { name: "tailnet_fetch", description: "Call a service on the person's private Tailscale network (e.g. their PC at http://my-pc:11434). Works without opening the Tailscale app.", inputSchema: obj({ url: str("URL on the tailnet"), method: str("GET (default), POST\u2026"), body: str("Request body"), content_type: str("Body type") }, ["url"]) },
        risk: (i) => i.method && i.method.toUpperCase() !== "GET" ? `${i.method} ${i.url} on your tailnet` : null,
        run: async (_c, i) => tailnetFetch(i.url, (i.method ?? "GET").toUpperCase(), i.body, i.content_type ? { "content-type": i.content_type } : {})
      }
    ];
    ONLY_IMPROVER = /^(improve_|routine_admin_|skill_save$|tool_list$)/;
    ONLY_MAUS_OR_IMPROVER = /^bot_(list|edit)$/;
    extraTools = null;
    allBuiltins = () => [...builtins, ...extraTools ??= [...routineTools(), ...calendarTools(), ...briefTools(), ...auditTools(), ...locationTools(), ...callTools(), ...improveTools(), ...shareTools(), ...adminTools()]];
    scheduleSchema = {
      kind: { type: "string", enum: ["daily", "weekly", "alert", "custom", "once", "interval"], description: "daily = Once a Day; weekly = Once a Week; alert = Upon Alert; custom = intervals / specific dates / recurring" },
      time: str("daily/weekly: local time HH:MM"),
      days: { type: "array", items: { type: "number" }, description: "weekly (or custom recurring): weekdays 0=Sun..6=Sat" },
      time_zone: str(`IANA time zone, e.g. "Australia/Sydney" (default: the phone's)`),
      custom: {
        type: "object",
        description: "custom: {mode:'interval', minutes>=15} | {mode:'dates', dates:['YYYY-MM-DDTHH:MM']} | {mode:'recurring', everyDays, times:['HH:MM'], days?, startDate?}"
      },
      window: { type: "object", description: "Only run between {start:'HH:MM', end:'HH:MM', days?:[0-6]}" },
      conditions: str("Plain-language condition checked before acting"),
      alert: { type: "object", description: 'alert: {type? (e.g. "share" = something the person shares to MausDroid; source is then the kind, e.g. "YouTube video"), source?, minPriority?: low|normal|high, contains?, dedupeMinutes?}' },
      missed_policy: { type: "string", enum: ["run-once", "skip"], description: "If a run is missed: run once late (default) or skip" },
      at: str("once: ISO date-time"),
      minutes: { type: "number", description: "interval: minutes (15 or more)" }
    };
    routinePermission = { key: "routines:change", label: "changing or deleting your routines" };
    listBotsForTools = () => listBots().filter((b) => !b.hidden);
    getBotName = (id2) => getBot(id2)?.name ?? "(missing bot)";
    COMPOSIO_READONLY = /SEARCH_TOOLS|GET_TOOL_SCHEMAS|MANAGE_CONNECTIONS/;
  }
});

// src/mcp-server.ts
var mcp_server_exports = {};
__export(mcp_server_exports, {
  handleMcp: () => handleMcp,
  initMcpServer: () => initMcpServer,
  mcpTokenFor: () => mcpTokenFor
});
async function initMcpServer() {
  key = getSecret("mcp:key");
  if (!key) {
    key = (0, import_node_crypto5.randomBytes)(32).toString("hex");
    await setSecret("mcp:key", key);
  }
}
function mcpTokenFor(botId) {
  return (0, import_node_crypto5.createHmac)("sha256", key ?? "unset").update(`mcp:${botId}`).digest("hex");
}
function validToken(botId, header) {
  const got = Buffer.from((header ?? "").replace(/^Bearer /i, ""));
  const want = Buffer.from(mcpTokenFor(botId));
  return got.length === want.length && (0, import_node_crypto5.timingSafeEqual)(got, want);
}
async function handleMcp(botId, req, res, body) {
  const send = (status2, obj2) => {
    res.writeHead(status2, { "content-type": "application/json" });
    res.end(JSON.stringify(obj2));
  };
  if (!validToken(botId, req.headers.authorization)) return send(401, { error: "bad token" });
  const bot = getBot(botId);
  if (!bot) return send(404, { error: "no bot" });
  if (req.method !== "POST") return send(405, { error: "POST only" });
  const reply = (result) => send(200, { jsonrpc: "2.0", id: body.id, result });
  const fail = (message) => send(200, { jsonrpc: "2.0", id: body.id, error: { code: -32e3, message } });
  switch (body.method) {
    case "initialize":
      return reply({ protocolVersion: body.params?.protocolVersion ?? "2025-06-18", capabilities: { tools: {} }, serverInfo: { name: "mausdroid", version: "0.1" } });
    case "notifications/initialized":
    case "notifications/cancelled":
      res.writeHead(202).end();
      return;
    case "ping":
      return reply({});
    case "tools/list": {
      const tools2 = await toolsFor(bot);
      return reply({ tools: [approvalTool, ...tools2.map((t) => t.spec)].map((t) => ({ name: t.name, description: t.description, inputSchema: t.inputSchema })) });
    }
    case "tools/call": {
      const { name, arguments: args } = body.params ?? {};
      if (name === "approval_prompt") {
        const r = await requestApproval(bot.id, String(args?.tool_name), `Computer: ${args?.tool_name}`, clip(JSON.stringify(args?.input ?? {}, null, 1), 1200));
        const decision = r.allow ? { behavior: "allow", updatedInput: args?.input ?? {} } : { behavior: "deny", message: "The person declined." };
        return reply({ content: [{ type: "text", text: JSON.stringify(decision) }] });
      }
      const tool = (await toolsFor(bot)).find((t) => t.spec.name === name);
      if (!tool) return fail(`No tool ${name}`);
      {
        const r = await gate(bot, tool, args ?? {});
        if (!r.allow) return reply({ content: [{ type: "text", text: r.reason ?? "The person declined this action." }], isError: true });
      }
      try {
        const out = await tool.run({ bot, signal: AbortSignal.timeout(6e5) }, args ?? {});
        const r = typeof out === "string" ? { text: out } : out;
        return reply({
          content: [{ type: "text", text: clip(r.text) }, ...(r.images ?? []).map((i) => ({ type: "image", mimeType: i.mediaType, data: i.data }))],
          isError: Boolean(r.isError)
        });
      } catch (e) {
        const m = addMessage(bot.id, { role: "tool", text: "", tool: { name, input: args, result: errorText(e), isError: true, status: "done" } });
        emit("message", { botId: bot.id, message: m });
        return reply({ content: [{ type: "text", text: errorText(e) }], isError: true });
      }
    }
    default:
      return fail(`Unsupported method ${body.method}`);
  }
}
var import_node_crypto5, key, approvalTool;
var init_mcp_server = __esm({
  "src/mcp-server.ts"() {
    "use strict";
    import_node_crypto5 = require("node:crypto");
    init_bots();
    init_secrets();
    init_tools();
    init_approvals();
    init_bots();
    init_events();
    init_util();
    approvalTool = {
      name: "approval_prompt",
      description: "Asks the person on their phone to allow or deny a tool call.",
      inputSchema: { type: "object", properties: { tool_name: { type: "string" }, input: { type: "object" } }, required: ["tool_name"] }
    };
  }
});

// src/agent.ts
function announceEnd(botId, reply, info) {
  for (const l of turnEndListeners) {
    try {
      l(botId, reply, info);
    } catch {
    }
  }
}
function tellShellBusy() {
  if (bridgeAvailable()) void bridge("/busy", { busy: running.size > 0 }).catch(() => {
  });
}
function stopBot(botId) {
  running.get(botId)?.abort();
  const waiting2 = (queues.get(botId) ?? []).map((q) => q.tag).filter((t) => Boolean(t));
  queues.delete(botId);
  if (waiting2.length) announceEnd(botId, "", { tags: waiting2, failed: true, aborted: true });
}
function resolveProvider(bot) {
  const s = settings();
  const id2 = renamedProvider(bot.providerId) ?? s.defaultProvider ?? s.providers.find((p2) => p2.enabled)?.id;
  const p = id2 ? provider(id2) : void 0;
  if (!p || !p.enabled) throw new Error("No AI is set up for this bot yet. Open Settings \u2192 AI and sign in to Claude or ChatGPT.");
  return p;
}
function systemPrompt(bot, extra = "") {
  const s = settings();
  const when = fmtLong(/* @__PURE__ */ new Date());
  return [
    bot.persona || `You are ${bot.name}, a helpful assistant.`,
    `

You are ${bot.name}, one of the person's bots in MausDroid, an agent app running on their Android phone. It is ${when} (${s.timeZone}).`,
    "Work step by step with your tools. Prefer the quickest reliable tool (web_fetch before the browser; connected apps before the browser).",
    "Anything that sends, buys, posts, deletes or changes things for the person is paused for their approval automatically; just call the tool.",
    "Never type passwords, card numbers or one-time codes yourself: if a site needs a login use browser_ask_login.",
    "For Facebook, Messenger and WhatsApp never drive the person's account in the browser (it can get them banned); draft text for them to send instead.",
    "Reply in plain, friendly language. Keep answers short unless asked for detail.",
    describeSkills(bot.skills),
    memoryContext(bot.id),
    extra
  ].join(" ");
}
function trimHistory(h, maxChars = 4e5) {
  const size = (m) => JSON.stringify(m).length;
  let total = h.reduce((a, m) => a + size(m), 0);
  let start = 0;
  while (total > maxChars && start < h.length - 2) {
    total -= size(h[start]);
    start++;
    while (start < h.length && !(h[start].role === "user" && h[start].content.some((b) => b.type === "text"))) {
      total -= size(h[start]);
      start++;
    }
  }
  return h.slice(start);
}
async function modelTurn(p, model, system, msgs2, tools2, signal, onText) {
  const req = { model, system, messages: msgs2, tools: tools2.map((t) => t.spec), signal, onText };
  const key2 = getSecret(`provider:${p.id}`);
  if (p.needsKey && !key2) throw new Error(`${p.label} needs an API key (Settings \u2192 AI).`);
  if (p.kind === "anthropic") return anthropicTurn(req, key2);
  return openaiTurn(req, p.baseUrl, key2);
}
function sendToBot(botId, text, source = "you", attachments, tag) {
  const bot = getBot(botId);
  if (!bot) throw new Error("No such bot");
  const msg = addMessage(botId, { role: "user", text, source, status: "done", ...attachments?.length ? { attachments } : {} });
  updateBot(botId, { lastMessageAt: msg.at });
  emit("message", { botId, message: msg });
  const q = queues.get(botId) ?? [];
  q.push({ text: source === "you" ? text : `[${source}] ${text}`, source, attachments, tag });
  queues.set(botId, q);
  if (!running.has(botId)) void drain(botId);
  return msg;
}
async function drain(botId) {
  const ctl = new AbortController();
  running.set(botId, ctl);
  emit("bot.busy", { botId, busy: true });
  tellShellBusy();
  let tags = [];
  try {
    while ((queues.get(botId) ?? []).length && !ctl.signal.aborted) {
      const batch = queues.get(botId).splice(0);
      const bot = getBot(botId);
      if (!bot) break;
      lastReply.delete(botId);
      lastFailed.delete(botId);
      tags = batch.map((b) => b.tag).filter((t) => Boolean(t));
      currentTags.set(botId, tags);
      for (const l of turnStartListeners) {
        try {
          l(botId, tags);
        } catch {
        }
      }
      try {
        const p = resolveProvider(bot);
        if (p.kind === "subscription") await runCliTurn(bot, p, batch.map((b) => b.text).join("\n\n"), ctl.signal, batch.flatMap((b) => b.attachments ?? []));
        else await runApiTurn(bot, p, batch, ctl.signal);
      } catch (e) {
        if (ctl.signal.aborted) break;
        const m = addMessage(botId, { role: "assistant", text: `\u26A0\uFE0F ${errorText(e)}`, status: "error" });
        emit("message", { botId, message: m });
        lastReply.set(botId, errorText(e));
        lastFailed.add(botId);
      }
      if (ctl.signal.aborted) break;
      announceEnd(botId, lastReply.get(botId) ?? "", { tags, failed: lastFailed.has(botId), aborted: false });
      tags = [];
    }
  } finally {
    currentTags.delete(botId);
    if (ctl.signal.aborted && tags.length) announceEnd(botId, lastReply.get(botId) ?? "", { tags, failed: true, aborted: true });
    running.delete(botId);
    emit("bot.busy", { botId, busy: false });
    tellShellBusy();
    if (ctl.signal.aborted) {
      const m = addMessage(botId, { role: "note", text: "Stopped.", status: "stopped" });
      emit("message", { botId, message: m });
    }
  }
}
async function runApiTurn(bot, p, batch, signal) {
  const h = history(bot.id);
  const content = [];
  for (const b2 of batch) {
    content.push({ type: "text", text: b2.text || "(see attached)" });
    content.push(...toBlocks(b2.attachments ?? []));
  }
  h.push({ role: "user", content });
  const tools2 = await toolsFor(bot);
  const model = bot.model ?? p.defaultModel;
  for (let step2 = 0; step2 < MAX_STEPS; step2++) {
    if (signal.aborted) break;
    const reply = addMessage(bot.id, { role: "assistant", text: "", status: "streaming" });
    emit("message", { botId: bot.id, message: reply });
    let text = "";
    let turn;
    try {
      turn = await modelTurn(p, model, systemPrompt(bot), trimHistory(h), tools2, signal, (d) => {
        text += d;
        emit("message.delta", { botId: bot.id, messageId: reply.id, delta: d });
      });
    } catch (e) {
      patchMessage(bot.id, reply.id, { text: text || `\u26A0\uFE0F ${errorText(e)}`, status: signal.aborted ? "stopped" : "error" });
      emit("message.updated", { botId: bot.id, messageId: reply.id });
      setHistory(bot.id, h);
      if (signal.aborted) return;
      throw e;
    }
    const finalText = turn.blocks.filter((b2) => b2.type === "text").map((b2) => b2.text).join("");
    patchMessage(bot.id, reply.id, { text: finalText, status: "done" });
    if (finalText.trim()) lastReply.set(bot.id, finalText);
    emit("message.updated", { botId: bot.id, messageId: reply.id, text: finalText, status: finalText ? "done" : "empty" });
    h.push({ role: "assistant", content: turn.blocks });
    const calls = turn.blocks.filter((b2) => b2.type === "tool_use");
    if (!calls.length) break;
    const results = [];
    for (const call of calls) results.push(await runTool(bot, tools2, call, signal));
    h.push({ role: "user", content: results });
    setHistory(bot.id, h);
  }
  setHistory(bot.id, h);
  const b = getBot(bot.id);
  if (b) updateBot(bot.id, { unread: b.unread + 1, lastMessageAt: (/* @__PURE__ */ new Date()).toISOString() });
}
async function runTool(bot, tools2, call, signal) {
  const tool = tools2.find((t) => t.spec.name === call.name);
  const card = addMessage(bot.id, { role: "tool", text: "", tool: { name: call.name, input: call.input, status: "running" } });
  emit("message", { botId: bot.id, message: card });
  const finish3 = (result, isError, status2) => {
    patchMessage(bot.id, card.id, { tool: { name: call.name, input: call.input, result: clip(result, 4e3), isError, status: status2 } });
    emit("message.updated", { botId: bot.id, messageId: card.id });
  };
  if (!tool) {
    finish3("Unknown tool", true, "done");
    return { type: "tool_result", toolUseId: call.id, content: `There is no tool called ${call.name}.`, isError: true };
  }
  {
    const r = await gate(bot, tool, call.input, signal);
    if (!r.allow) {
      finish3(r.reason ?? "You said no.", true, "denied");
      return { type: "tool_result", toolUseId: call.id, content: r.reason ?? "The person declined this action. Do not retry it; ask what they would like instead.", isError: true };
    }
  }
  try {
    const out = await tool.run({ bot, signal }, call.input);
    const res = typeof out === "string" ? { text: out } : out;
    finish3(res.text, Boolean(res.isError), "done");
    return { type: "tool_result", toolUseId: call.id, content: clip(res.text), isError: res.isError, images: res.images };
  } catch (e) {
    finish3(errorText(e), true, "done");
    return { type: "tool_result", toolUseId: call.id, content: errorText(e), isError: true };
  }
}
async function runCliTurn(bot, p, text, signal, attachments = []) {
  const onPhone = p.runOn !== "computer" && isSignedIn(p.subId);
  const mcpBase = onPhone || !settings().tailscale.enabled ? `http://127.0.0.1:${config.port}` : `http://${settings().tailscale.hostname}`;
  const run = {
    attachments,
    prompt: text,
    model: bot.model ?? p.defaultModel,
    resume: bot.cliSession,
    mcpUrl: `${mcpBase}/mcp/${bot.id}`,
    mcpToken: mcpTokenFor(bot.id),
    systemPrompt: systemPrompt(bot, "\n\nMausDroid's tools (browser on the phone, connected apps, alerts, memory, routines, skills) are available through the mausdroid MCP server.")
  };
  let current = null;
  let streaming = null;
  let streamed = "";
  let produced = false;
  const pass = async () => {
    for await (const ev of runCli(p, run, signal)) {
      if (ev.kind !== "session") produced = true;
      if (ev.kind === "session" && ev.sessionId) updateBot(bot.id, { cliSession: ev.sessionId });
      else if (ev.kind === "delta" && ev.text) {
        if (!streaming) {
          streaming = addMessage(bot.id, { role: "assistant", text: "", status: "streaming" });
          emit("message", { botId: bot.id, message: streaming });
        }
        streamed += ev.text;
        emit("message.delta", { botId: bot.id, messageId: streaming.id, delta: ev.text });
      } else if (ev.kind === "text" && ev.text) {
        if (streaming) {
          patchMessage(bot.id, streaming.id, { text: ev.text, status: "done" });
          if (ev.text.startsWith(streamed) && ev.text.length > streamed.length) emit("message.delta", { botId: bot.id, messageId: streaming.id, delta: ev.text.slice(streamed.length) });
          emit("message.updated", { botId: bot.id, messageId: streaming.id, text: ev.text, status: "done" });
          current = streaming;
          streaming = null;
          streamed = "";
        } else {
          current = addMessage(bot.id, { role: "assistant", text: ev.text, status: "done" });
          emit("message", { botId: bot.id, message: current });
        }
        lastReply.set(bot.id, ev.text);
      } else if (ev.kind === "tool") {
        const m = addMessage(bot.id, { role: "tool", text: "", tool: { name: ev.name ?? "tool", input: ev.input, status: "done" } });
        emit("message", { botId: bot.id, message: m });
      } else if (ev.kind === "error") throw new Error(ev.text);
    }
  };
  try {
    try {
      await pass();
    } catch (e) {
      if (!run.resume || produced || signal.aborted || !STALE_SESSION.test(errorText(e))) throw e;
      updateBot(bot.id, { cliSession: void 0 });
      run.resume = void 0;
      const note = addMessage(bot.id, { role: "note", text: "Started a fresh conversation \u2014 the earlier one couldn't be continued.", status: "done" });
      emit("message", { botId: bot.id, message: note });
      await pass();
    }
  } finally {
    const half = streaming;
    if (half) {
      patchMessage(bot.id, half.id, { text: streamed, status: signal.aborted ? "stopped" : "done" });
      emit("message.updated", { botId: bot.id, messageId: half.id, text: streamed });
      if (streamed) lastReply.set(bot.id, streamed);
    }
  }
  const b = getBot(bot.id);
  if (b) updateBot(bot.id, { unread: b.unread + 1, lastMessageAt: (/* @__PURE__ */ new Date()).toISOString() });
}
var MAX_STEPS, running, queues, turnEndListeners, onTurnEnd, turnStartListeners, onTurnStart, lastReply, lastFailed, currentTags, currentRunTags, busyBots, STALE_SESSION;
var init_agent = __esm({
  "src/agent.ts"() {
    "use strict";
    init_bots();
    init_events();
    init_settings();
    init_secrets();
    init_anthropic();
    init_openai();
    init_cli();
    init_subscriptions();
    init_tools();
    init_util();
    init_config();
    init_time();
    init_mcp_server();
    init_bridge();
    init_files();
    MAX_STEPS = 40;
    running = /* @__PURE__ */ new Map();
    queues = /* @__PURE__ */ new Map();
    turnEndListeners = /* @__PURE__ */ new Set();
    onTurnEnd = (fn) => {
      turnEndListeners.add(fn);
      return () => turnEndListeners.delete(fn);
    };
    turnStartListeners = /* @__PURE__ */ new Set();
    onTurnStart = (fn) => {
      turnStartListeners.add(fn);
      return () => turnStartListeners.delete(fn);
    };
    lastReply = /* @__PURE__ */ new Map();
    lastFailed = /* @__PURE__ */ new Set();
    currentTags = /* @__PURE__ */ new Map();
    currentRunTags = (botId) => currentTags.get(botId) ?? [];
    busyBots = () => [...running.keys()];
    STALE_SESSION = /no rollout found|thread\/resume failed|no conversation found|conversation .{0,40}not found|session .{0,40}not found|could not find (the )?(session|conversation)/i;
  }
});

// src/voice.ts
function speakable(text) {
  return text.replace(/```[\s\S]*?```/g, " (code) ").replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/https?:\/\/\S+/g, "a link").replace(/[*_#>`|]/g, "").replace(/^\s*[-•]\s+/gm, "").replace(/\n{2,}/g, ". ").replace(/\s+/g, " ").trim().slice(0, 3e3);
}
function voiceParams() {
  const v = settings().voice;
  return { rate: v.rate, engine: v.ttsEngine ?? "", voice: v.voiceName ?? "", pitch: v.pitch ?? 1 };
}
async function speak(text, wait = false) {
  if (!bridgeAvailable() || !text.trim()) return;
  await bridge("/voice/speak", { text: speakable(text), ...voiceParams(), wait }, wait ? 18e4 : 6e4).catch(() => {
  });
}
async function say(text, flush = false) {
  const t = speakable(text);
  if (!bridgeAvailable() || !t) return;
  await bridge("/voice/say", { text: t, ...voiceParams(), flush }, 15e3).catch(() => {
  });
}
function sendByVoice(botId, text) {
  spokenTo.add(botId);
  return sendToBot(botId, text, "voice");
}
function assistantBot() {
  const id2 = settings().assistant.botId;
  const bots = listBots().filter((b) => !b.hidden);
  return id2 && getBot(id2) || bots.find((b) => b.pinned) || bots[0];
}
function askAssistant(text, attachments = [], screen, waitMs = 75e3) {
  const bot = assistantBot();
  if (!bot) throw new Error("Create a bot first.");
  return new Promise((resolve) => {
    let done = false;
    const off = onTurnEnd((botId, reply) => {
      if (botId !== bot.id || done) return;
      done = true;
      off();
      clearTimeout(t);
      resolve({ botId: bot.id, botName: bot.name, reply });
    });
    const t = setTimeout(() => {
      if (done) return;
      done = true;
      off();
      resolve({ botId: bot.id, botName: bot.name, reply: null });
      const later = onTurnEnd((botId, reply) => {
        if (botId !== bot.id) return;
        later();
        void notifyUser({ title: `${bot.emoji} ${bot.name}`, body: reply.slice(0, 400) || "Finished.", botId: bot.id, priority: "high" });
      });
    }, waitMs);
    const parts = [text];
    if (screen && (screen.text || screen.url || screen.app)) {
      parts.push(
        `
[Screen context \u2014 what the person was looking at when they asked${screen.app ? `, in ${screen.app}` : ""}${screen.url ? `, page ${screen.url}` : ""}. Use it only if relevant; it may include private info.]${screen.text ? `
${screen.text.slice(0, 6e3)}` : ""}`
      );
    }
    sendToBot(bot.id, parts.join("\n"), "assistant", attachments);
  });
}
var spokenTo;
var init_voice = __esm({
  "src/voice.ts"() {
    "use strict";
    init_bridge();
    init_agent();
    init_bots();
    init_settings();
    init_notify();
    spokenTo = /* @__PURE__ */ new Set();
    onTurnEnd((botId, reply) => {
      const mode = settings().voice.readReplies;
      const asked = spokenTo.delete(botId);
      if (mode === "always" || mode === "voice" && asked) void speak(reply);
    });
  }
});

// src/call-session.ts
function partOfDay(at) {
  const h = at.getHours();
  if (h < 5) return "late";
  if (h < 12) return "morning";
  if (h < 17) return "afternoon";
  if (h < 22) return "evening";
  return "late";
}
function greeting(name, at = /* @__PURE__ */ new Date(), pick = Math.random) {
  const list = TEMPLATES[partOfDay(at)];
  let t = list[Math.floor(pick() * list.length) % list.length];
  if (t === lastGreeting && list.length > 1) t = list[(list.indexOf(t) + 1) % list.length];
  lastGreeting = t;
  const n = name.trim();
  return t.replace("{, n}", n ? `, ${n}` : "").replace("{ n}", n ? ` ${n}` : "");
}
function shortGreeting(name, at = /* @__PURE__ */ new Date(), pick = Math.random) {
  const part = { late: "Hi", morning: "Morning", afternoon: "Afternoon", evening: "Evening" }[partOfDay(at)];
  const list = [`${part}{, n}`, "Hey{ n}", "G'day{ n}"];
  const n = name.trim();
  return list[Math.floor(pick() * list.length) % list.length].replace("{, n}", n ? `, ${n}` : "").replace("{ n}", n ? ` ${n}` : "");
}
function userName() {
  const set3 = callSettings().userName?.trim();
  if (set3) return set3;
  const about = readMemory("about-me");
  const m = about.match(/\b(?:my name is|i am|i'm|call me|name:)\s+([A-Z][a-z]+)/);
  return m?.[1] ?? "";
}
function runCall(callId) {
  const existing = liveCall(callId);
  if (existing?.active) return existing;
  const c = getCall(callId);
  if (!c || c.state !== "active") throw new Error("This call isn't active.");
  const l = { callId, phase: "connecting", lines: [], note: "", active: true, interruptions: 0, turn: null };
  live.set(callId, l);
  void conversation(l, c.botId, c.direction === "incoming" ? c.openingLine || c.reason : "").catch((e) => l.note = e.message).finally(() => finish2(l));
  return liveCall(callId);
}
async function hangUp(callId) {
  const l = live.get(callId);
  if (l) {
    l.active = false;
    cancelTurn(l);
  }
  await bridge("/voice/stop", {}).catch(() => {
  });
  if (!l) endCall(callId);
  return liveCall(callId);
}
async function finish2(l) {
  l.active = false;
  cancelTurn(l);
  setPhase(l, "ended");
  await bridge("/voice/call-mode", { on: false }).catch(() => {
  });
  endCall(l.callId);
  setTimeout(() => live.delete(l.callId), 10 * 6e4);
}
function cancelTurn(l) {
  const t = l.turn;
  if (!t || t.done) return;
  t.cancelled = true;
  t.done = true;
  t.off();
  if (currentRunTags(t.botId).includes(t.id)) stopBot(t.botId);
  if (l.lines[t.line]) l.lines[t.line].interrupted = true;
  l.turn = null;
}
async function speakLine(l, text, flush = false) {
  l.lines.push({ who: "maus", text });
  setPhase(l, "speaking");
  await say(text, flush);
}
async function waitWhileBusy(l) {
  let errors = 0;
  while (l.active) {
    const busy = Boolean(l.turn && !l.turn.done);
    const st = await bridge("/voice/await-speech", { maxMs: 250, bargeIn: true }, 5e3).catch((e) => ({ error: e.message, speech: false, speaking: false }));
    if (st.speech) return "speech";
    if (st.error) {
      if (errors++ === 0) l.note = st.error;
      const s = await bridge("/voice/state", {}).catch(() => ({ speaking: false }));
      if (!busy && !s.speaking) return "idle";
      await sleep(200);
      continue;
    }
    if (!busy && !st.speaking) return "idle";
  }
  return "idle";
}
function startTurn(l, botId, text, name) {
  const id2 = id("callturn");
  const chunker = new SpeechChunker();
  const turn = { id: id2, botId, done: false, cancelled: false, spoke: false, line: -1, off: () => {
  } };
  l.turn = turn;
  setPhase(l, "thinking");
  const speakPiece = (piece) => {
    if (turn.cancelled) return;
    if (turn.line < 0) {
      l.lines.push({ who: "maus", text: piece });
      turn.line = l.lines.length - 1;
    } else l.lines[turn.line].text += ` ${piece}`;
    turn.spoke = true;
    setPhase(l, "speaking");
    void say(piece);
  };
  const unsub = subscribe((e) => {
    if (turn.cancelled || e.type !== "message.delta" || e.botId !== botId) return;
    if (!currentRunTags(botId).includes(id2)) return;
    for (const piece of chunker.push(String(e.delta ?? ""))) speakPiece(piece);
  });
  const offEnd = onTurnEnd((b, reply, info) => {
    if (b !== botId || !(info?.tags ?? []).includes(id2) || turn.done) return;
    turn.done = true;
    turn.off();
    if (turn.cancelled) return;
    const rest = chunker.flush();
    if (rest) speakPiece(rest);
    if (!turn.spoke) speakPiece(reply?.trim() || (info?.failed ? "Sorry, something went wrong there." : "Done."));
  });
  const timer = setTimeout(() => {
    if (turn.done) return;
    turn.done = true;
    turn.off();
    speakPiece("Sorry, that's taking me a while. I'll message you when it's done.");
  }, 12e4);
  turn.off = () => {
    unsub();
    offEnd();
    clearTimeout(timer);
  };
  sendToBot(
    botId,
    `${text}

(Said aloud during a phone call with ${name || "you"}. Reply like natural spoken conversation: start with the answer in a short first sentence, one to three short sentences in all, no lists, links or formatting.)`,
    "call",
    [],
    id2
  );
}
async function conversation(l, botId, reason) {
  const bot = getBot(botId);
  const name = userName();
  await bridge("/voice/call-mode", { on: true }).catch(() => {
  });
  await speakLine(l, reason ? `${shortGreeting(name)}, it's ${bot?.name ?? "Maus"}. ${reason}` : greeting(name), true);
  let silences = 0;
  let failures = 0;
  while (l.active) {
    const w = await waitWhileBusy(l);
    if (!l.active) break;
    if (w === "speech") {
      if (l.turn && !l.turn.done) cancelTurn(l);
      else if (l.lines.at(-1)?.who === "maus") l.lines[l.lines.length - 1].interrupted = true;
      l.interruptions++;
    }
    setPhase(l, "listening");
    const r = await bridge("/voice/listen", { soft: true, silenceMs: 700, timeoutSec: 30 }, 4e4).catch((e) => ({ text: "", missed: false, error: e.message }));
    if (!l.active) break;
    if (r.error && !r.missed) {
      l.note = r.error;
      changed(l);
      failures++;
      if (/permission/i.test(r.error) || failures >= 2) {
        await speakLine(l, `Sorry${name ? ` ${name}` : ""}, I can't hear you. ${r.error}`);
        await waitWhileBusy(l);
        break;
      }
      continue;
    }
    failures = 0;
    const text = (r.text ?? "").trim();
    if (!text) {
      if (++silences >= 3) {
        await speakLine(l, `I'll let you go${name ? `, ${name}` : ""}. Talk soon!`);
        await waitWhileBusy(l);
        break;
      }
      if (silences === 2) await speakLine(l, "Are you still there?");
      continue;
    }
    silences = 0;
    l.note = "";
    l.lines.push({ who: "you", text });
    changed(l);
    if (isGoodbye(text)) {
      await speakLine(l, `Bye${name ? ` ${name}` : ""}! Talk soon.`);
      await waitWhileBusy(l);
      break;
    }
    startTurn(l, botId, text, name);
  }
}
var TEMPLATES, lastGreeting, SPEAKABLE, SpeechChunker, live, liveCall, changed, setPhase, BYE_START, isGoodbye;
var init_call_session = __esm({
  "src/call-session.ts"() {
    "use strict";
    init_bridge();
    init_events();
    init_agent();
    init_bots();
    init_memory();
    init_voice();
    init_calls();
    init_util();
    TEMPLATES = {
      late: ["Hey{ n}, you're up late. What's up?", "Hi{ n}, burning the midnight oil? What can I do?", "Hey{ n}. Late one tonight \u2014 what do you need?"],
      morning: ["Morning{, n}!", "Good morning{, n}. What can I do for you?", "Hey{ n}, how you going this morning?", "Morning{, n} \u2014 what's up?", "G'day{ n}! What's on this morning?"],
      afternoon: ["Afternoon{, n}!", "Good afternoon{, n}. What do you need?", "Hey{ n}, how's the day going?", "G'day{ n}, what's up?", "Hey{ n}, how you going?"],
      evening: ["Evening{, n}!", "Good evening{, n}. What can I do for you?", "Hey{ n}, how you going?", "Evening{, n} \u2014 how was the day?", "Hey{ n}, what's up tonight?"]
    };
    lastGreeting = "";
    SPEAKABLE = /[^\s!-/:-@[-`{-~\u2013\u2014\u2018\u2019\u201c\u201d\u2026]/;
    SpeechChunker = class {
      buf = "";
      first = true;
      push(delta) {
        this.buf += delta;
        const out = [];
        for (; ; ) {
          let cut = -1;
          const end = this.buf.search(/[.!?…](?=[\s"')\]]|$)|\n/);
          if (end >= 0 && (end + 1 < this.buf.length || /\n$/.test(this.buf))) cut = end + 1;
          if (cut < 0 && this.first) {
            const m = this.buf.slice(18).search(/[,;:—–](?=\s)/);
            if (m >= 0) cut = 18 + m + 1;
          }
          if (cut < 0 && this.buf.length > 160) {
            const sp = this.buf.lastIndexOf(" ", 160);
            cut = sp > 40 ? sp : 160;
          }
          if (cut < 0) break;
          const piece = this.buf.slice(0, cut).trim();
          this.buf = this.buf.slice(cut);
          if (SPEAKABLE.test(piece)) {
            out.push(piece);
            this.first = false;
          }
        }
        return out;
      }
      flush() {
        const rest = this.buf.trim();
        this.buf = "";
        return SPEAKABLE.test(rest) ? rest : "";
      }
    };
    live = /* @__PURE__ */ new Map();
    liveCall = (callId) => {
      const l = live.get(callId);
      return l ? { callId, phase: l.phase, lines: l.lines.slice(-12), note: l.note, active: l.active, interruptions: l.interruptions } : null;
    };
    changed = (l) => emit("call.live", { callId: l.callId, phase: l.phase });
    setPhase = (l, p) => {
      if (l.phase !== p) l.phase = p, changed(l);
    };
    BYE_START = /^(ok(ay)?[, ]+)?(bye|goodbye|good bye|see ya|see you|hang up|that's all|that is all|end (the )?call)\b/i;
    isGoodbye = (t) => BYE_START.test(t.trim()) || t.trim().split(/\s+/).length <= 5 && /\b(bye|goodbye|see ya|talk (to you )?later|cheers)\W*$/i.test(t.trim());
  }
});

// src/pairing.ts
function createPairingCode() {
  const code = (0, import_node_crypto6.randomBytes)(16).toString("base64url");
  const exp = Date.now() + 10 * 6e4;
  codes.set(code, exp);
  return { code, expiresAt: new Date(exp).toISOString() };
}
function pairingLink(code, base) {
  return `${base.replace(/\/$/, "")}/#pair=${code}`;
}
function redeemPairingCode(code, name) {
  const exp = codes.get(code);
  if (!exp || exp < Date.now()) throw new Error("This QR code has expired. Show a new one on the phone.");
  codes.delete(code);
  const token = (0, import_node_crypto6.randomBytes)(32).toString("base64url");
  devices.update((d) => void d.push({ id: hash(token).slice(0, 12), name: name.slice(0, 60) || "Device", tokenHash: hash(token), createdAt: (/* @__PURE__ */ new Date()).toISOString() }));
  return token;
}
function deviceForToken(token) {
  if (!token) return void 0;
  const h = hash(token);
  const d = devices.get().find((x) => x.tokenHash === h);
  if (d) d.lastSeenAt = (/* @__PURE__ */ new Date()).toISOString();
  return d;
}
function revokeDevice(id2) {
  devices.update((l) => {
    const i = l.findIndex((x) => x.id === id2);
    if (i >= 0) l.splice(i, 1);
  });
}
async function setWebsitePassword(pw) {
  if (pw.length < 8) throw new Error("Use at least 8 characters.");
  const salt = (0, import_node_crypto6.randomBytes)(16).toString("hex");
  await setSecret("website:password", `${salt}:${(0, import_node_crypto6.scryptSync)(pw, salt, 32).toString("hex")}`);
}
function checkWebsitePassword(pw) {
  const stored = getSecret("website:password");
  if (!stored) return false;
  const [salt, want] = stored.split(":");
  const got = (0, import_node_crypto6.scryptSync)(pw, salt, 32);
  return (0, import_node_crypto6.timingSafeEqual)(got, Buffer.from(want, "hex"));
}
function websiteBase() {
  const w = settings().website;
  if (w.enabled && w.relayUrl && w.deviceId) return `${w.relayUrl.replace(/\/$/, "")}/d/${w.deviceId}`;
  if (settings().tailscale.enabled) return `http://${settings().tailscale.hostname}`;
  return null;
}
function configureWebsite(relayUrl, enabled) {
  updateSettings((s) => {
    s.website.relayUrl = relayUrl.trim().replace(/\/$/, "");
    s.website.enabled = enabled;
    s.website.deviceId ??= (0, import_node_crypto6.randomBytes)(9).toString("base64url");
  });
}
function linkCodeFrom(text, relayUrl) {
  const t = text.trim();
  const url = t.match(/^https?:\/\/[^\s]+$/)?.[0];
  if (url) {
    let u;
    try {
      u = new URL(url);
    } catch {
      throw new Error("That QR code isn't a MausDroid one.");
    }
    if (u.origin !== new URL(relayUrl).origin) throw new Error(`That QR code is for a different website (${u.host}). Open ${new URL(relayUrl).host} on your PC.`);
    const m = u.pathname.match(/^\/p\/([A-Za-z0-9]{8})$/);
    if (!m) throw new Error("That QR code isn't a MausDroid linking code.");
    return m[1].toUpperCase();
  }
  const code = t.toUpperCase().replace(/[\s-]/g, "");
  if (!/^[A-Z0-9]{8}$/.test(code)) throw new Error("The code has 8 letters and numbers, like ABCD-2345.");
  return code;
}
async function linkDevice(text) {
  const w = settings().website;
  if (!w.enabled || !w.relayUrl || !w.deviceId) throw new Error("Turn on the website first (address and password above).");
  if (!getSecret("website:password")) throw new Error("Set a website password first.");
  const code = linkCodeFrom(text, w.relayUrl);
  const pair = createPairingCode();
  const link = pairingLink(pair.code, websiteBase());
  const r = await fetch(`${w.relayUrl.replace(/\/$/, "")}/p/${code}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ link }), signal: AbortSignal.timeout(2e4) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error ?? `The website said HTTP ${r.status}. Refresh the page on your PC for a new code.`);
  return { ok: true };
}
var import_node_crypto6, devices, codes, hash, listDevices;
var init_pairing = __esm({
  "src/pairing.ts"() {
    "use strict";
    import_node_crypto6 = require("node:crypto");
    init_store();
    init_secrets();
    init_settings();
    devices = collection("devices", []);
    codes = /* @__PURE__ */ new Map();
    hash = (t) => (0, import_node_crypto6.createHash)("sha256").update(t).digest("hex");
    listDevices = () => devices.get().map(({ tokenHash, ...d }) => d);
  }
});

// src/models.ts
function modelGroups(p) {
  const yours = (p.customModels ?? []).map((id2) => ({ id: id2, label: id2 }));
  const groups = [];
  if (p.subId === "claude") groups.push(...CLAUDE_MODELS);
  else if (p.subId === "chatgpt") groups.push({ label: "ChatGPT", models: [{ id: "default", label: "Codex default (best for your plan)" }] });
  else if (p.models.length) groups.push({ label: p.kind === "openai" ? "Offered by this service" : "Models", models: p.models.map((id2) => ({ id: id2, label: id2 })) });
  if (yours.length) groups.push({ label: "Your models", models: yours });
  return groups;
}
function rememberModel(providerId, model) {
  const m = model.trim();
  if (!m || m === "default") return;
  updateSettings((s) => {
    const p = s.providers.find((x) => x.id === providerId);
    if (!p) return;
    const known = modelGroups(p).some((g) => g.models.some((x) => x.id === m));
    if (!known) p.customModels = [...p.customModels ?? [], m].slice(-20);
  });
}
async function checkModel(providerId, model) {
  const p = provider(providerId);
  if (!p) return { ok: false, detail: "Unknown AI.", ms: 0 };
  const start = Date.now();
  const signal = AbortSignal.timeout(9e4);
  try {
    let text = "";
    if (p.kind === "subscription") {
      for await (const ev of runCli(p, { prompt: "Reply with just the word OK.", model, mcpUrl: "http://127.0.0.1:1/none", mcpToken: "-", systemPrompt: "This is a connection check." }, signal)) {
        if (ev.kind === "text") text += ev.text;
        if (ev.kind === "error") throw new Error(ev.text);
      }
    } else {
      const key2 = getSecret(`provider:${p.id}`);
      if (p.needsKey && !key2) throw new Error("Add the API key first.");
      const req = { model, system: "This is a connection check.", messages: [{ role: "user", content: [{ type: "text", text: "Reply with just the word OK." }] }], tools: [], signal, onText: () => {
      } };
      const turn = p.kind === "anthropic" ? await anthropicTurn(req, key2) : await openaiTurn(req, p.baseUrl, key2);
      text = turn.blocks.filter((b) => b.type === "text").map((b) => b.text).join("");
    }
    rememberModel(providerId, model);
    return { ok: true, detail: `Answered: \u201C${text.trim().slice(0, 60) || "(empty)"}\u201D`, ms: Date.now() - start };
  } catch (e) {
    const msg = errorText(e);
    const hint = /not.?found|404|unknown model|invalid model|does not exist|not available|model_not_found/i.test(msg) ? " This model isn't available for your plan/server." : "";
    return { ok: false, detail: `${msg.slice(0, 300)}${hint}`, ms: Date.now() - start };
  }
}
function addEndpoint(label, baseUrl, needsKey) {
  const clean = label.trim() || "My endpoint";
  let base = baseUrl.trim().replace(/\/+$/, "");
  if (!/^https?:\/\//.test(base)) throw new Error("The address must start with http:// or https://");
  if (!/\/v\d+$/.test(base)) base += "/v1";
  const id2 = `custom-${clean.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 24) || "endpoint"}-${Date.now().toString(36).slice(-4)}`;
  updateSettings((s) => void s.providers.push({ id: id2, label: clean, kind: "openai", baseUrl: base, defaultModel: "", models: [], enabled: false, needsKey, custom: true, free: !needsKey }));
  return id2;
}
function removeEndpoint(id2) {
  const p = provider(id2);
  if (!p?.custom) throw new Error("Only endpoints you added can be removed.");
  updateSettings((s) => {
    s.providers = s.providers.filter((x) => x.id !== id2);
    if (s.defaultProvider === id2) s.defaultProvider = null;
  });
}
var CLAUDE_MODELS;
var init_models = __esm({
  "src/models.ts"() {
    "use strict";
    init_settings();
    init_secrets();
    init_anthropic();
    init_openai();
    init_cli();
    init_util();
    CLAUDE_MODELS = [
      {
        label: "Newest of each (short names)",
        models: [
          { id: "opus", label: "Opus \u2014 most capable" },
          { id: "sonnet", label: "Sonnet \u2014 balanced" },
          { id: "haiku", label: "Haiku \u2014 fastest" },
          { id: "fable", label: "Fable" }
        ]
      },
      {
        label: "Claude 5 (numbered)",
        models: [
          { id: "claude-fable-5-2", label: "Fable 5.2" },
          { id: "claude-opus-5-5", label: "Opus 5.5" },
          { id: "claude-sonnet-5-5", label: "Sonnet 5.5" },
          { id: "claude-haiku-5-5", label: "Haiku 5.5" }
        ]
      },
      {
        label: "Earlier (numbered)",
        models: [
          { id: "claude-opus-4-1-20250805", label: "Opus 4.1" },
          { id: "claude-opus-4-20250514", label: "Opus 4" },
          { id: "claude-sonnet-4-5-20250929", label: "Sonnet 4.5" },
          { id: "claude-sonnet-4-20250514", label: "Sonnet 4" },
          { id: "claude-haiku-4-5-20251001", label: "Haiku 4.5" },
          { id: "claude-3-7-sonnet-20250219", label: "Sonnet 3.7" },
          { id: "claude-3-5-haiku-20241022", label: "Haiku 3.5" }
        ]
      }
    ];
  }
});

// src/server.ts
var server_exports = {};
__export(server_exports, {
  handle: () => handle,
  startServer: () => startServer
});
function cookies(h) {
  const out = {};
  for (const part of (h.cookie ?? "").split(";")) {
    const i = part.indexOf("=");
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function cookie(name, value, req, maxAge) {
  const secure = req.via === "relay" ? "; Secure" : "";
  return `${name}=${encodeURIComponent(value)}; Path=${req.prefix || "/"}; Max-Age=${maxAge}; HttpOnly; SameSite=Strict${secure}`;
}
function auth(req) {
  const c = cookies(req.headers);
  const bearer = (req.headers.authorization ?? "").replace(/^Bearer /i, "");
  if (req.via === "local" && (bearer === config.localToken || c.md_t === config.localToken)) return "owner";
  const dev = deviceForToken(c.md_dev);
  if (!dev) return null;
  const s = sessions2.get()[c.md_sess ?? ""];
  if (s && s.device === dev.id && s.expires > Date.now()) return "owner";
  return "paired";
}
function serveStatic(p, ifNoneMatch) {
  const rel = p === "/" ? "index.html" : p.replace(/^\/+/, "");
  const file4 = import_node_path11.default.resolve(config.uiDir, rel);
  if (!file4.startsWith(import_node_path11.default.resolve(config.uiDir)) || !import_node_fs13.default.existsSync(file4) || import_node_fs13.default.statSync(file4).isDirectory()) {
    return rel === "index.html" ? { status: 404, body: "UI missing" } : serveStatic("/");
  }
  const st = import_node_fs13.default.statSync(file4);
  const etag = `"${config.version}-${st.size}-${Math.floor(st.mtimeMs)}"`;
  const common = {
    "content-type": TYPES[import_node_path11.default.extname(file4)] ?? "application/octet-stream",
    "content-security-policy": "default-src 'self'; img-src 'self' data: https: blob:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'",
    "x-content-type-options": "nosniff"
  };
  if (rel === "index.html") {
    const v = encodeURIComponent(config.version);
    const html = import_node_fs13.default.readFileSync(file4, "utf8").replace('href="app.css"', `href="app.css?v=${v}"`).replace('src="app.js"', `src="app.js?v=${v}"`).replace("<head>", `<head>
<meta name="md-version" content="${v}" />`);
    return { status: 200, headers: { ...common, "cache-control": "no-store" }, body: html };
  }
  if (ifNoneMatch === etag) return { status: 304, headers: { etag, "cache-control": "no-cache" } };
  return { status: 200, headers: { ...common, etag, "cache-control": "no-cache" }, body: import_node_fs13.default.readFileSync(file4) };
}
function state2() {
  return {
    version: { engine: config.version, apk: config.apkVersion, platform: config.platform },
    bots: listBots().map((b) => ({ ...b, last: lastMessage(b.id) ?? null, busy: busyBots().includes(b.id) })),
    cards: pendingCards(),
    seq: currentSeq(),
    unreadAlerts: listAlerts().filter((a) => !a.read).length,
    onboardingDone: settings().onboardingDone,
    nativeBridge: bridgeAvailable()
  };
}
function morningBriefRoutine(create) {
  const existing = listRoutines().find((r) => r.system === "morning-brief");
  if (existing || !create) return existing;
  const bots = listBotsForBrief();
  const owner = bots.find((b) => b.pinned) ?? bots[0];
  if (!owner) throw new HttpError(400, "Create a bot first.");
  return createRoutine({ botId: owner.id, title: "Morning Brief", prompt: MORNING_BRIEF_PROMPT, schedule: { kind: "weekly", days: [1, 2, 3, 4, 5], time: "06:30", timeZone: settings().timeZone?.includes("/") ? settings().timeZone : void 0 }, system: "morning-brief", timeoutMinutes: 20 });
}
function reviewMuse() {
  const items = recent({ app: "muse", limit: 150 });
  if (!items.length) throw new HttpError(400, "No Muse notifications have been read yet. Allow notification access, then tap Read pending notifications.");
  const bot = improverBot();
  if (!bot) throw new HttpError(400, "No Improver bot.");
  markFirstReview();
  sendToBot(bot.id, REVIEW_PROMPT(items), "notifications");
  return { botId: bot.id, reviewed: items.length };
}
async function handle(req) {
  try {
    if (!req.path.startsWith("/api/")) return serveStatic(req.path, req.headers["if-none-match"]);
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = req.path.match(r.re);
      if (!m) continue;
      if (!r.open) {
        const who = auth(req);
        if (who !== "owner") throw new HttpError(401, who === "paired" ? "Enter your password." : "Not signed in.");
      }
      return await r.h(req, m.slice(1));
    }
    return json({ error: "Not found" }, 404);
  } catch (e) {
    const status2 = e instanceof HttpError ? e.status : 500;
    return json({ error: errorText(e) }, status2);
  }
}
function startServer() {
  const server = import_node_http3.default.createServer(async (inc, out) => {
    const url = new URL(inc.url ?? "/", "http://x");
    const via = inc.headers["x-mausdroid-via"] === "tailnet" ? "tailnet" : "local";
    if (via === "local" && url.searchParams.get("t") === config.localToken) {
      out.writeHead(302, { location: "/", "set-cookie": `md_t=${config.localToken}; Path=/; HttpOnly; SameSite=Strict` });
      return out.end();
    }
    if (url.pathname === "/api/files" && inc.method === "POST") {
      const headers0 = Object.fromEntries(Object.entries(inc.headers).map(([k, v]) => [k, Array.isArray(v) ? v.join(", ") : v]));
      if (auth({ method: "POST", path: url.pathname, query: url.searchParams, headers: headers0, body: void 0, via, prefix: "/" }) !== "owner") return out.writeHead(401).end();
      const name = decodeURIComponent(String(inc.headers["x-file-name"] ?? "file"));
      const up = startUpload(name, String(inc.headers["content-type"] ?? ""));
      let size2 = 0;
      inc.on("data", (c) => {
        size2 += c.length;
        if (size2 > 500 * 1024 * 1024) inc.destroy();
      });
      inc.pipe(up.stream);
      up.stream.on("finish", () => {
        up.finish(size2);
        out.writeHead(200, { "content-type": "application/json" });
        out.end(JSON.stringify({ ...up.attachment, size: size2 }));
      });
      up.stream.on("error", () => out.writeHead(500).end());
      return;
    }
    const chunks = [];
    let size = 0;
    for await (const c of inc) {
      size += c.length;
      if (size > 25 * 1024 * 1024) return out.writeHead(413).end();
      chunks.push(c);
    }
    const raw = Buffer.concat(chunks).toString("utf8");
    let body = void 0;
    try {
      body = raw ? JSON.parse(raw) : void 0;
    } catch {
      body = raw;
    }
    const headers2 = Object.fromEntries(Object.entries(inc.headers).map(([k, v]) => [k, Array.isArray(v) ? v.join(", ") : v]));
    const req = { method: inc.method ?? "GET", path: url.pathname, query: url.searchParams, headers: headers2, body, via, prefix: "/" };
    const mcp2 = url.pathname.match(/^\/mcp\/([^/]+)$/);
    if (mcp2) return void handleMcp(mcp2[1], inc, out, body).catch((e) => out.writeHead(500).end(errorText(e)));
    if (req.path === "/api/events" && req.method === "GET") {
      if (auth(req) !== "owner") return out.writeHead(401).end();
      out.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-store", connection: "keep-alive" });
      out.write(`event: hello
data: ${JSON.stringify({ seq: currentSeq() })}

`);
      const off = subscribe((e) => out.write(`data: ${JSON.stringify(e)}

`));
      const ping = setInterval(() => out.write(": ping\n\n"), 2e4);
      inc.on("close", () => {
        off();
        clearInterval(ping);
      });
      return;
    }
    const res = await handle(req);
    out.writeHead(res.status, res.headers ?? {});
    out.end(res.body);
  });
  server.listen(config.port, "127.0.0.1");
  return server;
}
var import_node_fs13, import_node_path11, import_node_http3, import_node_crypto7, HttpError, json, sessions2, attempts, TYPES, routes, route, attachmentsFrom, subId, listBotsForBrief, badRequest, firstReviewTimer;
var init_server = __esm({
  "src/server.ts"() {
    "use strict";
    import_node_fs13 = __toESM(require("node:fs"), 1);
    import_node_path11 = __toESM(require("node:path"), 1);
    import_node_http3 = __toESM(require("node:http"), 1);
    import_node_crypto7 = require("node:crypto");
    init_config();
    init_bots();
    init_agent();
    init_events();
    init_approvals();
    init_notify();
    init_settings();
    init_secrets();
    init_anthropic();
    init_openai();
    init_secrets();
    init_composio();
    init_skills();
    init_routines();
    init_improve();
    init_call_session();
    init_share();
    init_bot_admin();
    init_selfupdate();
    init_cloud_keys();
    init_phone_notifications();
    init_pairing();
    init_memory();
    init_bridge();
    init_mcp_server();
    init_tools();
    init_store();
    init_util();
    init_scheduler();
    init_schedule();
    init_subscriptions();
    init_voice();
    init_files();
    init_calendar();
    init_brief();
    init_audit();
    init_location();
    init_models();
    init_calls();
    HttpError = class extends Error {
      constructor(status2, msg) {
        super(msg);
        this.status = status2;
      }
    };
    json = (data, status2 = 200, headers2 = {}) => ({
      status: status2,
      headers: { "content-type": "application/json", "cache-control": "no-store", ...headers2 },
      body: JSON.stringify(data)
    });
    sessions2 = collection("web-sessions", {});
    attempts = [];
    TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".png": "image/png", ".json": "application/json", ".webmanifest": "application/manifest+json", ".ico": "image/x-icon" };
    routes = [];
    route = (method, pattern, h, open2 = false) => routes.push({ method, re: new RegExp(`^${pattern.replace(/:([a-zA-Z]+)/g, "([^/]+)")}$`), h, open: open2 });
    route("POST", "/api/pair/redeem", (req) => {
      const token = redeemPairingCode(String(req.body?.code ?? ""), String(req.body?.name ?? "Device"));
      return json({ ok: true, needsPassword: true }, 200, { "set-cookie": cookie("md_dev", token, req, 400 * 86400) });
    }, true);
    route("POST", "/api/login", (req) => {
      const c = cookies(req.headers);
      const dev = deviceForToken(c.md_dev);
      if (!dev) throw new HttpError(401, "This device isn't paired. Scan the QR code on the phone first.");
      const recent2 = attempts.filter((t) => t > Date.now() - 15 * 6e4);
      attempts.splice(0, attempts.length, ...recent2);
      if (recent2.length >= 8) throw new HttpError(429, "Too many tries. Wait 15 minutes.");
      attempts.push(Date.now());
      if (!checkWebsitePassword(String(req.body?.password ?? ""))) throw new HttpError(401, "Wrong password.");
      const sid = (0, import_node_crypto7.randomBytes)(24).toString("base64url");
      sessions2.update((s) => {
        for (const [k, v] of Object.entries(s)) if (v.expires < Date.now()) delete s[k];
        s[sid] = { device: dev.id, expires: Date.now() + 30 * 864e5 };
      });
      return json({ ok: true }, 200, { "set-cookie": cookie("md_sess", sid, req, 30 * 86400) });
    }, true);
    route("GET", "/api/whoami", (req) => json({ auth: auth(req), via: req.via, passwordSet: publicSettings().website.passwordSet }), true);
    route("POST", "/api/logout", (req) => {
      const c = cookies(req.headers);
      sessions2.update((s) => void delete s[c.md_sess ?? ""]);
      return json({ ok: true }, 200, { "set-cookie": cookie("md_sess", "", req, 0) });
    });
    route("GET", "/api/state", () => json(state2()));
    route("POST", "/api/bots", (req) => json(createBot(req.body ?? {})));
    route("PATCH", "/api/bots/:id", (req, [id2]) => {
      const { id: _i, createdAt: _c, ...patch3 } = req.body ?? {};
      const b = updateBot(id2, patch3);
      if (b.providerId && b.model) rememberModel(b.providerId, b.model);
      return json(b);
    });
    route("DELETE", "/api/bots/:id", (_r, [id2]) => {
      stopBot(id2);
      deleteBot(id2);
      return json({ ok: true });
    });
    route("GET", "/api/bots/:id/messages", (req, [id2]) => json(messages(id2, req.query.get("before") ?? void 0)));
    attachmentsFrom = (ids) => Array.isArray(ids) ? ids.map((x) => getFile(String(x && typeof x === "object" ? x.id : x))).filter((x) => Boolean(x)) : [];
    route("POST", "/api/bots/:id/messages", (req, [id2]) => json(sendToBot(id2, String(req.body?.text ?? ""), "you", attachmentsFrom(req.body?.attachments))));
    route("POST", "/api/files/json", (req) => {
      const b = req.body ?? {};
      const data = Buffer.from(String(b.b64 ?? ""), "base64");
      if (!data.length) throw new HttpError(400, "Empty file");
      return json(saveFile(String(b.name ?? "file"), b.mime, data, b.note));
    });
    route("GET", "/api/files/:id/info", (_r, [id2]) => {
      const a = getFile(id2);
      if (!a) throw new HttpError(404, "No such file");
      return json(a);
    });
    route("GET", "/api/files/:id", (_r, [id2]) => {
      const a = getFile(id2);
      if (!a) throw new HttpError(404, "No such file");
      return {
        status: 200,
        headers: { "content-type": a.mime, "content-disposition": `inline; filename="${a.name.replace(/"/g, "")}"`, "cache-control": "private, max-age=86400", "x-content-type-options": "nosniff", "content-security-policy": "sandbox" },
        body: import_node_fs13.default.readFileSync(filePath(a))
      };
    });
    route("POST", "/api/bots/:id/stop", (_r, [id2]) => (stopBot(id2), json({ ok: true })));
    route("POST", "/api/bots/:id/clear", (_r, [id2]) => (clearChat(id2), json({ ok: true })));
    route("POST", "/api/bots/:id/read", (_r, [id2]) => json(updateBot(id2, { unread: 0 })));
    route("GET", "/api/events/poll", async (req) => json({ events: await waitForEvents(Number(req.query.get("since") ?? 0), 25e3), seq: currentSeq() }));
    route("GET", "/api/cards", () => json(pendingCards()));
    route("POST", "/api/cards/:id", (req, [id2]) => json({ ok: settle(id2, { allow: Boolean(req.body?.allow), answer: req.body?.answer, always: Boolean(req.body?.always) }) }));
    route("GET", "/api/alerts", () => json(listAlerts()));
    route("POST", "/api/alerts/read", () => (markAlertsRead(), json({ ok: true })));
    route("GET", "/api/settings", () => json(publicSettings()));
    route("PUT", "/api/settings/general", (req) => {
      const b = req.body ?? {};
      updateSettings((s) => {
        if ("defaultProvider" in b) s.defaultProvider = b.defaultProvider;
        if (b.timeZone) s.timeZone = b.timeZone;
        if ("quietHours" in b) s.quietHours = b.quietHours;
        if ("onboardingDone" in b) s.onboardingDone = Boolean(b.onboardingDone);
      });
      emit("settings.changed");
      return json(publicSettings());
    });
    route("PUT", "/api/settings/providers/:id", async (req, [id2]) => {
      const b = req.body ?? {};
      if (!provider(id2) && b.kind) {
        updateSettings((s) => void s.providers.push({ id: id2, label: b.label ?? id2, kind: b.kind, baseUrl: b.baseUrl, defaultModel: b.defaultModel ?? "", models: [], enabled: false, needsKey: Boolean(b.needsKey) }));
      }
      if (!provider(id2)) throw new HttpError(404, "No such AI provider");
      if (typeof b.key === "string") await setSecret(`provider:${id2}`, b.key.trim() || null);
      if (typeof b.computerToken === "string") await setSecret(`computer:${id2}`, b.computerToken.trim() || null);
      updateSettings((s) => {
        const p = s.providers.find((x) => x.id === id2);
        for (const k of ["enabled", "baseUrl", "defaultModel", "models", "runOn", "computerUrl", "label", "needsKey"]) if (k in b) p[k] = b[k];
        if (p.enabled && !s.defaultProvider) s.defaultProvider = p.id;
      });
      emit("settings.changed");
      return json(publicSettings());
    });
    route("POST", "/api/settings/providers/:id/models", async (_r, [id2]) => {
      const p = provider(id2);
      if (!p) throw new HttpError(404, "No such AI provider");
      const key2 = getSecret(`provider:${id2}`);
      const models = p.kind === "anthropic" ? await anthropicModels(key2 ?? "") : p.kind === "openai" ? await openaiModels(p.baseUrl, key2) : p.models;
      updateSettings((s) => void (s.providers.find((x) => x.id === id2).models = models));
      return json({ models });
    });
    route("GET", "/api/models/:provider", (_r, [pid]) => {
      const p = provider(pid);
      if (!p) throw new HttpError(404, "No such AI");
      return json({ provider: p.id, defaultModel: p.defaultModel, groups: modelGroups(p) });
    });
    route("POST", "/api/models/check", async (req) => json(await checkModel(String(req.body?.provider ?? ""), String(req.body?.model ?? "").trim() || provider(String(req.body?.provider ?? ""))?.defaultModel || "default")));
    route("POST", "/api/endpoints", (req) => {
      const b = req.body ?? {};
      try {
        return json({ id: addEndpoint(String(b.label ?? ""), String(b.baseUrl ?? ""), Boolean(b.needsKey)) });
      } catch (e) {
        throw new HttpError(400, errorText(e));
      }
    });
    route("DELETE", "/api/endpoints/:id", (_r, [id2]) => {
      try {
        removeEndpoint(id2);
      } catch (e) {
        throw new HttpError(400, errorText(e));
      }
      return json(publicSettings());
    });
    route("PUT", "/api/settings/github", async (req) => {
      await setSecret("github", String(req.body?.token ?? "").trim() || null);
      return json(publicSettings());
    });
    subId = (id2) => {
      if (!(id2 in SUBS)) throw new HttpError(404, "Unknown subscription");
      return id2;
    };
    route("GET", "/api/subs", () => json(allSubs()));
    onSignedIn((sid) => {
      updateSettings((st) => {
        const p = st.providers.find((x) => x.id === sid);
        if (p) p.enabled = true;
        st.defaultProvider ??= sid;
      });
      emit("settings.changed");
    });
    route("POST", "/api/subs/:id/signin", (req, [id2]) => {
      const sid = subId(id2);
      const opener = async (url) => {
        if (req.via === "local" && bridgeAvailable()) await bridge("/open-url", { url });
      };
      void signIn(sid, opener);
      return json(subStatus(sid));
    });
    route("POST", "/api/subs/:id/code", (req, [id2]) => (sendCode(subId(id2), String(req.body?.code ?? "")), json(subStatus(subId(id2)))));
    route("POST", "/api/subs/:id/cancel", (_r, [id2]) => (cancelSignIn(subId(id2)), json(subStatus(subId(id2)))));
    route("POST", "/api/subs/:id/signout", async (_r, [id2]) => {
      await signOut(subId(id2));
      return json(subStatus(subId(id2)));
    });
    route("POST", "/api/subs/:id/uninstall", async (_r, [id2]) => {
      await uninstall(subId(id2));
      return json(subStatus(subId(id2)));
    });
    route("PUT", "/api/settings/voice", (req) => {
      const b = req.body ?? {};
      updateSettings((st) => {
        if (b.readReplies) st.voice.readReplies = b.readReplies;
        if (typeof b.rate === "number") st.voice.rate = Math.min(2, Math.max(0.5, b.rate));
        if (typeof b.pitch === "number") st.voice.pitch = Math.min(2, Math.max(0.5, b.pitch));
        if (typeof b.ttsEngine === "string") st.voice.ttsEngine = b.ttsEngine;
        if (typeof b.voiceName === "string") st.voice.voiceName = b.voiceName;
        if ("assistantBotId" in b) st.assistant.botId = b.assistantBotId || null;
        if ("assistantSpeak" in b) st.assistant.speak = Boolean(b.assistantSpeak);
      });
      emit("settings.changed");
      return json(publicSettings());
    });
    route("POST", "/api/voice/listen", async (req) => json(await bridge("/voice/listen", { soft: Boolean(req.body?.soft) }, 6e4)));
    route("GET", "/api/voice/engines", async () => json(await bridge("/voice/engines", {})));
    route("POST", "/api/voice/voices", async (req) => json(await bridge("/voice/voices", { engine: String(req.body?.engine ?? "") }, 2e4)));
    route("POST", "/api/voice/speak", async (req) => (await speak(String(req.body?.text ?? ""), Boolean(req.body?.wait)), json({ ok: true })));
    route("POST", "/api/voice/stop", async () => json(await bridge("/voice/stop", {}).catch(() => ({}))));
    route("POST", "/api/bots/:id/voice", (req, [id2]) => json(sendByVoice(id2, String(req.body?.text ?? ""))));
    route("GET", "/api/assistant", () => {
      const b = assistantBot();
      return json({ botId: b?.id ?? null, botName: b?.name ?? null, emoji: b?.emoji ?? null, color: b?.color ?? null, speak: settings().assistant.speak });
    });
    route("POST", "/api/assistant/ask", async (req) => json(await askAssistant(String(req.body?.text ?? ""), attachmentsFrom(req.body?.attachments), req.body?.screen)));
    route("GET", "/api/calendars", async (req) => json({ destination: getDestination(), ...req.query.get("refresh") === "0" && lastDiscovery() ? lastDiscovery() : await discoverCalendars() }));
    route("PUT", "/api/calendars/destination", (req) => {
      const b = req.body ?? {};
      if (!b.accountId || !b.calendarId) {
        setDestination(null);
        return json({ destination: null });
      }
      const c = lastDiscovery()?.calendars.find((x) => x.accountId === b.accountId && x.calendarId === b.calendarId);
      if (!c) throw new HttpError(400, "Refresh the calendar list first.");
      if (!c.writable) throw new HttpError(400, `"${c.name}" is read-only for ${c.accountAlias}.`);
      setDestination({ accountId: c.accountId, calendarId: c.calendarId, name: c.name, accountAlias: c.accountAlias });
      return json({ destination: getDestination() });
    });
    route("POST", "/api/calendars/test-write", async (req) => json(await testWrite(req.body?.accountId ? req.body : void 0)));
    route("POST", "/api/calendars/events", async (req) => {
      const b = req.body ?? {};
      return json(await createEvent({ summary: b.summary, start: b.start, durationMinutes: b.durationMinutes, description: b.description, location: b.location, timeZone: b.timeZone }, b.calendar ? { name: b.calendar } : void 0));
    });
    route(
      "GET",
      "/api/location",
      async () => json({
        permission: bridgeAvailable() ? (await bridge("/location/permission").catch(() => ({ permission: "unavailable" }))).permission : "unavailable",
        active: activeLocationRequests(),
        recent: recentLocationUses()
      })
    );
    route("GET", "/api/calls", () => {
      const b = callBot();
      return json({ settings: callSettings(), knownName: userName(), bot: b ? { id: b.id, name: b.name, emoji: b.emoji } : null, log: callLog() });
    });
    route("PUT", "/api/calls/settings", (req) => json(saveCallSettings(req.body ?? {})));
    route("GET", "/api/calls/may", async () => json(await mayCall()));
    route("POST", "/api/calls/start", () => json(startOutgoing()));
    route("GET", "/api/calls/:id", (_r, [id2]) => {
      const c = getCall(id2);
      if (!c) throw new HttpError(404, "No such call");
      return json(c);
    });
    route("POST", "/api/calls/:id/answer", (req, [id2]) => json(answerCall(id2, req.body?.answer !== false)));
    route("POST", "/api/calls/:id/turn", async (req, [id2]) => {
      try {
        return json(await callTurn(id2, String(req.body?.text ?? "")));
      } catch (e) {
        throw new HttpError(400, errorText(e));
      }
    });
    route("POST", "/api/calls/:id/end", async (_r, [id2]) => (await hangUp(id2), json(getCall(id2) ?? {})));
    route("POST", "/api/calls/:id/run", (_r, [id2]) => json(badRequest(() => runCall(id2))));
    route("GET", "/api/calls/:id/live", (_r, [id2]) => json(liveCall(id2) ?? { callId: id2, phase: "ended", lines: [], note: "", active: false }));
    route("POST", "/api/calls/test", async (req) => json(await ringUser(String(req.body?.reason ?? "Test call"), "Hi, this is a test call from MausDroid.")));
    route("GET", "/api/audits", () => json(listAudits().map(({ scored, ...a }) => ({ ...a, candidates: scored.length }))));
    route("GET", "/api/audits/wiki", async () => json(await checkWiki()));
    route("GET", "/api/brief/settings", () => json(briefSettings()));
    route("PUT", "/api/brief/settings", (req) => json(saveBriefSettings(req.body ?? {})));
    route("GET", "/api/briefings", () => json(listBriefings()));
    route("GET", "/api/briefings/:id", (_r, [id2]) => {
      const b = getBriefing(id2);
      if (!b) throw new HttpError(404, "No such briefing");
      return json(b);
    });
    route("POST", "/api/briefings/:id/events/:eid", async (req, [id2, eid]) => json(await decideEvent(id2, eid, Boolean(req.body?.approve))));
    route("POST", "/api/brief/prepare", async (req) => json(await prepareBrief(req.body?.date)));
    listBotsForBrief = () => listBots().filter((b) => !b.hidden);
    route("GET", "/api/brief/routine", () => json(morningBriefRoutine(false) ? routineDetails(morningBriefRoutine(false)) : null));
    route("POST", "/api/brief/routine", () => json(routineDetails(morningBriefRoutine(true))));
    route("POST", "/api/brief/refresh", () => json(runRoutineNow(morningBriefRoutine(true).id)));
    route("POST", "/api/composio/key", async (req) => (await connectComposio(String(req.body?.key ?? "")), json(publicSettings())));
    route("DELETE", "/api/composio/key", async () => (await disconnectComposio(), json(publicSettings())));
    route("GET", "/api/composio/toolkits", async (req) => json(await listToolkits(req.query.get("search") ?? "", req.query.get("cursor") ?? void 0)));
    route("GET", "/api/composio/connections", async () => json(await listConnections()));
    route("POST", "/api/composio/link", async (req) => {
      const { url } = await linkToolkit(String(req.body?.toolkit), req.body?.alias);
      if (req.via === "local" && bridgeAvailable()) await bridge("/open-url", { url }).catch(() => {
      });
      return json({ url });
    });
    route("GET", "/api/composio/toolkits/:slug/auth", async (_r, [slug]) => json(await toolkitAuth(decodeURIComponent(slug))));
    route("POST", "/api/composio/toolkits/:slug/auth", async (req, [slug]) => {
      try {
        return json(await setupCustomAuth(decodeURIComponent(slug), String(req.body?.mode ?? "OAUTH2"), req.body?.credentials ?? {}));
      } catch (e) {
        throw new HttpError(400, e.message);
      }
    });
    route("DELETE", "/api/composio/toolkits/:slug/auth", async (_r, [slug]) => (await removeCustomAuth(decodeURIComponent(slug)), json({ ok: true })));
    route("DELETE", "/api/composio/connections/:id", async (_r, [id2]) => (await removeConnection(id2), json({ ok: true })));
    route("GET", "/api/skills", () => json(listSkills().map(({ dir, ...s }) => s)));
    route("POST", "/api/skills", (req) => json({ name: saveSkill(String(req.body?.name), String(req.body?.md)) }));
    route("DELETE", "/api/skills/:name", (_r, [name]) => (removeSkill(decodeURIComponent(name)), json({ ok: true })));
    route("GET", "/api/skills/market", async (req) => json(await searchMarketplace(req.query.get("q") ?? "")));
    route("GET", "/api/skills/repo", async (req) => {
      const r = await listRepoSkills(req.query.get("ref") ?? "");
      return json({ repo: `${r.owner}/${r.repo}`, branch: r.branch, skills: r.dirs });
    });
    route("POST", "/api/skills/install", async (req) => json({ installed: await installFromGitHub(String(req.body?.ref), req.body?.only) }));
    badRequest = (fn) => {
      try {
        return fn();
      } catch (e) {
        throw new HttpError(400, errorText(e));
      }
    };
    route(
      "GET",
      "/api/tools",
      () => json({
        tools: toolCatalog(),
        bots: listBots().filter((b) => !b.hidden).map((b) => ({ id: b.id, name: b.name, emoji: b.emoji, tools: b.tools, disabledTools: b.disabledTools ?? [] }))
      })
    );
    route("POST", "/api/tools/:name/bots", (req, [name]) => {
      setToolForBots(decodeURIComponent(name), (req.body?.botIds ?? []).map(String), req.body?.enabled !== false);
      return json({ ok: true });
    });
    route("GET", "/api/bot-changes", () => json(listBotChanges()));
    route("POST", "/api/bot-changes/:id/undo", (_r, [id2]) => json(badRequest(() => undoBotChange(id2))));
    firstReviewTimer = null;
    route("POST", "/api/notifications/incoming", (req) => {
      const r = addIncoming(req.body?.items ?? []);
      if (r.added && !firstReviewDone() && !firstReviewTimer && recent({ app: "muse", limit: 1 }).length)
        firstReviewTimer = setTimeout(() => {
          firstReviewTimer = null;
          if (!firstReviewDone()) {
            try {
              reviewMuse();
            } catch {
            }
          }
        }, Number(process.env.MAUSDROID_FIRST_REVIEW_MS ?? 6e4));
      return json(r);
    });
    route("GET", "/api/notifications/phone", async (req) => {
      const native = bridgeAvailable() ? await bridge("/notifications/status", {}).catch(() => null) : null;
      return json({ native, counts: counts(), recent: recent({ app: req.query.get("app") ?? void 0, limit: 50 }) });
    });
    route("POST", "/api/notifications/allow", async () => json(await bridge("/notifications/open-settings", {})));
    route("PUT", "/api/notifications/watch", async (req) => json(await bridge("/notifications/watch", { packages: (req.body?.packages ?? []).map(String) })));
    route("POST", "/api/notifications/rescan", async () => json(await bridge("/notifications/rescan", {})));
    route("POST", "/api/notifications/review", () => json(reviewMuse()));
    route("POST", "/api/share", (req) => {
      const rec = badRequest(() => receiveShare({ text: req.body?.text, attachments: attachmentsFrom(req.body?.attachments) }));
      const bot = getBot(rec.botId);
      return json({ ...rec, botName: bot?.name ?? "Maus" });
    });
    route("GET", "/api/shares", () => json(listShares()));
    route("GET", "/api/improve", () => json(overview()));
    route("PUT", "/api/improve/settings", (req) => json(badRequest(() => saveImproveSettings(req.body ?? {}))));
    route("POST", "/api/improve/run", () => {
      const r = improveRoutine();
      if (!r) throw new Error("The nightly check routine is missing.");
      return json(runRoutineNow(r.id));
    });
    route("POST", "/api/improve/reveal", async () => json(await revealDue(/* @__PURE__ */ new Date(), true)));
    route("GET", "/api/improve/cloud", async () => json({ checklist: await checklist(), connect: connectState(), codex: codexConnectState() }));
    route("POST", "/api/improve/cloud/codex/connect", async (req) => {
      const opener = async (url) => {
        if (req.via === "local" && bridgeAvailable()) await bridge("/open-url", { url });
      };
      if (!getSecret("github")) throw new HttpError(400, "Save a GitHub token first (Settings \u2192 Memory \u2192 GitHub token).");
      void startCodexConnect(opener).catch(() => {
      });
      return json(codexConnectState());
    });
    route("POST", "/api/improve/cloud/codex/cancel", () => (cancelCodexConnect(), json(codexConnectState())));
    route("POST", "/api/improve/cloud/connect", async (req) => {
      const opener = async (url) => {
        if (req.via === "local" && bridgeAvailable()) await bridge("/open-url", { url });
      };
      if (!getSecret("github")) throw new HttpError(400, "Save a GitHub token first (Settings \u2192 Memory \u2192 GitHub token).");
      void startConnect(opener).catch(() => {
      });
      return json(connectState());
    });
    route("POST", "/api/improve/cloud/code", (req) => {
      try {
        connectCode(String(req.body?.code ?? ""));
      } catch (e) {
        throw new HttpError(400, e.message);
      }
      return json(connectState());
    });
    route("POST", "/api/improve/cloud/secret", async (req) => {
      try {
        await addSecret(String(req.body?.name ?? ""), String(req.body?.value ?? ""));
      } catch (e) {
        throw new HttpError(400, e.message);
      }
      return json({ checklist: await checklist() });
    });
    route("POST", "/api/improve/cloud/cancel", () => (cancelConnect(), json(connectState())));
    route("POST", "/api/improve/rollback", (req) => json(badRequest(() => {
      const r = rollBack(req.body?.version ? String(req.body.version) : void 0);
      recordApplied(`Rolled back ${r.from} \u2192 ${r.to}`, `Went back from ${r.from} to ${r.to}.`, "code");
      return r;
    })));
    route("POST", "/api/improve/build", async (req) => json(await requestBuild(String(req.body?.title ?? "Change"), String(req.body?.spec ?? ""))));
    route("POST", "/api/improve/check-builds", async () => (await checkBuilds(), json(overview())));
    route("POST", "/api/improve/:id/answer", async (req, [id2]) => {
      try {
        return json(await answerBuild(id2, String(req.body?.answers ?? "")));
      } catch (e) {
        throw new HttpError(400, e.message);
      }
    });
    route("POST", "/api/improve/:id/approve", async (_r, [id2]) => json(await approve(id2)));
    route("POST", "/api/improve/:id/snooze", (_r, [id2]) => json(badRequest(() => snooze(id2))));
    route("POST", "/api/improve/:id/dismiss", (_r, [id2]) => json(badRequest(() => dismiss(id2))));
    route("GET", "/api/routines", (req) => json(listRoutines(req.query.get("bot") ?? void 0).map(routineDetails)));
    route("POST", "/api/routines", (req) => json(routineDetails(badRequest(() => createRoutine(req.body)))));
    route("PATCH", "/api/routines/:id", (req, [id2]) => json(routineDetails(badRequest(() => updateRoutine(id2, req.body ?? {})))));
    route("DELETE", "/api/routines/:id", (_r, [id2]) => (deleteRoutine(id2), json({ ok: true })));
    route("POST", "/api/routines/:id/run", (_r, [id2]) => json(runRoutineNow(id2)));
    route("POST", "/api/routines/:id/pause", (_r, [id2]) => json(routineDetails(pauseRoutine(id2))));
    route("POST", "/api/routines/:id/resume", (_r, [id2]) => json(routineDetails(resumeRoutine(id2))));
    route("GET", "/api/routines/:id/runs", (req, [id2]) => json(listRuns(id2, Number(req.query.get("limit") ?? 30))));
    route("POST", "/api/routines/preview", (req) => {
      const sc = req.body?.schedule ?? {};
      const problems = validateSchedule(sc);
      const upcoming = [];
      if (!problems.length) {
        let from = /* @__PURE__ */ new Date();
        for (let i = 0; i < 3; i++) {
          const o = nextOccurrence(sc, from);
          if (!o) break;
          upcoming.push(o.at.toISOString());
          from = o.at;
        }
      }
      return json({ text: problems.length ? null : describeSchedule(sc), problems, upcoming });
    });
    route("POST", "/api/alerts/incoming", async (req) => {
      const b = req.body ?? {};
      if (!b.title && !b.body) throw new HttpError(400, "Send at least a title or body.");
      const a = await notifyUser({ title: String(b.title ?? ""), body: String(b.body ?? ""), type: String(b.type ?? "external"), source: b.source ? String(b.source) : void 0, priority: ["low", "normal", "high"].includes(b.priority) ? b.priority : "normal", eventId: b.id ? String(b.id) : void 0, silentRecord: b.notify === false });
      return json(a);
    });
    route("GET", "/api/memory/:scope", (_r, [scope]) => json({ text: readMemory(scope) }));
    route("PUT", "/api/memory/:scope", (req, [scope]) => (writeMemory(scope, String(req.body?.text ?? "")), json({ ok: true })));
    route("GET", "/api/devices", () => json(listDevices()));
    route("DELETE", "/api/devices/:id", (_r, [id2]) => (revokeDevice(id2), json({ ok: true })));
    route("POST", "/api/pair/link", async (req) => {
      try {
        return json(await linkDevice(String(req.body?.text ?? "")));
      } catch (e) {
        throw new HttpError(400, e.message);
      }
    });
    route("POST", "/api/pair/create", () => {
      const base = websiteBase();
      if (!base) throw new HttpError(400, "Turn on the website (or Tailscale) first so other devices have an address to open.");
      const c = createPairingCode();
      return json({ ...c, link: pairingLink(c.code, base) });
    });
    route("PUT", "/api/website", async (req) => {
      const b = req.body ?? {};
      if (b.password) await setWebsitePassword(String(b.password));
      if ("relayUrl" in b || "enabled" in b) configureWebsite(String(b.relayUrl ?? settings().website.relayUrl ?? ""), Boolean(b.enabled));
      emit("settings.changed");
      return json(publicSettings());
    });
    route("GET", "/api/tailscale", async () => json(bridgeAvailable() ? await bridge("/tailscale/status") : { state: "Unavailable" }));
    route("PUT", "/api/tailscale", async (req) => {
      const b = req.body ?? {};
      if (typeof b.authKey === "string") await setSecret("tailscale:authkey", b.authKey.trim() || null);
      updateSettings((s2) => {
        if ("enabled" in b) s2.tailscale.enabled = Boolean(b.enabled);
        if (b.hostname) s2.tailscale.hostname = String(b.hostname).toLowerCase().replace(/[^a-z0-9-]/g, "-");
      });
      const s = settings().tailscale;
      if (bridgeAvailable()) await bridge(s.enabled ? "/tailscale/start" : "/tailscale/stop", { hostname: s.hostname, authKey: getSecret("tailscale:authkey") ?? "" });
      return json(publicSettings());
    });
    route("GET", "/api/update", async () => json(bridgeAvailable() ? await bridge("/update/status") : { state: "dev" }));
    route("POST", "/api/update/check", async () => json(await bridge("/update/check", {}, 3e5)));
    route("POST", "/api/update/apply", async () => json(await bridge("/update/apply", {}, 3e5)));
    route("GET", "/api/system", async () => json({ ...bridgeAvailable() ? await bridge("/device/info").catch(() => ({})) : {}, engine: config.version }));
    route("POST", "/api/system/:action", async (req, [action]) => json(await bridge(`/device/${action}`, req.body ?? {})));
    route("POST", "/api/browser/login", async (req) => json(await bridge("/login/show", { url: req.body?.url })));
  }
});

// src/relay-client.ts
var relay_client_exports = {};
__export(relay_client_exports, {
  relayStatus: () => relayStatus,
  startRelayClient: () => startRelayClient
});
async function relaySecret() {
  let s = getSecret("website:relay");
  if (!s) {
    s = (0, import_node_crypto9.randomBytes)(32).toString("base64url");
    await setSecret("website:relay", s);
  }
  return s;
}
function startRelayClient() {
  if (running2) return;
  running2 = true;
  void loop();
}
async function loop() {
  let backoff = 1e3;
  while (true) {
    const w = settings().website;
    if (!w.enabled || !w.relayUrl || !w.deviceId) {
      relayStatus.connected = false;
      await sleep(5e3);
      continue;
    }
    const base = `${w.relayUrl.replace(/\/$/, "")}/d/${w.deviceId}`;
    try {
      const secret = await relaySecret();
      const ts = String(Date.now());
      const sig = (0, import_node_crypto8.createHmac)("sha256", secret).update(`${w.deviceId}:${ts}`).digest("hex");
      phoneKey = (0, import_node_crypto8.createHmac)("sha256", secret).update("register").digest("hex");
      const res = await fetch(`${base}/_phone/poll`, {
        headers: { "x-phone-ts": ts, "x-phone-sig": sig, "x-phone-key": phoneKey },
        signal: AbortSignal.timeout(4e4)
      });
      if (!res.ok) throw new Error(`website relay: HTTP ${res.status} ${await res.text()}`);
      relayStatus.connected = true;
      relayStatus.lastSeen = (/* @__PURE__ */ new Date()).toISOString();
      relayStatus.lastError = "";
      backoff = 1e3;
      const jobs = await res.json();
      for (const job of jobs) void answer(base, sig, ts, job);
    } catch (e) {
      relayStatus.connected = false;
      relayStatus.lastError = e instanceof Error ? e.message : String(e);
      await sleep(backoff);
      backoff = Math.min(backoff * 2, 6e4);
    }
  }
}
async function answer(base, sig, ts, job) {
  let body;
  try {
    body = job.body ? JSON.parse(job.body) : void 0;
  } catch {
    body = job.body;
  }
  const prefix = new URL(base).pathname + "/";
  const r = await handle({ method: job.method, path: job.path, query: new URLSearchParams(job.query), headers: job.headers, body, via: "relay", prefix });
  const payload = typeof r.body === "string" ? Buffer.from(r.body) : r.body ?? Buffer.alloc(0);
  await fetch(`${base}/_phone/reply`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-phone-ts": ts, "x-phone-sig": sig, "x-phone-key": phoneKey },
    body: JSON.stringify({ rid: job.rid, status: r.status, headers: r.headers ?? {}, body: payload.toString("base64") })
  }).catch(() => {
  });
}
var import_node_crypto8, import_node_crypto9, running2, relayStatus, phoneKey;
var init_relay_client = __esm({
  "src/relay-client.ts"() {
    "use strict";
    import_node_crypto8 = require("node:crypto");
    init_server();
    init_settings();
    init_secrets();
    import_node_crypto9 = require("node:crypto");
    init_util();
    running2 = false;
    relayStatus = { connected: false, lastError: "", lastSeen: "" };
    phoneKey = "";
  }
});

// src/proxy.ts
var proxy_exports = {};
__export(proxy_exports, {
  startEgressProxy: () => startEgressProxy
});
function startEgressProxy(port) {
  const server = import_node_http4.default.createServer((req, res) => {
    try {
      const u = new URL(req.url ?? "");
      const up = import_node_http4.default.request({ host: u.hostname, port: u.port || 80, path: u.pathname + u.search, method: req.method, headers: req.headers }, (r) => {
        res.writeHead(r.statusCode ?? 502, r.headers);
        r.pipe(res);
      });
      up.on("error", () => res.writeHead(502).end());
      req.pipe(up);
    } catch {
      res.writeHead(400).end();
    }
  });
  server.on("connect", (req, client2, head) => {
    const [host, port2] = (req.url ?? "").split(":");
    const up = import_node_net.default.connect(Number(port2) || 443, host, () => {
      client2.write("HTTP/1.1 200 Connection Established\r\n\r\n");
      if (head.length) up.write(head);
      up.pipe(client2);
      client2.pipe(up);
    });
    up.on("error", () => client2.destroy());
    client2.on("error", () => up.destroy());
  });
  server.listen(port, "127.0.0.1");
  return server;
}
var import_node_http4, import_node_net;
var init_proxy = __esm({
  "src/proxy.ts"() {
    "use strict";
    import_node_http4 = __toESM(require("node:http"), 1);
    import_node_net = __toESM(require("node:net"), 1);
  }
});

// src/audit-setup.ts
var audit_setup_exports = {};
__export(audit_setup_exports, {
  ensureAuditRoutine: () => ensureAuditRoutine
});
function ensureAuditRoutine() {
  addRunValidator(AUDIT_SYSTEM, (run) => auditFor(run.id)?.report ? null : "The audit finished without producing its report, so it's incomplete.");
  if (listRoutines().some((r) => r.system === AUDIT_SYSTEM)) return;
  const bots = listBots().filter((b) => !b.hidden);
  const owner = bots.find((b) => b.pinned) ?? bots[0];
  if (!owner) return;
  createRoutine({
    botId: owner.id,
    title: "Weekly MausDroid Routine & Skill Audit",
    prompt: AUDIT_PROMPT,
    schedule: { kind: "weekly", days: [0], time: "07:52", timeZone: "Australia/Sydney", missedPolicy: "skip" },
    deadline: "08:00",
    researchCutoffMinutes: 5,
    timeoutMinutes: 8,
    retry: { max: 0, delayMinutes: 1 },
    system: AUDIT_SYSTEM
  });
}
var init_audit_setup = __esm({
  "src/audit-setup.ts"() {
    "use strict";
    init_routines();
    init_bots();
    init_scheduler();
    init_audit();
  }
});

// src/main.ts
var import_node_fs14 = __toESM(require("node:fs"), 1);
var import_node_path12 = __toESM(require("node:path"), 1);

// src/net-fetch.ts
var import_node_http = __toESM(require("node:http"), 1);
var import_node_https = __toESM(require("node:https"), 1);
var import_node_zlib = __toESM(require("node:zlib"), 1);
function nodeFetch(input, init = {}) {
  return new Promise((resolve, reject) => {
    let redirects = 0;
    const go = (urlStr, method, body) => {
      const u = new URL(urlStr);
      const lib2 = u.protocol === "https:" ? import_node_https.default : u.protocol === "http:" ? import_node_http.default : null;
      if (!lib2) return reject(new TypeError(`Unsupported URL ${urlStr}`));
      const headers2 = {};
      const h = init.headers;
      if (h) {
        if (typeof h.forEach === "function" && !Array.isArray(h)) h.forEach((v, k) => headers2[k.toLowerCase()] = v);
        else for (const [k, v] of Array.isArray(h) ? h : Object.entries(h)) if (v !== void 0) headers2[String(k).toLowerCase()] = String(v);
      }
      headers2["accept-encoding"] ??= "gzip, deflate, br";
      let payload;
      if (body !== void 0 && body !== null) {
        payload = Buffer.isBuffer(body) ? body : body instanceof Uint8Array ? Buffer.from(body) : Buffer.from(String(body));
        headers2["content-length"] = String(payload.length);
      }
      const req = lib2.request(u, { method, headers: headers2 }, (res) => {
        const status2 = res.statusCode ?? 0;
        const loc = res.headers.location;
        if ([301, 302, 303, 307, 308].includes(status2) && loc && init.redirect !== "manual" && redirects++ < 10) {
          res.resume();
          const next2 = new URL(loc, u).toString();
          const keep = status2 === 307 || status2 === 308;
          return go(next2, keep ? method : method === "HEAD" ? "HEAD" : "GET", keep ? body : void 0);
        }
        let stream = res;
        const enc = String(res.headers["content-encoding"] ?? "").toLowerCase();
        if (enc === "gzip") stream = res.pipe(import_node_zlib.default.createGunzip());
        else if (enc === "deflate") stream = res.pipe(import_node_zlib.default.createInflate());
        else if (enc === "br") stream = res.pipe(import_node_zlib.default.createBrotliDecompress());
        const noBody = method === "HEAD" || status2 === 204 || status2 === 304 || status2 < 200;
        if (noBody) res.resume();
        resolve(makeResponse(urlStr, status2, res.statusMessage ?? "", res.headers, noBody ? null : stream));
      });
      req.on("error", reject);
      const signal = init.signal;
      if (signal) {
        if (signal.aborted) return req.destroy(signal.reason ?? new Error("aborted"));
        signal.addEventListener("abort", () => req.destroy(signal.reason ?? new Error("The operation was aborted")), { once: true });
      }
      if (payload) req.write(payload);
      req.end();
    };
    const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
    go(url, (init.method ?? "GET").toUpperCase(), init.body);
  });
}
var SimpleHeaders = class {
  m = /* @__PURE__ */ new Map();
  constructor(raw) {
    for (const [k, v] of Object.entries(raw)) {
      if (v === void 0 || k === "content-encoding" || k === "content-length") continue;
      this.m.set(k.toLowerCase(), Array.isArray(v) ? v.join(", ") : String(v));
    }
  }
  get(k) {
    return this.m.get(k.toLowerCase()) ?? null;
  }
  has(k) {
    return this.m.has(k.toLowerCase());
  }
  forEach(fn) {
    this.m.forEach(fn);
  }
  entries() {
    return this.m.entries();
  }
  [Symbol.iterator]() {
    return this.m.entries();
  }
};
function makeResponse(url, status2, statusText, raw, stream) {
  let used = false;
  const all = async () => {
    if (used) throw new TypeError("Body already read");
    used = true;
    if (!stream) return Buffer.alloc(0);
    const chunks = [];
    for await (const c of stream) chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c));
    return Buffer.concat(chunks);
  };
  const body = stream ? {
    getReader() {
      used = true;
      const it = stream[Symbol.asyncIterator]();
      return {
        async read() {
          const r = await it.next();
          return r.done ? { done: true } : { done: false, value: new Uint8Array(Buffer.isBuffer(r.value) ? r.value : Buffer.from(r.value)) };
        },
        async cancel() {
          stream.destroy();
        },
        releaseLock() {
        }
      };
    },
    async cancel() {
      stream.destroy();
    }
  } : null;
  return {
    url,
    status: status2,
    statusText,
    ok: status2 >= 200 && status2 < 300,
    redirected: false,
    headers: new SimpleHeaders(raw),
    body,
    get bodyUsed() {
      return used;
    },
    text: async () => (await all()).toString("utf8"),
    json: async () => JSON.parse((await all()).toString("utf8")),
    arrayBuffer: async () => {
      const b = await all();
      return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);
    }
  };
}
function installNodeFetch() {
  globalThis.fetch = nodeFetch;
}

// src/main.ts
init_config();
if (config.platform === "android" || process.env.MAUSDROID_NODE_FETCH === "1" || typeof globalThis.WebAssembly === "undefined") installNodeFetch();
var statusFile = () => import_node_path12.default.join(config.dataDir, "engine-status.json");
var steps = [];
function record2(step2, error) {
  steps.push({ step: step2, ok: !error, error: error ? error instanceof Error ? `${error.message}
${error.stack ?? ""}` : String(error) : void 0, at: (/* @__PURE__ */ new Date()).toISOString() });
  try {
    import_node_fs14.default.writeFileSync(statusFile(), JSON.stringify({ version: config.version, steps }, null, 1));
  } catch {
  }
  if (error) console.error(`[startup] ${step2} failed:`, error);
  else console.log(`[startup] ${step2} ok`);
}
async function step(name, fn) {
  try {
    await fn();
    record2(name);
  } catch (e) {
    record2(name, e);
  }
}
async function main() {
  import_node_fs14.default.mkdirSync(config.dataDir, { recursive: true });
  record2("begin");
  const { initSecrets: initSecrets2 } = await Promise.resolve().then(() => (init_secrets(), secrets_exports));
  const { ensureDefaultBots: ensureDefaultBots2 } = await Promise.resolve().then(() => (init_bots(), bots_exports));
  const { startServer: startServer2 } = await Promise.resolve().then(() => (init_server(), server_exports));
  const { startScheduler: startScheduler2 } = await Promise.resolve().then(() => (init_scheduler(), scheduler_exports));
  const { startRelayClient: startRelayClient2 } = await Promise.resolve().then(() => (init_relay_client(), relay_client_exports));
  const { startEgressProxy: startEgressProxy2 } = await Promise.resolve().then(() => (init_proxy(), proxy_exports));
  const { initMcpServer: initMcpServer2 } = await Promise.resolve().then(() => (init_mcp_server(), mcp_server_exports));
  const { flushAll: flushAll2 } = await Promise.resolve().then(() => (init_store(), store_exports));
  const { bridge: bridge2, bridgeAvailable: bridgeAvailable2 } = await Promise.resolve().then(() => (init_bridge(), bridge_exports));
  const { settings: settings2 } = await Promise.resolve().then(() => (init_settings(), settings_exports));
  const { getSecret: getSecret2 } = await Promise.resolve().then(() => (init_secrets(), secrets_exports));
  for (const sig of ["SIGTERM", "SIGINT"])
    process.on(sig, () => {
      flushAll2();
      process.exit(0);
    });
  process.on("exit", flushAll2);
  await step("server", () => startServer2());
  await step("secrets", () => initSecrets2());
  await step("bots", () => ensureDefaultBots2());
  const { ensureBuiltinSkills: ensureBuiltinSkills2 } = await Promise.resolve().then(() => (init_skills(), skills_exports));
  await step("skills", () => ensureBuiltinSkills2());
  await step("mcp", () => initMcpServer2());
  await step("proxy", () => startEgressProxy2(config.port + 3));
  const { ensureAuditRoutine: ensureAuditRoutine2 } = await Promise.resolve().then(() => (init_audit_setup(), audit_setup_exports));
  await step("audit-routine", () => ensureAuditRoutine2());
  const { ensureImprover: ensureImprover2, startImprover: startImprover2 } = await Promise.resolve().then(() => (init_improve(), improve_exports));
  await step("improver", () => ensureImprover2());
  await step("scheduler", () => startScheduler2());
  await step("improver-reveal", () => startImprover2());
  await step("website", () => startRelayClient2());
  const ts = settings2().tailscale;
  if (bridgeAvailable2() && ts.enabled) await step("tailscale", () => bridge2("/tailscale/start", { hostname: ts.hostname, authKey: getSecret2("tailscale:authkey") ?? "" }));
  if (bridgeAvailable2()) await step("ready", () => bridge2("/engine/ready", { version: config.version, port: config.port }));
  console.log(`MausDroid engine ${config.version} on http://127.0.0.1:${config.port}/?t=${config.platform === "desktop-dev" ? config.localToken : "\u2026"}`);
}
process.on("uncaughtException", (e) => record2("uncaught", e));
process.on("unhandledRejection", (e) => record2("unhandled", e));
main().catch((e) => record2("main", e));
