"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key2) && key2 !== except)
        __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// src/config.ts
var import_node_path, import_node_crypto, config;
var init_config = __esm({
  "src/config.ts"() {
    "use strict";
    import_node_path = __toESM(require("node:path"), 1);
    import_node_crypto = require("node:crypto");
    config = {
      version: "0.2.0",
      apkVersion: process.env.MAUSDROID_APK_VERSION ?? "dev",
      dataDir: process.env.MAUSDROID_DATA_DIR ?? import_node_path.default.resolve(".mausdroid-data"),
      uiDir: process.env.MAUSDROID_UI_DIR ?? import_node_path.default.resolve("../ui/dist"),
      port: Number(process.env.MAUSDROID_PORT ?? 8737),
      /** Secret the on-phone UI uses; the shell passes it in the WebView URL. */
      localToken: process.env.MAUSDROID_TOKEN ?? (0, import_node_crypto.randomBytes)(24).toString("hex"),
      bridgeUrl: process.env.MAUSDROID_BRIDGE_URL ?? "",
      bridgeToken: process.env.MAUSDROID_BRIDGE_TOKEN ?? "",
      /** Local HTTP proxy (from tsbridge) that reaches devices on your tailnet. */
      tailnetProxy: process.env.MAUSDROID_TAILNET_PROXY ?? "127.0.0.1:8739",
      platform: process.env.MAUSDROID_PLATFORM ?? "desktop-dev"
    };
  }
});

// src/bridge.ts
var bridge_exports = {};
__export(bridge_exports, {
  bridge: () => bridge,
  bridgeAvailable: () => bridgeAvailable
});
async function bridge(path8, body, timeoutMs = 6e4) {
  if (!config.bridgeUrl) throw new Error("This feature needs the Android app (no native bridge in this run).");
  const res = await fetch(`${config.bridgeUrl}${path8}`, {
    method: body === void 0 ? "GET" : "POST",
    headers: { "content-type": "application/json", "x-bridge-token": config.bridgeToken },
    body: body === void 0 ? void 0 : JSON.stringify(body),
    signal: AbortSignal.timeout(timeoutMs)
  });
  const text = await res.text();
  let data;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }
  if (!res.ok) throw new Error(data?.error ?? `Native bridge ${path8}: HTTP ${res.status}`);
  return data;
}
var bridgeAvailable;
var init_bridge = __esm({
  "src/bridge.ts"() {
    "use strict";
    init_config();
    bridgeAvailable = () => Boolean(config.bridgeUrl);
  }
});

// src/store.ts
var store_exports = {};
__export(store_exports, {
  JsonFile: () => JsonFile,
  collection: () => collection,
  dataPath: () => dataPath,
  flushAll: () => flushAll
});
function collection(name, initial) {
  let f = files.get(name);
  if (!f) {
    f = new JsonFile(import_node_path2.default.join(config.dataDir, `${name}.json`), initial);
    files.set(name, f);
  }
  return f;
}
function flushAll() {
  for (const f of files.values()) {
    try {
      f.flush();
    } catch {
    }
  }
}
function dataPath(...parts) {
  const p = import_node_path2.default.join(config.dataDir, ...parts);
  import_node_fs.default.mkdirSync(import_node_path2.default.dirname(p), { recursive: true });
  return p;
}
var import_node_fs, import_node_path2, JsonFile, files;
var init_store = __esm({
  "src/store.ts"() {
    "use strict";
    import_node_fs = __toESM(require("node:fs"), 1);
    import_node_path2 = __toESM(require("node:path"), 1);
    init_config();
    JsonFile = class {
      constructor(file4, initial) {
        this.file = file4;
        import_node_fs.default.mkdirSync(import_node_path2.default.dirname(file4), { recursive: true });
        try {
          this.value = JSON.parse(import_node_fs.default.readFileSync(file4, "utf8"));
        } catch {
          this.value = initial;
        }
      }
      value;
      timer = null;
      get() {
        return this.value;
      }
      set(next) {
        this.value = next;
        this.schedule();
      }
      update(fn) {
        fn(this.value);
        this.schedule();
        return this.value;
      }
      flush() {
        if (this.timer) clearTimeout(this.timer);
        this.timer = null;
        const tmp = `${this.file}.tmp`;
        import_node_fs.default.writeFileSync(tmp, JSON.stringify(this.value));
        import_node_fs.default.renameSync(tmp, this.file);
      }
      schedule() {
        if (this.timer) return;
        this.timer = setTimeout(() => this.flush(), 150);
      }
    };
    files = /* @__PURE__ */ new Map();
  }
});

// src/secrets.ts
var secrets_exports = {};
__export(secrets_exports, {
  getSecret: () => getSecret,
  hasSecret: () => hasSecret,
  initSecrets: () => initSecrets,
  setSecret: () => setSecret
});
async function load() {
  if (loaded) return;
  for (const [name, stored] of Object.entries(file.get())) {
    try {
      if (stored.startsWith("ks:")) {
        const { plain } = await bridge("/secret/decrypt", { cipher: stored.slice(3) });
        cache.set(name, plain);
      } else if (stored.startsWith("dev:")) {
        cache.set(name, Buffer.from(stored.slice(4), "base64").toString("utf8"));
      }
    } catch {
    }
  }
  loaded = true;
}
async function initSecrets() {
  await load();
}
function getSecret(name) {
  return cache.get(name);
}
function hasSecret(name) {
  return Boolean(cache.get(name));
}
async function setSecret(name, value) {
  await load();
  if (!value) {
    cache.delete(name);
    file.update((f) => {
      delete f[name];
    });
    return;
  }
  let stored;
  if (bridgeAvailable()) {
    const { cipher } = await bridge("/secret/encrypt", { plain: value });
    stored = `ks:${cipher}`;
  } else {
    stored = `dev:${Buffer.from(value, "utf8").toString("base64")}`;
  }
  cache.set(name, value);
  file.update((f) => {
    f[name] = stored;
  });
}
var file, cache, loaded;
var init_secrets = __esm({
  "src/secrets.ts"() {
    "use strict";
    init_bridge();
    init_store();
    file = collection("secrets", {});
    cache = /* @__PURE__ */ new Map();
    loaded = false;
  }
});

// src/util.ts
function errorText(e) {
  return e instanceof Error ? e.message : String(e);
}
function clip(text, max = 24e3) {
  if (text.length <= max) return text;
  return `${text.slice(0, max)}

[\u2026 ${text.length - max} more characters cut]`;
}
function htmlToText(html) {
  return html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<noscript[\s\S]*?<\/noscript>/gi, " ").replace(/<(br|\/p|\/div|\/h[1-6]|\/li|\/tr)[^>]*>/gi, "\n").replace(/<a [^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi, "$2 ($1)").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/[ \t]+/g, " ").replace(/\n\s*\n\s*/g, "\n\n").trim();
}
var import_node_crypto2, id, now, sleep;
var init_util = __esm({
  "src/util.ts"() {
    "use strict";
    import_node_crypto2 = require("node:crypto");
    id = (prefix) => `${prefix}_${(0, import_node_crypto2.randomUUID)().replace(/-/g, "").slice(0, 16)}`;
    now = () => (/* @__PURE__ */ new Date()).toISOString();
    sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  }
});

// src/bots.ts
var bots_exports = {};
__export(bots_exports, {
  DEFAULT_BOTS: () => DEFAULT_BOTS,
  addMessage: () => addMessage,
  clearChat: () => clearChat,
  createBot: () => createBot,
  deleteBot: () => deleteBot,
  ensureDefaultBots: () => ensureDefaultBots,
  getBot: () => getBot,
  history: () => history,
  lastMessage: () => lastMessage,
  listBots: () => listBots,
  messages: () => messages,
  patchMessage: () => patchMessage,
  setHistory: () => setHistory,
  updateBot: () => updateBot
});
function listBots() {
  return botsFile.get();
}
function getBot(botId) {
  return botsFile.get().find((b) => b.id === botId);
}
function createBot(input) {
  const bot = {
    id: id("bot"),
    name: input.name?.trim() || "New bot",
    emoji: input.emoji || "\u{1F916}",
    color: input.color || "#6c757d",
    persona: input.persona ?? "",
    providerId: input.providerId ?? null,
    model: input.model ?? null,
    approvalMode: input.approvalMode ?? "ask-risky",
    tools: { web: true, browser: true, apps: true, phone: false, ...input.tools ?? {} },
    skills: input.skills ?? [],
    pinned: input.pinned ?? false,
    hidden: false,
    createdAt: now(),
    unread: 0,
    alwaysAllow: []
  };
  botsFile.update((b) => void b.push(bot));
  return bot;
}
function updateBot(botId, patch) {
  let found;
  botsFile.update((all) => {
    found = all.find((b) => b.id === botId);
    if (found) Object.assign(found, patch, { id: found.id, createdAt: found.createdAt });
  });
  if (!found) throw new Error("No such bot");
  return found;
}
function deleteBot(botId) {
  botsFile.update((all) => {
    const i = all.findIndex((b) => b.id === botId);
    if (i >= 0) all.splice(i, 1);
  });
  for (const f of [`messages-${botId}`, `history-${botId}`]) import_node_fs2.default.rmSync(dataPath("chats", `${f}.json`), { force: true });
}
function ensureDefaultBots() {
  if (botsFile.get().length) return;
  DEFAULT_BOTS.forEach((b, i) => createBot({ ...b, pinned: i === 0 }));
}
function messages(botId, before, limit = 60) {
  const all = msgs(botId).get();
  let end = all.length;
  if (before) {
    const i = all.findIndex((m) => m.id === before);
    if (i >= 0) end = i;
  }
  return all.slice(Math.max(0, end - limit), end);
}
function addMessage(botId, m) {
  const full = { id: m.id ?? id("msg"), at: now(), ...m };
  msgs(botId).update((a) => void a.push(full));
  return full;
}
function patchMessage(botId, msgId, patch) {
  let found;
  msgs(botId).update((a) => {
    found = a.find((x) => x.id === msgId);
    if (found) Object.assign(found, patch);
  });
  return found;
}
function history(botId) {
  return hist(botId).get();
}
function setHistory(botId, h) {
  hist(botId).set(h);
}
function clearChat(botId) {
  msgs(botId).set([]);
  hist(botId).set([]);
  updateBot(botId, { cliSession: void 0 });
}
function lastMessage(botId) {
  const a = msgs(botId).get();
  for (let i = a.length - 1; i >= 0; i--) if (a[i].role === "user" || a[i].role === "assistant") return a[i];
  return void 0;
}
var import_node_fs2, botsFile, DEFAULT_BOTS, msgs, hist;
var init_bots = __esm({
  "src/bots.ts"() {
    "use strict";
    import_node_fs2 = __toESM(require("node:fs"), 1);
    init_store();
    init_util();
    botsFile = collection("bots", []);
    DEFAULT_BOTS = [
      { name: "Maus", emoji: "\u{1F42D}", color: "#1084fe", persona: "You are Maus, the user's main personal assistant. You are warm, brief and practical. You plan, delegate to tools, and check in before anything risky." },
      { name: "Researcher", emoji: "\u{1F50E}", color: "#2a9d8f", persona: "You research topics thoroughly using web search and the browser, cite your sources with links, and summarise clearly for a non-technical reader." },
      { name: "Inbox", emoji: "\u{1F4EC}", color: "#e76f51", persona: "You look after the user's email, calendar and messages through connected apps. You summarise what matters, draft replies for approval, and never send without approval." }
    ];
    msgs = (botId) => collection(`chats/messages-${botId}`, []);
    hist = (botId) => collection(`chats/history-${botId}`, []);
  }
});

// src/events.ts
function emit(type, data = {}) {
  const e = { ...data, seq: ++seq, type, at: (/* @__PURE__ */ new Date()).toISOString() };
  backlog.push(e);
  if (backlog.length > 2e3) backlog.splice(0, backlog.length - 2e3);
  for (const l of listeners) {
    try {
      l(e);
    } catch {
    }
  }
  return e;
}
function subscribe(l) {
  listeners.add(l);
  return () => listeners.delete(l);
}
function eventsSince(since) {
  return backlog.filter((e) => e.seq > since);
}
function waitForEvents(since, ms) {
  const ready = eventsSince(since);
  if (ready.length) return Promise.resolve(ready);
  return new Promise((resolve) => {
    const t = setTimeout(() => {
      off();
      resolve([]);
    }, ms);
    const off = subscribe(() => {
      clearTimeout(t);
      off();
      resolve(eventsSince(since));
    });
  });
}
var listeners, backlog, seq, currentSeq;
var init_events = __esm({
  "src/events.ts"() {
    "use strict";
    listeners = /* @__PURE__ */ new Set();
    backlog = [];
    seq = 0;
    currentSeq = () => seq;
  }
});

// src/time.ts
function localParts(d) {
  return { hm: `${pad(d.getHours())}:${pad(d.getMinutes())}`, wd: d.getDay(), ymd: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` };
}
function fmtLong(d) {
  const h = d.getHours();
  const off = -d.getTimezoneOffset();
  const sign = off >= 0 ? "+" : "-";
  const tz = `UTC${sign}${pad(Math.floor(Math.abs(off) / 60))}:${pad(Math.abs(off) % 60)}`;
  return `${DAYS[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}, ${h % 12 || 12}:${pad(d.getMinutes())} ${h < 12 ? "am" : "pm"} (${tz})`;
}
function deviceTimeZone() {
  try {
    const I = globalThis.Intl;
    const z = I?.DateTimeFormat?.().resolvedOptions?.().timeZone;
    if (z) return z;
  } catch {
  }
  if (process.env.TZ) return process.env.TZ;
  const off = -(/* @__PURE__ */ new Date()).getTimezoneOffset();
  return `UTC${off >= 0 ? "+" : "-"}${pad(Math.floor(Math.abs(off) / 60))}:${pad(Math.abs(off) % 60)}`;
}
var DAYS, MONTHS, pad;
var init_time = __esm({
  "src/time.ts"() {
    "use strict";
    DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    pad = (n) => String(n).padStart(2, "0");
  }
});

// src/settings.ts
var settings_exports = {};
__export(settings_exports, {
  PROVIDER_PRESETS: () => PROVIDER_PRESETS,
  provider: () => provider,
  publicSettings: () => publicSettings,
  renamedProvider: () => renamedProvider,
  settings: () => settings,
  updateSettings: () => updateSettings
});
function provider(id2) {
  return settings().providers.find((p) => p.id === id2);
}
function publicSettings() {
  const s = settings();
  return {
    ...s,
    providers: s.providers.map((p) => ({ ...p, hasKey: hasSecret(`provider:${p.id}`) })),
    composio: { connected: hasSecret("composio"), userId: s.composio.userId },
    website: { ...s.website, passwordSet: hasSecret("website:password") },
    tailscale: { ...s.tailscale, hasAuthKey: hasSecret("tailscale:authkey") },
    github: { hasToken: hasSecret("github") }
  };
}
var PROVIDER_PRESETS, RENAMED, settingsFile, renamedProvider, settings, updateSettings;
var init_settings = __esm({
  "src/settings.ts"() {
    "use strict";
    init_store();
    init_secrets();
    init_time();
    PROVIDER_PRESETS = [
      // Your subscriptions: sign in with your account (no API keys). Each runs the company's official program.
      { id: "claude", label: "Claude", kind: "subscription", subId: "claude", defaultModel: "default", models: ["default", "opus", "sonnet", "haiku"], runOn: "phone", enabled: false, needsKey: false, note: "Sign in with your Claude account (Pro or Max). Uses Anthropic's official Claude Code." },
      { id: "chatgpt", label: "ChatGPT", kind: "subscription", subId: "chatgpt", defaultModel: "default", models: ["default"], runOn: "phone", enabled: false, needsKey: false, note: "Sign in with your ChatGPT account (Plus, Pro, Business or Edu). Uses OpenAI's official Codex." },
      { id: "gemini", label: "Gemini", kind: "subscription", subId: "gemini", defaultModel: "default", models: ["default", "gemini-2.5-pro", "gemini-2.5-flash"], runOn: "phone", enabled: false, needsKey: false, free: true, note: "Sign in with your Google account (free, or your Google AI plan). Uses Google's official Gemini CLI." },
      // Other models: API keys, free services, and local models.
      { id: "openrouter", label: "OpenRouter (many models, some free)", kind: "openai", baseUrl: "https://openrouter.ai/api/v1", defaultModel: "openrouter/auto", models: ["openrouter/auto"], enabled: false, needsKey: true, free: true, note: "Models ending in :free cost nothing." },
      { id: "groq", label: "Groq (free tier)", kind: "openai", baseUrl: "https://api.groq.com/openai/v1", defaultModel: "llama-3.3-70b-versatile", models: ["llama-3.3-70b-versatile"], enabled: false, needsKey: true, free: true },
      { id: "local", label: "Local / custom model (phone, PC or any device)", kind: "openai", baseUrl: "http://127.0.0.1:11434/v1", defaultModel: "llama3.2", models: [], enabled: false, needsKey: false, free: true, note: "Any OpenAI-compatible server: on this phone, your PC over Tailscale, or another device." }
    ];
    RENAMED = { anthropic: "claude", openai: "chatgpt", "claude-code": "claude", codex: "chatgpt" };
    settingsFile = collection("settings", {
      providers: PROVIDER_PRESETS,
      defaultProvider: null,
      composio: {},
      website: { enabled: false },
      tailscale: { enabled: false, hostname: "mausdroid" },
      onboardingDone: false,
      timeZone: deviceTimeZone(),
      quietHours: null,
      voice: { engine: "phone", readReplies: "voice", rate: 1 },
      assistant: { botId: null, speak: true }
    });
    settingsFile.update((s) => {
      s.voice ??= { engine: "phone", readReplies: "voice", rate: 1 };
      s.assistant ??= { botId: null, speak: true };
    });
    settingsFile.update((s) => {
      s.providers = s.providers.filter((p) => !RENAMED[p.id] && !(p.id === "gemini" && p.kind !== "subscription"));
      for (const p of PROVIDER_PRESETS) {
        const have = s.providers.find((x) => x.id === p.id);
        if (!have) s.providers.push(p);
        else if (p.kind === "subscription") Object.assign(have, { label: p.label, note: p.note, kind: p.kind, subId: p.subId, needsKey: false, baseUrl: void 0 });
      }
      s.providers.sort((a, b) => PROVIDER_PRESETS.findIndex((p) => p.id === a.id) - PROVIDER_PRESETS.findIndex((p) => p.id === b.id));
      if (s.defaultProvider && RENAMED[s.defaultProvider]) s.defaultProvider = RENAMED[s.defaultProvider];
      if (s.defaultProvider && !s.providers.find((p) => p.id === s.defaultProvider)) s.defaultProvider = null;
    });
    renamedProvider = (id2) => id2 && RENAMED[id2] || id2;
    settings = () => settingsFile.get();
    updateSettings = (fn) => settingsFile.update(fn);
  }
});

// src/sse.ts
async function* readSSE(res) {
  if (!res.body) return;
  const reader = res.body.getReader();
  const decoder = new import_node_string_decoder.StringDecoder("utf8");
  let buf = "";
  let event = "message";
  let data = [];
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.write(Buffer.from(value));
    let nl;
    while ((nl = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, nl).replace(/\r$/, "");
      buf = buf.slice(nl + 1);
      if (line === "") {
        if (data.length) yield { event, data: data.join("\n") };
        event = "message";
        data = [];
      } else if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) data.push(line.slice(5).replace(/^ /, ""));
    }
  }
  if (data.length) yield { event, data: data.join("\n") };
}
var import_node_string_decoder;
var init_sse = __esm({
  "src/sse.ts"() {
    "use strict";
    import_node_string_decoder = require("node:string_decoder");
  }
});

// src/providers/anthropic.ts
function toAnthropic(messages2) {
  return messages2.map((m) => ({
    role: m.role,
    content: m.content.map((b) => {
      switch (b.type) {
        case "text":
          return { type: "text", text: b.text };
        case "image":
          return { type: "image", source: { type: "base64", media_type: b.mediaType, data: b.data } };
        case "tool_use":
          return { type: "tool_use", id: b.id, name: b.name, input: b.input };
        case "tool_result":
          return {
            type: "tool_result",
            tool_use_id: b.toolUseId,
            is_error: b.isError || void 0,
            content: [
              { type: "text", text: b.content || "(no output)" },
              ...(b.images ?? []).map((i) => ({ type: "image", source: { type: "base64", media_type: i.mediaType, data: i.data } }))
            ]
          };
      }
    })
  }));
}
async function anthropicTurn(req, apiKey) {
  const res = await fetch(`${API}/messages`, {
    method: "POST",
    signal: req.signal,
    headers: { "content-type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({
      model: req.model,
      max_tokens: 16e3,
      stream: true,
      system: req.system,
      messages: toAnthropic(req.messages),
      tools: req.tools.map((t) => ({ name: t.name, description: t.description, input_schema: t.inputSchema }))
    })
  });
  if (!res.ok) throw new Error(`Claude API: HTTP ${res.status} ${(await res.text()).slice(0, 400)}`);
  const blocks = [];
  let stop = "end";
  const usage = {};
  for await (const { data } of readSSE(res)) {
    const ev = JSON.parse(data);
    switch (ev.type) {
      case "message_start":
        usage.input = ev.message?.usage?.input_tokens;
        break;
      case "content_block_start":
        if (ev.content_block.type === "text") blocks[ev.index] = { type: "text", text: "" };
        else if (ev.content_block.type === "tool_use")
          blocks[ev.index] = { type: "tool_use", id: ev.content_block.id, name: ev.content_block.name, input: {}, _json: "" };
        break;
      case "content_block_delta": {
        const b = blocks[ev.index];
        if (ev.delta.type === "text_delta" && b?.type === "text") {
          b.text += ev.delta.text;
          req.onText(ev.delta.text);
        } else if (ev.delta.type === "input_json_delta" && b?.type === "tool_use") b._json += ev.delta.partial_json;
        break;
      }
      case "content_block_stop": {
        const b = blocks[ev.index];
        if (b?.type === "tool_use") {
          b.input = b._json ? JSON.parse(b._json) : {};
          delete b._json;
        }
        break;
      }
      case "message_delta":
        if (ev.delta?.stop_reason === "tool_use") stop = "tool_use";
        else if (ev.delta?.stop_reason === "max_tokens") stop = "max_tokens";
        usage.output = ev.usage?.output_tokens;
        break;
      case "error":
        throw new Error(`Claude API: ${ev.error?.message ?? "stream error"}`);
    }
  }
  return { blocks: blocks.filter(Boolean), stopReason: stop, usage };
}
async function anthropicModels(apiKey) {
  const res = await fetch(`${API}/models?limit=100`, { headers: { "x-api-key": apiKey, "anthropic-version": "2023-06-01" } });
  if (!res.ok) throw new Error(`Claude API: HTTP ${res.status}`);
  const j = await res.json();
  return j.data.map((m) => m.id);
}
var API;
var init_anthropic = __esm({
  "src/providers/anthropic.ts"() {
    "use strict";
    init_sse();
    API = "https://api.anthropic.com/v1";
  }
});

// src/providers/openai.ts
function toOpenAI(system, messages2) {
  const out = [{ role: "system", content: system }];
  for (const m of messages2) {
    if (m.role === "assistant") {
      const text = m.content.filter((b) => b.type === "text").map((b) => b.text).join("");
      const calls = m.content.filter((b) => b.type === "tool_use");
      out.push({
        role: "assistant",
        content: text || null,
        tool_calls: calls.length ? calls.map((c) => ({ id: c.id, type: "function", function: { name: c.name, arguments: JSON.stringify(c.input) } })) : void 0
      });
      continue;
    }
    const parts = [];
    for (const b of m.content) {
      if (b.type === "tool_result") {
        out.push({ role: "tool", tool_call_id: b.toolUseId, content: (b.isError ? "ERROR: " : "") + (b.content || "(no output)") });
        for (const img of b.images ?? []) parts.push({ type: "image_url", image_url: { url: `data:${img.mediaType};base64,${img.data}` } });
      } else if (b.type === "text") parts.push({ type: "text", text: b.text });
      else if (b.type === "image") parts.push({ type: "image_url", image_url: { url: `data:${b.mediaType};base64,${b.data}` } });
    }
    if (parts.length) out.push({ role: "user", content: parts.length === 1 && parts[0].type === "text" ? parts[0].text : parts });
  }
  return out;
}
async function openaiTurn(req, baseUrl, apiKey) {
  const headers2 = { "content-type": "application/json" };
  if (apiKey) headers2.authorization = `Bearer ${apiKey}`;
  if (baseUrl.includes("openrouter.ai")) {
    headers2["HTTP-Referer"] = "https://github.com/DanGeo13/MausDroid";
    headers2["X-Title"] = "MausDroid";
  }
  const res = await fetch(`${baseUrl.replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    signal: req.signal,
    headers: headers2,
    body: JSON.stringify({
      model: req.model,
      stream: true,
      messages: toOpenAI(req.system, req.messages),
      tools: req.tools.length ? req.tools.map((t) => ({ type: "function", function: { name: t.name, description: t.description, parameters: t.inputSchema } })) : void 0
    })
  });
  if (!res.ok) throw new Error(`Model endpoint: HTTP ${res.status} ${(await res.text()).slice(0, 400)}`);
  let text = "";
  const calls = [];
  let finish = "";
  const usage = {};
  for await (const { data } of readSSE(res)) {
    if (data === "[DONE]") break;
    const ev = JSON.parse(data);
    if (ev.error) throw new Error(`Model endpoint: ${ev.error.message ?? JSON.stringify(ev.error)}`);
    if (ev.usage) {
      usage.input = ev.usage.prompt_tokens;
      usage.output = ev.usage.completion_tokens;
    }
    const choice = ev.choices?.[0];
    if (!choice) continue;
    const d = choice.delta ?? {};
    if (d.content) {
      text += d.content;
      req.onText(d.content);
    }
    for (const tc of d.tool_calls ?? []) {
      const i = tc.index ?? calls.length;
      calls[i] ??= { id: tc.id ?? `call_${i}`, name: "", args: "" };
      if (tc.id) calls[i].id = tc.id;
      if (tc.function?.name) calls[i].name += tc.function.name;
      if (tc.function?.arguments) calls[i].args += tc.function.arguments;
    }
    if (choice.finish_reason) finish = choice.finish_reason;
  }
  const blocks = [];
  if (text) blocks.push({ type: "text", text });
  for (const c of calls.filter(Boolean)) {
    let input = {};
    try {
      input = c.args ? JSON.parse(c.args) : {};
    } catch {
      input = { _unparsed: c.args };
    }
    blocks.push({ type: "tool_use", id: c.id, name: c.name, input });
  }
  const stopReason = calls.length ? "tool_use" : finish === "length" ? "max_tokens" : "end";
  return { blocks, stopReason, usage };
}
async function openaiModels(baseUrl, apiKey) {
  const res = await fetch(`${baseUrl.replace(/\/$/, "")}/models`, { headers: apiKey ? { authorization: `Bearer ${apiKey}` } : {} });
  if (!res.ok) throw new Error(`Model list: HTTP ${res.status}`);
  const j = await res.json();
  return (j.data?.map((m) => m.id) ?? j.models?.map((m) => m.name) ?? []).map((m) => m.replace(/^models\//, "")).sort();
}
var init_openai = __esm({
  "src/providers/openai.ts"() {
    "use strict";
    init_sse();
  }
});

// src/archive.ts
async function download(url, file4, onProgress) {
  const res = await fetch(url, { headers: { "user-agent": "MausDroid" } });
  if (!res.ok || !res.body) throw new Error(`Download failed (HTTP ${res.status}) for ${url}`);
  const total = Number(res.headers.get("content-length") ?? 0);
  import_node_fs3.default.mkdirSync(import_node_path3.default.dirname(file4), { recursive: true });
  const out = import_node_fs3.default.createWriteStream(`${file4}.part`);
  const reader = res.body.getReader();
  let done = 0;
  try {
    while (true) {
      const r = await reader.read();
      if (r.done) break;
      done += r.value.length;
      if (!out.write(Buffer.from(r.value))) await new Promise((ok) => out.once("drain", ok));
      onProgress?.(done, total);
    }
  } finally {
    await new Promise((ok) => out.end(ok));
  }
  import_node_fs3.default.renameSync(`${file4}.part`, file4);
}
async function extractTarGz(file4, pick) {
  const written = [];
  let buf = Buffer.alloc(0);
  let current = null;
  let longName = null;
  let collectingLongName = null;
  const consume = (chunk) => {
    buf = buf.length ? Buffer.concat([buf, chunk]) : chunk;
    while (true) {
      if (current) {
        if (current.remaining > 0) {
          if (!buf.length) return;
          const n = Math.min(current.remaining, buf.length);
          const part = buf.subarray(0, n);
          if (collectingLongName) collectingLongName.push(Buffer.from(part));
          else if (current.out !== null) import_node_fs3.default.writeSync(current.out, part);
          buf = buf.subarray(n);
          current.remaining -= n;
          if (current.remaining > 0) return;
        }
        if (buf.length < current.pad) return;
        buf = buf.subarray(current.pad);
        if (current.out !== null) import_node_fs3.default.closeSync(current.out);
        if (collectingLongName) {
          longName = Buffer.concat(collectingLongName).toString("utf8").replace(/\0.*$/s, "");
          collectingLongName = null;
        }
        current = null;
      }
      if (buf.length < 512) return;
      const h = buf.subarray(0, 512);
      buf = buf.subarray(512);
      if (h.every((b) => b === 0)) continue;
      const str2 = (a, b) => h.subarray(a, b).toString("utf8").replace(/\0.*$/s, "");
      const size = parseInt(str2(124, 136).trim() || "0", 8) || 0;
      const type = String.fromCharCode(h[156] || 48);
      const prefix = str2(345, 500);
      let name = longName ?? (prefix ? `${prefix}/${str2(0, 100)}` : str2(0, 100));
      longName = null;
      const pad2 = (512 - size % 512) % 512;
      if (type === "L") {
        collectingLongName = [];
        current = { remaining: size, pad: pad2, out: null };
        continue;
      }
      name = name.replace(/^\.\//, "");
      let out = null;
      if (type === "0" || type === "\0" || type === "7") {
        const dest = pick(name);
        if (dest) {
          import_node_fs3.default.mkdirSync(import_node_path3.default.dirname(dest), { recursive: true });
          out = import_node_fs3.default.openSync(dest, "w", 493);
          written.push(dest);
        }
      } else if (type === "2") {
        const dest = pick(name);
        if (dest) written.push(`${dest}\0${str2(157, 257)}`);
      }
      current = { remaining: size, pad: pad2, out };
    }
  };
  await (0, import_promises.pipeline)(
    import_node_fs3.default.createReadStream(file4),
    import_node_zlib2.default.createGunzip(),
    new import_node_stream.Writable({
      write(chunk, _enc, cb) {
        try {
          consume(chunk);
          cb();
        } catch (e) {
          cb(e);
        }
      }
    })
  );
  const files2 = written.filter((w) => !w.includes("\0"));
  for (const link of written.filter((w) => w.includes("\0"))) {
    const [dest, target] = link.split("\0");
    const src = import_node_path3.default.join(import_node_path3.default.dirname(dest), import_node_path3.default.basename(target));
    if (import_node_fs3.default.existsSync(src)) {
      import_node_fs3.default.copyFileSync(src, dest);
      import_node_fs3.default.chmodSync(dest, 493);
      files2.push(dest);
    }
  }
  return files2;
}
function extractZip(file4, pick) {
  const zip = import_node_fs3.default.readFileSync(file4);
  let eocd = zip.length - 22;
  while (eocd >= 0 && zip.readUInt32LE(eocd) !== 101010256) eocd--;
  if (eocd < 0) throw new Error("Not a zip file");
  const count = zip.readUInt16LE(eocd + 10);
  let p = zip.readUInt32LE(eocd + 16);
  const out = [];
  for (let i = 0; i < count; i++) {
    const method = zip.readUInt16LE(p + 10);
    const csize = zip.readUInt32LE(p + 20);
    const nlen = zip.readUInt16LE(p + 28);
    const elen = zip.readUInt16LE(p + 30);
    const clen = zip.readUInt16LE(p + 32);
    const local = zip.readUInt32LE(p + 42);
    const name = zip.subarray(p + 46, p + 46 + nlen).toString("utf8");
    p += 46 + nlen + elen + clen;
    const dest = name.endsWith("/") ? null : pick(name);
    if (!dest) continue;
    const lnlen = zip.readUInt16LE(local + 26);
    const lelen = zip.readUInt16LE(local + 28);
    const data = zip.subarray(local + 30 + lnlen + lelen, local + 30 + lnlen + lelen + csize);
    import_node_fs3.default.mkdirSync(import_node_path3.default.dirname(dest), { recursive: true });
    import_node_fs3.default.writeFileSync(dest, method === 8 ? import_node_zlib2.default.inflateRawSync(data) : data, { mode: 493 });
    out.push(dest);
  }
  return out;
}
var import_node_fs3, import_node_path3, import_node_zlib2, import_promises, import_node_stream;
var init_archive = __esm({
  "src/archive.ts"() {
    "use strict";
    import_node_fs3 = __toESM(require("node:fs"), 1);
    import_node_path3 = __toESM(require("node:path"), 1);
    import_node_zlib2 = __toESM(require("node:zlib"), 1);
    import_promises = require("node:stream/promises");
    import_node_stream = require("node:stream");
  }
});

// src/subscriptions.ts
function set(id2, patch) {
  const before = status.get(id2)?.stage;
  const s = { ...status.get(id2) ?? { id: id2, stage: "not-installed" }, ...patch, id: id2 };
  status.set(id2, s);
  emit("subs.changed", { id: id2, status: s });
  if (s.stage === "signed-in" && before !== "signed-in") for (const l of signedInListeners) l(id2);
}
function isSignedIn(id2) {
  if (id2 === "claude") return Boolean(getSecret("sub:claude:token"));
  if (id2 === "chatgpt") return import_node_fs4.default.existsSync(import_node_path4.default.join(subHome("chatgpt"), ".codex", "auth.json"));
  return import_node_fs4.default.existsSync(import_node_path4.default.join(subHome("gemini"), ".gemini", "oauth_creds.json"));
}
function subStatus(id2) {
  const s = status.get(id2);
  if (s && (s.stage === "installing" || s.stage === "signing-in" || s.stage === "error")) return s;
  return { id: id2, stage: isSignedIn(id2) ? "signed-in" : installed(id2) ? "installed" : "not-installed", message: s?.message };
}
async function npmTarball(pkg, version) {
  const meta = await (await fetch(`https://registry.npmjs.org/${pkg.replace("/", "%2F")}`)).json();
  const v = version ?? meta["dist-tags"]?.latest;
  const d = meta.versions?.[v]?.dist;
  if (!d) throw new Error(`Couldn't find ${pkg}@${v} on npm`);
  return { version: v, url: d.tarball, integrity: d.integrity };
}
function checkIntegrity(file4, integrity) {
  const [algo, want] = integrity.split("-");
  const got = import_node_crypto3.default.createHash(algo).update(import_node_fs4.default.readFileSync(file4)).digest("base64");
  if (got !== want) throw new Error("Download check failed (file damaged). Try again.");
}
async function ensureMusl(id2) {
  if (hasMusl() && import_node_fs4.default.existsSync(import_node_path4.default.join(lib(), "libstdc++.so.6"))) return;
  set(id2, { message: "Getting system libraries (Alpine Linux)\u2026" });
  const base = "https://dl-cdn.alpinelinux.org/alpine/latest-stable/main/aarch64";
  const idxFile = import_node_path4.default.join(root(), "dl", "APKINDEX.tar.gz");
  await download(`${base}/APKINDEX.tar.gz`, idxFile);
  const idxOut = import_node_path4.default.join(root(), "dl", "APKINDEX");
  await extractTarGz(idxFile, (n) => n === "APKINDEX" ? idxOut : null);
  const index = import_node_fs4.default.readFileSync(idxOut, "utf8");
  const versionOf = (pkg) => index.match(new RegExp(`\\nP:${pkg.replace(/[+]/g, "\\+")}\\nV:([^\\n]+)`))?.[1];
  for (const pkg of ["musl", "libstdc++", "libgcc"]) {
    const v = versionOf(pkg);
    if (!v) throw new Error(`Alpine package ${pkg} not found`);
    const f = import_node_path4.default.join(root(), "dl", `${pkg}-${v}.apk`);
    await download(`${base}/${pkg}-${v}.apk`, f);
    await extractTarGz(f, (n) => /^(usr\/)?lib\/[^/]+\.so[.\d]*$/.test(n) ? import_node_path4.default.join(lib(), import_node_path4.default.basename(n)) : null);
    import_node_fs4.default.rmSync(f, { force: true });
  }
  if (!import_node_fs4.default.existsSync(import_node_path4.default.join(lib(), "libc.musl-aarch64.so.1"))) import_node_fs4.default.copyFileSync(import_node_path4.default.join(lib(), "ld-musl-aarch64.so.1"), import_node_path4.default.join(lib(), "libc.musl-aarch64.so.1"));
  if (!hasMusl()) throw new Error("The system library download didn't contain the loader.");
}
function patchInterpreter(file4) {
  const b = import_node_fs4.default.readFileSync(file4);
  const old = Buffer.from("/lib/ld-musl-aarch64.so.1\0");
  const i = b.indexOf(old);
  if (i < 0) return;
  const neu = Buffer.alloc(old.length);
  Buffer.from("./.mausld\0").copy(neu);
  neu.copy(b, i);
  import_node_fs4.default.writeFileSync(file4, b, { mode: 493 });
}
async function install(id2) {
  if (installed(id2)) return;
  if (process.arch !== "arm64" && config.platform === "android") throw new Error("Only 64-bit phones are supported.");
  set(id2, { stage: "installing", progress: 0, message: "Starting download\u2026" });
  import_node_fs4.default.mkdirSync(bin(), { recursive: true });
  const dl = import_node_path4.default.join(root(), "dl");
  if (id2 === "chatgpt") {
    const top = await npmTarball("@openai/codex");
    const t = await npmTarball("@openai/codex", `${top.version}-linux-arm64`);
    const f = import_node_path4.default.join(dl, "codex.tgz");
    await download(t.url, f, progress(id2, `Codex ${top.version} (about 170 MB)`));
    checkIntegrity(f, t.integrity);
    set(id2, { message: "Unpacking\u2026" });
    await extractTarGz(f, (n) => /aarch64-unknown-linux-musl\/bin\/(codex|codex-code-mode-host)$/.test(n) ? bin(import_node_path4.default.basename(n)) : null);
    import_node_fs4.default.rmSync(f, { force: true });
  } else if (id2 === "claude") {
    await ensureMusl(id2);
    const t = await npmTarball("@anthropic-ai/claude-code-linux-arm64-musl");
    const f = import_node_path4.default.join(dl, "claude.tgz");
    await download(t.url, f, progress(id2, `Claude Code ${t.version} (about 170 MB)`));
    checkIntegrity(f, t.integrity);
    set(id2, { message: "Unpacking\u2026" });
    await extractTarGz(f, (n) => n === "package/claude" ? bin("claude") : null);
    import_node_fs4.default.rmSync(f, { force: true });
    patchInterpreter(bin("claude"));
  } else {
    await ensureMusl(id2);
    const BUN = "1.4.5";
    const z = import_node_path4.default.join(dl, "bun.zip");
    await download(`https://github.com/oven-sh/bun/releases/download/bun-v${BUN}/bun-linux-aarch64-musl.zip`, z, progress(id2, `Bun ${BUN} runtime`));
    const sums = await (await fetch(`https://github.com/oven-sh/bun/releases/download/bun-v${BUN}/SHASUMS256.txt`)).text().catch(() => "");
    const want = sums.split("\n").find((l) => l.includes("bun-linux-aarch64-musl.zip"))?.split(/\s+/)[0];
    if (want && import_node_crypto3.default.createHash("sha256").update(import_node_fs4.default.readFileSync(z)).digest("hex") !== want) throw new Error("Bun download check failed. Try again.");
    extractZip(z, (n) => n.endsWith("/bun") ? bin("bun") : null);
    import_node_fs4.default.rmSync(z, { force: true });
    patchInterpreter(bin("bun"));
    const t = await npmTarball("@google/gemini-cli");
    const f = import_node_path4.default.join(dl, "gemini.tgz");
    await download(t.url, f, progress(id2, `Gemini CLI ${t.version}`));
    checkIntegrity(f, t.integrity);
    const dest = import_node_path4.default.join(root(), "gemini");
    import_node_fs4.default.rmSync(dest, { recursive: true, force: true });
    await extractTarGz(f, (n) => n.startsWith("package/") ? import_node_path4.default.join(dest, n.slice(8)) : null);
    import_node_fs4.default.rmSync(f, { force: true });
  }
  set(id2, { stage: "installed", progress: void 0, message: `${SUBS[id2].program} is installed.` });
}
function caBundle() {
  if (certFile && import_node_fs4.default.existsSync(certFile)) return certFile;
  certFile = import_node_path4.default.join(root(), "cacert.pem");
  import_node_fs4.default.writeFileSync(certFile, import_node_tls.default.rootCertificates.join("\n"));
  return certFile;
}
function programEnv(id2) {
  const proxy = `http://127.0.0.1:${config.port + 3}`;
  const env = {
    ...process.env,
    HOME: subHome(id2),
    TMPDIR: import_node_path4.default.dirname(dataPath("tmp", "x")),
    // These Linux programs can't read Android's network settings, so their
    // traffic goes through MausDroid's local proxy, which resolves names.
    HTTPS_PROXY: proxy,
    HTTP_PROXY: proxy,
    https_proxy: proxy,
    http_proxy: proxy,
    NO_PROXY: "127.0.0.1,localhost",
    no_proxy: "127.0.0.1,localhost",
    SSL_CERT_FILE: caBundle(),
    LD_LIBRARY_PATH: lib(),
    SHELL: "/system/bin/sh",
    TERM: "xterm-256color",
    NO_COLOR: "1"
  };
  if (id2 === "claude") {
    const tok = getSecret("sub:claude:token");
    if (tok) env.CLAUDE_CODE_OAUTH_TOKEN = tok;
    env.DISABLE_AUTOUPDATER = "1";
  }
  if (id2 === "gemini") {
    env.NO_BROWSER = "true";
    env.GEMINI_CLI_NO_RELAUNCH = "true";
  }
  return env;
}
function programCommand(id2, args) {
  if (id2 === "chatgpt") return [bin("codex"), args];
  if (id2 === "claude") return [bin("claude"), args];
  return [bin("bun"), [import_node_path4.default.join(root(), "gemini", "bundle", "gemini.js"), ...args]];
}
function writeGeminiSettings(mcp2) {
  const dir = import_node_path4.default.join(subHome("gemini"), ".gemini");
  import_node_fs4.default.mkdirSync(dir, { recursive: true });
  const s = {
    security: { auth: { selectedType: "oauth-personal" } },
    // Gemini's own shell and file-writing tools stay off on the phone; MausDroid's tools ask before risky actions.
    tools: { exclude: ["run_shell_command", "write_file", "replace"] },
    general: { disableAutoUpdate: true, disableUpdateNag: true },
    privacy: { usageStatisticsEnabled: false }
  };
  if (mcp2) s.mcpServers = { mausdroid: { httpUrl: mcp2.url, headers: { Authorization: `Bearer ${mcp2.token}` }, trust: true } };
  import_node_fs4.default.writeFileSync(import_node_path4.default.join(dir, "settings.json"), JSON.stringify(s, null, 1));
}
async function signIn(id2, openUrl) {
  try {
    await install(id2);
  } catch (e) {
    set(id2, { stage: "error", message: `Couldn't install ${SUBS[id2].program} on this phone: ${errorText(e)}` });
    return;
  }
  sessions.get(id2)?.kill();
  workDir();
  if (id2 === "gemini") writeGeminiSettings();
  const loginArgs = id2 === "chatgpt" ? ["login"] : id2 === "claude" ? ["setup-token"] : ["-p", "Reply with the single word OK."];
  const [cmd, args] = programCommand(id2, loginArgs);
  const native = process.env.MAUSDROID_NATIVE_DIR;
  const usePty = id2 !== "chatgpt" && native;
  const child = usePty ? (0, import_node_child_process.spawn)(import_node_path4.default.join(native, "libtsbridge.so"), ["pty", cmd, ...args], { cwd: workDir(), env: programEnv(id2) }) : (0, import_node_child_process.spawn)(cmd, args, { cwd: workDir(), env: programEnv(id2) });
  sessions.set(id2, child);
  if (usePty) viaPty.add(id2);
  else viaPty.delete(id2);
  set(id2, { stage: "signing-in", message: `Opening the ${SUBS[id2].label} sign-in page\u2026`, loginUrl: void 0, needsCode: false, log: "" });
  let log = "";
  let opened = false;
  const onData = (d) => {
    log = (log + stripAnsi(d.toString("utf8"))).slice(-6e3);
    const compact = log.replace(/\n(?=\S)/g, (m, off) => /[A-Za-z0-9%&=._~:/?#-]$/.test(log.slice(0, off)) ? "" : m);
    const url = compact.match(/https:\/\/[^\s"'<>]+(oauth|authorize|accounts\.google\.com|auth\.openai\.com)[^\s"'<>]*/)?.[0];
    const needsCode = /paste|authorization code|enter.*code/i.test(log) && id2 !== "chatgpt";
    if (id2 === "claude") {
      const tok = compact.match(/sk-ant-oat[0-9A-Za-z_-]{20,}/)?.[0];
      if (tok) void setSecret("sub:claude:token", tok).then(() => set(id2, { stage: "signed-in", message: "Signed in to Claude \u2713", loginUrl: void 0, needsCode: false }));
    }
    set(id2, { log: log.slice(-1500), ...url ? { loginUrl: url } : {}, needsCode });
    if (url && !opened) {
      opened = true;
      set(id2, { message: `Sign in on the ${SUBS[id2].label} page that opened.${needsCode ? " Then paste the code here." : ""}` });
      void openUrl(url).catch(() => {
      });
    }
  };
  child.stdout?.on("data", onData);
  child.stderr?.on("data", onData);
  child.on("error", (e) => set(id2, { stage: "error", message: `${SUBS[id2].program} couldn't start on this phone (${e.message}). Use "My computer" instead.` }));
  child.on("close", (code) => {
    sessions.delete(id2);
    if (isSignedIn(id2)) set(id2, { stage: "signed-in", message: `Signed in to ${SUBS[id2].label} \u2713`, loginUrl: void 0, needsCode: false });
    else if (status.get(id2)?.stage === "signing-in") set(id2, { stage: "error", message: `Sign-in didn't finish (exit ${code}). Try again.`, log: log.slice(-1500) });
  });
}
function sendCode(id2, code) {
  const c = sessions.get(id2);
  if (!c?.stdin) throw new Error("No sign-in is waiting for a code. Tap Sign in again.");
  c.stdin.write(`${code.trim()}${viaPty.has(id2) ? "\r" : "\n"}`);
  set(id2, { message: "Checking the code\u2026", needsCode: false });
}
function cancelSignIn(id2) {
  sessions.get(id2)?.kill();
  sessions.delete(id2);
  set(id2, { stage: installed(id2) ? "installed" : "not-installed", message: void 0, loginUrl: void 0, needsCode: false });
}
async function signOut(id2) {
  cancelSignIn(id2);
  if (id2 === "claude") await setSecret("sub:claude:token", null);
  if (id2 === "chatgpt") import_node_fs4.default.rmSync(import_node_path4.default.join(subHome("chatgpt"), ".codex", "auth.json"), { force: true });
  if (id2 === "gemini") import_node_fs4.default.rmSync(import_node_path4.default.join(subHome("gemini"), ".gemini", "oauth_creds.json"), { force: true });
  set(id2, { stage: installed(id2) ? "installed" : "not-installed", message: "Signed out." });
}
async function uninstall(id2) {
  await signOut(id2);
  for (const f of id2 === "chatgpt" ? ["codex", "codex-code-mode-host"] : id2 === "claude" ? ["claude"] : ["bun"]) import_node_fs4.default.rmSync(bin(f), { force: true });
  if (id2 === "gemini") import_node_fs4.default.rmSync(import_node_path4.default.join(root(), "gemini"), { recursive: true, force: true });
  set(id2, { stage: "not-installed", message: "Removed from this phone." });
}
var import_node_child_process, import_node_crypto3, import_node_fs4, import_node_path4, import_node_tls, SUBS, status, root, bin, lib, subHome, workDir, signedInListeners, onSignedIn, installed, hasMusl, allSubs, progress, certFile, sessions, viaPty, stripAnsi;
var init_subscriptions = __esm({
  "src/subscriptions.ts"() {
    "use strict";
    import_node_child_process = require("node:child_process");
    import_node_crypto3 = __toESM(require("node:crypto"), 1);
    import_node_fs4 = __toESM(require("node:fs"), 1);
    import_node_path4 = __toESM(require("node:path"), 1);
    import_node_tls = __toESM(require("node:tls"), 1);
    init_config();
    init_store();
    init_events();
    init_secrets();
    init_archive();
    init_util();
    SUBS = {
      claude: { label: "Claude", program: "Claude Code", company: "Anthropic" },
      chatgpt: { label: "ChatGPT", program: "Codex", company: "OpenAI" },
      gemini: { label: "Gemini", program: "Gemini CLI", company: "Google" }
    };
    status = /* @__PURE__ */ new Map();
    root = () => import_node_path4.default.dirname(dataPath("subs", ".keep"));
    bin = (...p) => import_node_path4.default.join(root(), "bin", ...p);
    lib = () => import_node_path4.default.join(root(), "lib");
    subHome = (id2) => {
      const h = import_node_path4.default.join(root(), "home", id2);
      import_node_fs4.default.mkdirSync(h, { recursive: true });
      return h;
    };
    workDir = () => {
      const w = import_node_path4.default.join(root(), "work");
      import_node_fs4.default.mkdirSync(w, { recursive: true });
      const link = import_node_path4.default.join(w, ".mausld");
      const target = import_node_path4.default.join(lib(), "ld-musl-aarch64.so.1");
      if (import_node_fs4.default.existsSync(target) && !import_node_fs4.default.existsSync(link)) import_node_fs4.default.symlinkSync(target, link);
      return w;
    };
    signedInListeners = [];
    onSignedIn = (fn) => signedInListeners.push(fn);
    installed = (id2) => id2 === "chatgpt" ? import_node_fs4.default.existsSync(bin("codex")) : id2 === "claude" ? import_node_fs4.default.existsSync(bin("claude")) && hasMusl() : import_node_fs4.default.existsSync(bin("bun")) && import_node_fs4.default.existsSync(import_node_path4.default.join(root(), "gemini", "bundle", "gemini.js")) && hasMusl();
    hasMusl = () => import_node_fs4.default.existsSync(import_node_path4.default.join(lib(), "ld-musl-aarch64.so.1"));
    allSubs = () => Object.keys(SUBS).map((id2) => ({ ...subStatus(id2), ...SUBS[id2] }));
    progress = (id2, what) => (done, total) => {
      const pct = total ? Math.round(done / total * 100) : void 0;
      const s = status.get(id2);
      if (pct !== void 0 && s?.progress === pct) return;
      set(id2, { progress: pct, message: `Downloading ${what}\u2026 ${pct !== void 0 ? `${pct}%` : `${Math.round(done / 1e6)} MB`}` });
    };
    certFile = null;
    sessions = /* @__PURE__ */ new Map();
    viaPty = /* @__PURE__ */ new Set();
    stripAnsi = (s) => s.replace(/\x1b\[[0-9;?]*[ -/]*[@-~]/g, "").replace(/\x1b\][^\x07]*\x07/g, "").replace(/\r/g, "\n");
  }
});

// src/providers/cli.ts
function cliArgs(run) {
  if (run.engine === "claude") {
    const mcp2 = JSON.stringify({ mcpServers: { mausdroid: { type: "http", url: run.mcpUrl, headers: { authorization: `Bearer ${run.mcpToken}` } } } });
    const args2 = [
      "-p",
      run.prompt,
      "--output-format",
      "stream-json",
      "--verbose",
      "--mcp-config",
      mcp2,
      "--permission-prompt-tool",
      "mcp__mausdroid__approval_prompt",
      "--append-system-prompt",
      run.systemPrompt
    ];
    if (run.model && run.model !== "default") args2.push("--model", run.model);
    if (run.resume) args2.push("--resume", run.resume);
    return args2;
  }
  if (run.engine === "codex") {
    const base = [
      "exec",
      "--json",
      "--skip-git-repo-check",
      "-c",
      `mcp_servers.mausdroid.url="${run.mcpUrl}"`,
      "-c",
      `mcp_servers.mausdroid.bearer_token="${run.mcpToken}"`
    ];
    if (run.model && run.model !== "default") base.push("-m", run.model);
    return run.resume ? ["exec", "resume", run.resume, ...base.slice(1), run.prompt] : [...base, `${run.systemPrompt}

${run.prompt}`];
  }
  const args = ["-p", `${run.systemPrompt}

${run.prompt}`, "--output-format", "stream-json", "--yolo"];
  if (run.model && run.model !== "default") args.push("-m", run.model);
  return args;
}
function parseCliLine(engine, line, acc) {
  let ev;
  try {
    ev = JSON.parse(line);
  } catch {
    return [];
  }
  const out = [];
  if (engine === "claude") {
    if (ev.type === "system" && ev.session_id) out.push({ kind: "session", sessionId: ev.session_id });
    if (ev.type === "assistant")
      for (const b of ev.message?.content ?? []) {
        if (b.type === "text") out.push({ kind: "text", text: b.text });
        if (b.type === "tool_use") out.push({ kind: "tool", name: b.name, input: b.input });
      }
    if (ev.type === "user") {
      for (const b of ev.message?.content ?? [])
        if (b.type === "tool_result") out.push({ kind: "tool_result", text: typeof b.content === "string" ? b.content : JSON.stringify(b.content).slice(0, 2e3) });
    }
    if (ev.type === "result") {
      if (ev.session_id) out.push({ kind: "session", sessionId: ev.session_id });
      out.push(ev.is_error ? { kind: "error", text: ev.result ?? "Claude reported an error" } : { kind: "done" });
    }
  } else if (engine === "codex") {
    if (ev.type === "thread.started") out.push({ kind: "session", sessionId: ev.thread_id });
    if (ev.type === "item.completed") {
      const it = ev.item ?? {};
      if (it.type === "agent_message") out.push({ kind: "text", text: it.text });
      else if (it.type === "command_execution") out.push({ kind: "tool", name: "shell", input: { command: it.command } }, { kind: "tool_result", text: String(it.aggregated_output ?? "").slice(0, 2e3) });
      else if (it.type === "mcp_tool_call") out.push({ kind: "tool", name: it.tool, input: it.arguments });
    }
    if (ev.type === "turn.completed") out.push({ kind: "done" });
    if (ev.type === "turn.failed" || ev.type === "error") out.push({ kind: "error", text: ev.error?.message ?? ev.message ?? "ChatGPT (Codex) error" });
  } else {
    const flush = () => {
      if (acc.text.trim()) out.push({ kind: "text", text: acc.text.trim() });
      acc.text = "";
    };
    if (ev.type === "init" && ev.session_id) out.push({ kind: "session", sessionId: ev.session_id });
    if (ev.type === "message" && ev.role === "assistant") acc.text += ev.content ?? "";
    if (ev.type === "tool_use") {
      flush();
      out.push({ kind: "tool", name: String(ev.tool_name ?? ev.name ?? "tool").replace(/^mcp_mausdroid_/, ""), input: ev.parameters ?? ev.args });
    }
    if (ev.type === "tool_result") out.push({ kind: "tool_result", text: String(ev.output ?? ev.result ?? "").slice(0, 2e3) });
    if (ev.type === "error") out.push({ kind: "error", text: ev.message ?? "Gemini error" });
    if (ev.type === "result") {
      flush();
      out.push(ev.status === "error" ? { kind: "error", text: ev.error?.message ?? "Gemini reported an error" } : { kind: "done" });
    }
  }
  return out;
}
async function* lines(stream) {
  for await (const l of stream) yield l;
}
async function* runOnComputer(p, run, signal) {
  const res = await fetch(`${p.computerUrl.replace(/\/$/, "")}/run`, {
    method: "POST",
    signal,
    headers: { "content-type": "application/json", authorization: `Bearer ${getSecret(`computer:${p.id}`) ?? ""}` },
    body: JSON.stringify(run)
  });
  if (!res.ok || !res.body) throw new Error(`Your computer said: HTTP ${res.status} ${await res.text()}`);
  const reader = res.body.getReader();
  const dec = new import_node_string_decoder2.StringDecoder("utf8");
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.write(Buffer.from(value));
    let i;
    while ((i = buf.indexOf("\n")) >= 0) {
      yield buf.slice(0, i);
      buf = buf.slice(i + 1);
    }
  }
  if (buf.trim()) yield buf;
}
async function* runOnPhone(sub, run, signal) {
  if (sub === "gemini") writeGeminiSettings({ url: run.mcpUrl, token: run.mcpToken });
  const [cmd, args] = programCommand(sub, cliArgs(run));
  const child = (0, import_node_child_process2.spawn)(cmd, args, { cwd: workDir(), env: programEnv(sub), stdio: ["ignore", "pipe", "pipe"] });
  signal.addEventListener("abort", () => child.kill("SIGTERM"), { once: true });
  let stderr = "";
  child.stderr.on("data", (d) => stderr = (stderr + d).slice(-4e3));
  const started = new Promise((ok, fail) => {
    child.once("spawn", ok);
    child.once("error", fail);
  });
  await started;
  yield* lines(import_node_readline.default.createInterface({ input: child.stdout }));
  const code = await new Promise((r) => child.exitCode !== null ? r(child.exitCode) : child.on("close", r));
  if (code !== 0 && !signal.aborted) throw new Error(`${SUBS[sub].program} stopped (code ${code}): ${stderr.slice(-600)}`);
}
async function* runCli(p, run, signal) {
  const sub = p.subId;
  const full = { ...run, engine: engineFor(sub) };
  const acc = { text: "" };
  const canComputer = Boolean(p.computerUrl);
  const phoneReady = p.runOn !== "computer" && isSignedIn(sub);
  if (!phoneReady && !canComputer) {
    throw new Error(`Sign in to ${SUBS[sub].label} first: Settings \u2192 AI \u2192 ${SUBS[sub].label} \u2192 Sign in.`);
  }
  let source;
  if (phoneReady) {
    try {
      source = runOnPhone(sub, full, signal);
      const first = await source.next();
      if (!first.done) for (const e of parseCliLine(full.engine, first.value, acc)) yield e;
    } catch (e) {
      if (!canComputer) throw e;
      yield { kind: "tool", name: "switching to your computer", input: { reason: String(e.message).slice(0, 200) } };
      source = runOnComputer(p, full, signal);
    }
  } else source = runOnComputer(p, full, signal);
  for await (const line of source) for (const e of parseCliLine(full.engine, line, acc)) yield e;
  if (acc.text.trim()) yield { kind: "text", text: acc.text.trim() };
}
var import_node_child_process2, import_node_readline, import_node_string_decoder2, engineFor;
var init_cli = __esm({
  "src/providers/cli.ts"() {
    "use strict";
    import_node_child_process2 = require("node:child_process");
    import_node_readline = __toESM(require("node:readline"), 1);
    import_node_string_decoder2 = require("node:string_decoder");
    init_secrets();
    init_subscriptions();
    engineFor = (sub) => sub === "chatgpt" ? "codex" : sub;
  }
});

// src/tools/web.ts
async function webFetch(url) {
  const u = new URL(url);
  if (!/^https?:$/.test(u.protocol)) throw new Error("Only http and https links can be fetched.");
  const res = await fetch(u, {
    headers: { "user-agent": "Mozilla/5.0 (Linux; Android 15) MausDroid/0.1", accept: "text/html,application/json,text/plain;q=0.9,*/*;q=0.5" },
    redirect: "follow",
    signal: AbortSignal.timeout(3e4)
  });
  const type = res.headers.get("content-type") ?? "";
  const body = await res.text();
  const text = type.includes("html") ? htmlToText(body) : body;
  return clip(`HTTP ${res.status} ${res.url}

${text}`);
}
async function webSearch(query) {
  const res = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`, {
    headers: { "user-agent": "Mozilla/5.0 (Linux; Android 15) MausDroid/0.1" },
    signal: AbortSignal.timeout(2e4)
  });
  const html = await res.text();
  const results = [];
  const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>)?/g;
  let m;
  while ((m = re.exec(html)) && results.length < 10) {
    let link = m[1];
    const uddg = link.match(/uddg=([^&]+)/);
    if (uddg) link = decodeURIComponent(uddg[1]);
    results.push(`${results.length + 1}. ${htmlToText(m[2])}
   ${link}
   ${htmlToText(m[3] ?? "")}`);
  }
  return results.length ? results.join("\n\n") : "No results (the search page may have changed; try the browser tool).";
}
function tailnetFetch(url, method = "GET", body, headers2 = {}) {
  const [phost, pport] = config.tailnetProxy.split(":");
  const u = new URL(url);
  return new Promise((resolve, reject) => {
    const done = (res) => {
      let data = "";
      res.setEncoding("utf8");
      res.on("data", (c) => data += c);
      res.on("end", () => resolve(clip(`HTTP ${res.statusCode}

${data}`)));
    };
    if (u.protocol === "http:") {
      const req = import_node_http2.default.request({ host: phost, port: Number(pport), method, path: url, headers: { host: u.host, ...headers2 } }, done);
      req.on("error", (e) => reject(new Error(`Tailnet: ${e.message} (is Tailscale on? Settings \u2192 Tailscale)`)));
      req.setTimeout(3e4, () => req.destroy(new Error("timed out")));
      if (body) req.write(body);
      req.end();
      return;
    }
    const connect = import_node_http2.default.request({ host: phost, port: Number(pport), method: "CONNECT", path: `${u.hostname}:${u.port || 443}` });
    connect.on("connect", (_res, socket) => {
      const tlsSock = import_node_tls2.default.connect({ socket, servername: u.hostname });
      const req = import_node_https2.default.request({ createConnection: () => tlsSock, method, path: u.pathname + u.search, headers: { host: u.host, ...headers2 } }, done);
      req.on("error", reject);
      if (body) req.write(body);
      req.end();
    });
    connect.on("error", (e) => reject(new Error(`Tailnet: ${e.message}`)));
    connect.end();
  });
}
var import_node_http2, import_node_https2, import_node_tls2;
var init_web = __esm({
  "src/tools/web.ts"() {
    "use strict";
    import_node_http2 = __toESM(require("node:http"), 1);
    import_node_https2 = __toESM(require("node:https"), 1);
    import_node_tls2 = __toESM(require("node:tls"), 1);
    init_config();
    init_util();
  }
});

// src/notify.ts
function inQuietHours() {
  const q = settings().quietHours;
  if (!q) return false;
  const t = localParts(/* @__PURE__ */ new Date()).hm;
  return q.start <= q.end ? t >= q.start && t < q.end : t >= q.start || t < q.end;
}
async function notifyUser(a) {
  const alert = { id: id("alert"), title: a.title, body: a.body, botId: a.botId, cardId: a.cardId, priority: a.priority ?? "normal", at: now(), read: false };
  alerts.update((l) => {
    l.push(alert);
    if (l.length > 500) l.splice(0, l.length - 500);
  });
  emit("alert", { alert });
  if (inQuietHours() && alert.priority !== "high") return alert;
  if (bridgeAvailable()) {
    await bridge("/notify", { ...a, id: alert.id, silent: alert.priority === "low" }).catch(() => {
    });
  }
  return alert;
}
function markAlertsRead() {
  alerts.update((l) => l.forEach((x) => x.read = true));
}
var alerts, listAlerts;
var init_notify = __esm({
  "src/notify.ts"() {
    "use strict";
    init_bridge();
    init_events();
    init_store();
    init_util();
    init_settings();
    init_time();
    alerts = collection("alerts", []);
    listAlerts = () => alerts.get().slice().reverse();
  }
});

// src/approvals.ts
function pendingCards() {
  return [...pending.values()].map(({ resolve, ...rest }) => rest);
}
function requestApproval(botId, tool, title, detail, signal) {
  const bot = getBot(botId);
  if (bot?.alwaysAllow.includes(tool)) return Promise.resolve({ allow: true });
  return open({ kind: "approval", botId, tool, title, detail }, signal);
}
function askQuestion(botId, question, options, signal) {
  return open({ kind: "question", botId, title: question, detail: "", options }, signal);
}
function open(p, signal) {
  return new Promise((resolve) => {
    const card = { ...p, id: id("card"), createdAt: (/* @__PURE__ */ new Date()).toISOString(), resolve };
    pending.set(card.id, card);
    const { resolve: _r, ...pub } = card;
    emit("card", { card: pub });
    const bot = getBot(p.botId);
    void notifyUser({
      title: `${bot?.emoji ?? "\u{1F916}"} ${bot?.name ?? "Bot"} ${p.kind === "approval" ? "needs your OK" : "has a question"}`,
      body: p.kind === "approval" ? `${p.title}
${p.detail}`.slice(0, 300) : p.title,
      botId: p.botId,
      cardId: card.id,
      actions: p.kind === "approval" ? ["Allow", "Deny"] : void 0,
      priority: "high"
    });
    signal?.addEventListener("abort", () => settle(card.id, { allow: false, answer: "(stopped)" }), { once: true });
  });
}
function settle(cardId, r) {
  const card = pending.get(cardId);
  if (!card) return false;
  pending.delete(cardId);
  if (r.always && card.tool) {
    const bot = getBot(card.botId);
    if (bot && !bot.alwaysAllow.includes(card.tool)) updateBot(bot.id, { alwaysAllow: [...bot.alwaysAllow, card.tool] });
  }
  emit("card.settled", { cardId, allow: r.allow, answer: r.answer });
  card.resolve(r);
  return true;
}
var pending;
var init_approvals = __esm({
  "src/approvals.ts"() {
    "use strict";
    init_events();
    init_util();
    init_bots();
    init_notify();
    pending = /* @__PURE__ */ new Map();
  }
});

// src/memory.ts
function readMemory(scope) {
  try {
    return import_node_fs5.default.readFileSync(file2(scope), "utf8");
  } catch {
    return "";
  }
}
function appendMemory(scope, note) {
  const line = `- ${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}: ${note.replace(/\n+/g, " ").trim()}
`;
  import_node_fs5.default.appendFileSync(file2(scope), line);
}
function writeMemory(scope, text) {
  import_node_fs5.default.writeFileSync(file2(scope), text);
}
var import_node_fs5, file2;
var init_memory = __esm({
  "src/memory.ts"() {
    "use strict";
    import_node_fs5 = __toESM(require("node:fs"), 1);
    init_store();
    file2 = (scope) => dataPath("memory", `${scope.replace(/[^a-zA-Z0-9_-]/g, "")}.md`);
  }
});

// src/routines.ts
function nextRun(s, from) {
  if (s.kind === "once") {
    const t = s.at ? new Date(s.at) : null;
    return t && t > from ? t : null;
  }
  if (s.kind === "interval") return new Date(from.getTime() + Math.max(15, s.minutes ?? 60) * 6e4);
  const start = new Date(Math.floor(from.getTime() / 6e4) * 6e4 + 6e4);
  for (let i = 0; i < 8 * 24 * 60; i++) {
    const d = new Date(start.getTime() + i * 6e4);
    const p = localParts2(d);
    if (p.hm !== s.time) continue;
    if (s.kind === "weekly" && !(s.days ?? []).includes(p.wd)) continue;
    return d;
  }
  return null;
}
function listRoutines(botId) {
  return file3.get().filter((r) => !botId || r.botId === botId);
}
function createRoutine(r) {
  const routine = { ...r, id: id("rt"), createdAt: now(), enabled: r.enabled ?? true };
  routine.nextRunAt = nextRun(routine.schedule, /* @__PURE__ */ new Date())?.toISOString();
  file3.update((l) => void l.push(routine));
  emit("routines.changed", {});
  return routine;
}
function updateRoutine(rid, patch) {
  file3.update((l) => {
    const r = l.find((x) => x.id === rid);
    if (!r) throw new Error("No such routine");
    Object.assign(r, patch);
    r.nextRunAt = nextRun(r.schedule, /* @__PURE__ */ new Date())?.toISOString();
  });
  emit("routines.changed", {});
}
function deleteRoutine(rid) {
  file3.update((l) => {
    const i = l.findIndex((x) => x.id === rid);
    if (i >= 0) l.splice(i, 1);
  });
  emit("routines.changed", {});
}
function dueRoutines(at = /* @__PURE__ */ new Date()) {
  const due = [];
  file3.update((l) => {
    for (const r of l) {
      if (!r.enabled || !r.nextRunAt) continue;
      if (new Date(r.nextRunAt) <= at) {
        due.push({ ...r });
        r.lastRunAt = at.toISOString();
        r.nextRunAt = nextRun(r.schedule, at)?.toISOString();
        if (!r.nextRunAt && r.schedule.kind === "once") r.enabled = false;
      }
    }
  });
  return due;
}
var file3, localParts2;
var init_routines = __esm({
  "src/routines.ts"() {
    "use strict";
    init_store();
    init_util();
    init_events();
    init_time();
    file3 = collection("routines", []);
    localParts2 = (d) => localParts(d);
  }
});

// src/skills.ts
function ghHeaders() {
  const h = { "user-agent": "MausDroid-skills", accept: "application/vnd.github+json" };
  const t = getSecret("github");
  if (t) h.authorization = `Bearer ${t}`;
  return h;
}
function parseFrontmatter(md) {
  const m = md.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!m) return { body: md };
  const meta = {};
  for (const line of m[1].split(/\r?\n/)) {
    const kv = line.match(/^([A-Za-z_-]+):\s*(.*)$/);
    if (kv) meta[kv[1]] = kv[2].replace(/^["']|["']$/g, "").trim();
  }
  return { name: meta.name, description: meta.description, body: m[2] };
}
function listSkills() {
  const out = [];
  if (!import_node_fs6.default.existsSync(root2())) return out;
  for (const d of import_node_fs6.default.readdirSync(root2())) {
    const file4 = import_node_path5.default.join(root2(), d, "SKILL.md");
    if (!import_node_fs6.default.existsSync(file4)) continue;
    const fm = parseFrontmatter(import_node_fs6.default.readFileSync(file4, "utf8"));
    let source;
    try {
      source = JSON.parse(import_node_fs6.default.readFileSync(import_node_path5.default.join(root2(), d, ".source.json"), "utf8")).source;
    } catch {
    }
    out.push({ name: fm.name ?? d, description: fm.description ?? "", source, dir: import_node_path5.default.join(root2(), d) });
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}
function readSkill(name) {
  const s = listSkills().find((x) => x.name === name);
  if (!s) throw new Error(`No skill called ${name}`);
  const md = import_node_fs6.default.readFileSync(import_node_path5.default.join(s.dir, "SKILL.md"), "utf8");
  const extra = import_node_fs6.default.readdirSync(s.dir, { recursive: true }).map(String).filter((f) => f !== "SKILL.md" && !f.startsWith("."));
  return `${md}

[Other files in this skill: ${extra.join(", ") || "none"}. Ask with skill_read using file= to open one.]`;
}
function readSkillFile(name, file4) {
  const s = listSkills().find((x) => x.name === name);
  if (!s) throw new Error(`No skill called ${name}`);
  const p = import_node_path5.default.resolve(s.dir, file4);
  if (!p.startsWith(s.dir + import_node_path5.default.sep)) throw new Error("That file is outside the skill folder.");
  return import_node_fs6.default.readFileSync(p, "utf8");
}
function saveSkill(name, md) {
  const safe = name.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-|-$/g, "") || "skill";
  const dir = import_node_path5.default.join(root2(), safe);
  import_node_fs6.default.mkdirSync(dir, { recursive: true });
  import_node_fs6.default.writeFileSync(import_node_path5.default.join(dir, "SKILL.md"), md);
  return safe;
}
function removeSkill(name) {
  const s = listSkills().find((x) => x.name === name);
  if (s) import_node_fs6.default.rmSync(s.dir, { recursive: true, force: true });
}
async function searchMarketplace(q) {
  const query = `${q ? `${q} ` : ""}topic:claude-skills OR topic:agent-skills OR topic:claude-code-skills`;
  const res = await fetch(`${API2}/search/repositories?q=${encodeURIComponent(query)}&sort=stars&per_page=30`, { headers: ghHeaders() });
  if (!res.ok) throw new Error(`GitHub search: HTTP ${res.status}${res.status === 403 ? " (rate limit: add a GitHub token in Settings)" : ""}`);
  const j = await res.json();
  const featured = [{ full_name: "anthropics/skills", description: "Anthropic's official example skills", stargazers_count: null, html_url: "https://github.com/anthropics/skills" }];
  return [...featured, ...j.items ?? []].map((r) => ({ repo: r.full_name, description: r.description, stars: r.stargazers_count, url: r.html_url }));
}
function parseRepoRef(ref) {
  const m = ref.trim().replace(/^https:\/\/github\.com\//, "").replace(/\.git$/, "").match(/^([^/]+)\/([^/]+)(?:\/tree\/([^/]+))?(?:\/(.*))?$/);
  if (!m) throw new Error("Use owner/repo or a github.com link.");
  return { owner: m[1], repo: m[2], branch: m[3], sub: (m[4] ?? "").replace(/\/$/, "") };
}
async function listRepoSkills(ref) {
  const { owner, repo, branch, sub } = parseRepoRef(ref);
  let ref2 = branch;
  if (!ref2) {
    const r = await fetch(`${API2}/repos/${owner}/${repo}`, { headers: ghHeaders() });
    if (!r.ok) throw new Error(`GitHub: HTTP ${r.status}`);
    ref2 = (await r.json()).default_branch;
  }
  const t = await fetch(`${API2}/repos/${owner}/${repo}/git/trees/${ref2}?recursive=1`, { headers: ghHeaders() });
  if (!t.ok) throw new Error(`GitHub: HTTP ${t.status}`);
  const tree = (await t.json()).tree;
  const dirs = tree.filter((e) => e.type === "blob" && /(^|\/)SKILL\.md$/.test(e.path) && (!sub || e.path.startsWith(sub))).map((e) => import_node_path5.default.posix.dirname(e.path));
  return { owner, repo, branch: ref2, tree, dirs };
}
async function installFromGitHub(ref, only) {
  const { owner, repo, branch, tree, dirs } = await listRepoSkills(ref);
  const chosen = only?.length ? dirs.filter((d) => only.includes(d) || only.includes(import_node_path5.default.posix.basename(d))) : dirs;
  if (!chosen.length) throw new Error("No SKILL.md found there.");
  if (chosen.length > 40) throw new Error(`That repo has ${chosen.length} skills \u2014 pick specific ones.`);
  const installed2 = [];
  for (const d of chosen) {
    const files2 = tree.filter((e) => e.type === "blob" && (d === "." ? !e.path.includes("/") || e.path === "SKILL.md" : e.path.startsWith(d + "/")) && (e.size ?? 0) < 1e6);
    if (files2.length > 200) continue;
    const skillMd = await (await fetch(`https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${d === "." ? "" : d + "/"}SKILL.md`)).text();
    const fm = parseFrontmatter(skillMd);
    const name = saveSkill(fm.name ?? import_node_path5.default.posix.basename(d === "." ? repo : d), skillMd);
    const dir = import_node_path5.default.join(root2(), name);
    for (const f of files2) {
      const rel = d === "." ? f.path : f.path.slice(d.length + 1);
      if (rel === "SKILL.md") continue;
      const res = await fetch(`https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${f.path}`);
      if (!res.ok) continue;
      const target = import_node_path5.default.join(dir, rel);
      import_node_fs6.default.mkdirSync(import_node_path5.default.dirname(target), { recursive: true });
      import_node_fs6.default.writeFileSync(target, Buffer.from(await res.arrayBuffer()));
    }
    import_node_fs6.default.writeFileSync(import_node_path5.default.join(dir, ".source.json"), JSON.stringify({ source: `github.com/${owner}/${repo}/${d}`, branch }));
    installed2.push(name);
  }
  return installed2;
}
var import_node_fs6, import_node_path5, root2, API2;
var init_skills = __esm({
  "src/skills.ts"() {
    "use strict";
    import_node_fs6 = __toESM(require("node:fs"), 1);
    import_node_path5 = __toESM(require("node:path"), 1);
    init_store();
    init_secrets();
    root2 = () => import_node_path5.default.dirname(dataPath("skills", ".keep"));
    API2 = "https://api.github.com";
  }
});

// src/mcp.ts
var McpClient;
var init_mcp = __esm({
  "src/mcp.ts"() {
    "use strict";
    init_sse();
    McpClient = class {
      constructor(url, headers2 = {}) {
        this.url = url;
        this.headers = headers2;
      }
      sessionId = null;
      nextId = 1;
      initialized = false;
      async rpc(method, params, notify = false) {
        const body = { jsonrpc: "2.0", method, params };
        if (!notify) body.id = this.nextId++;
        const h = {
          "content-type": "application/json",
          accept: "application/json, text/event-stream",
          ...this.headers
        };
        if (this.sessionId) h["mcp-session-id"] = this.sessionId;
        const res = await fetch(this.url, { method: "POST", headers: h, body: JSON.stringify(body), signal: AbortSignal.timeout(18e4) });
        const sid = res.headers.get("mcp-session-id");
        if (sid) this.sessionId = sid;
        if (notify) return null;
        if (!res.ok) throw new Error(`MCP ${method}: HTTP ${res.status} ${(await res.text()).slice(0, 300)}`);
        let msg;
        if ((res.headers.get("content-type") ?? "").includes("text/event-stream")) {
          for await (const { data } of readSSE(res)) {
            const m = JSON.parse(data);
            if (m.id === body.id) {
              msg = m;
              break;
            }
          }
        } else msg = await res.json();
        if (msg?.error) throw new Error(`MCP ${method}: ${msg.error.message}`);
        return msg?.result;
      }
      async init() {
        if (this.initialized) return;
        await this.rpc("initialize", {
          protocolVersion: "2025-06-18",
          capabilities: {},
          clientInfo: { name: "MausDroid", version: "0.1" }
        });
        await this.rpc("notifications/initialized", void 0, true);
        this.initialized = true;
      }
      async listTools() {
        await this.init();
        const out = [];
        let cursor;
        do {
          const r = await this.rpc("tools/list", cursor ? { cursor } : {});
          for (const t of r.tools ?? []) out.push({ name: t.name, description: t.description ?? "", inputSchema: t.inputSchema ?? { type: "object" } });
          cursor = r.nextCursor;
        } while (cursor);
        return out;
      }
      async callTool(name, args) {
        await this.init();
        const r = await this.rpc("tools/call", { name, arguments: args ?? {} });
        const parts = [];
        const images = [];
        for (const c of r.content ?? []) {
          if (c.type === "text") parts.push(c.text);
          else if (c.type === "image") images.push({ mediaType: c.mimeType, data: c.data });
          else parts.push(JSON.stringify(c));
        }
        if (r.structuredContent && !parts.length) parts.push(JSON.stringify(r.structuredContent));
        return { text: parts.join("\n"), isError: Boolean(r.isError), images };
      }
    };
  }
});

// src/composio.ts
async function responseError(res) {
  const t = await res.text();
  try {
    const j = JSON.parse(t);
    return j.error?.message ?? j.message ?? t.slice(0, 300);
  } catch {
    return t.slice(0, 300);
  }
}
async function createSession(key2, userId) {
  const res = await fetch(`${API3}/tool_router/session`, {
    method: "POST",
    headers: headers(key2, true),
    body: JSON.stringify({
      user_id: userId,
      manage_connections: { enable: true, enable_wait_for_connections: true, enable_connection_removal: true },
      multi_account: { enable: true, max_accounts_per_toolkit: 10, require_explicit_selection: true }
    }),
    signal: AbortSignal.timeout(3e4)
  });
  if (!res.ok) throw new Error(`Composio refused this key: ${await responseError(res)}`);
  const j = await res.json();
  const u = new URL(j.mcp.url);
  if (u.protocol !== "https:" || !(u.hostname === "composio.dev" || u.hostname.endsWith(".composio.dev")))
    throw new Error("Composio returned an untrusted MCP address");
  return j;
}
async function connectComposio(key2) {
  key2 = key2.trim();
  if (!key2.startsWith("ak_")) throw new Error("Composio project API keys start with ak_ (from the project's API Keys page).");
  const userId = settings().composio.userId ?? `mausdroid_${(0, import_node_crypto4.randomUUID)()}`;
  const s = await createSession(key2, userId);
  await setSecret("composio", key2);
  updateSettings((st) => {
    st.composio = { userId, sessionId: s.session_id, mcpUrl: s.mcp.url };
  });
  client = null;
  tools = null;
}
async function disconnectComposio() {
  await setSecret("composio", null);
  updateSettings((st) => {
    st.composio = { userId: st.composio.userId };
  });
  client = null;
  tools = null;
}
function mcp() {
  const key2 = getSecret("composio");
  const url = settings().composio.mcpUrl;
  if (!key2 || !url) return null;
  client ??= new McpClient(url, headers(key2));
  return client;
}
async function composioTools() {
  const c = mcp();
  if (!c) return [];
  if (!tools) {
    try {
      tools = (await c.listTools()).map((t) => ({ ...t, name: `composio__${t.name}` }));
    } catch (e) {
      const key2 = getSecret("composio");
      const s = await createSession(key2, settings().composio.userId);
      updateSettings((st) => {
        st.composio.sessionId = s.session_id;
        st.composio.mcpUrl = s.mcp.url;
      });
      client = new McpClient(s.mcp.url, headers(key2));
      tools = (await client.listTools()).map((t) => ({ ...t, name: `composio__${t.name}` }));
    }
  }
  return tools;
}
async function callComposio(name, args) {
  const c = mcp();
  if (!c) throw new Error("Composio is not connected. Add your project key in Settings \u2192 Connected apps.");
  return c.callTool(name.replace(/^composio__/, ""), args);
}
async function listToolkits(search = "", cursor) {
  const key2 = getSecret("composio");
  if (!key2) throw new Error("Add your Composio project key first.");
  const q = new URLSearchParams({ limit: "50" });
  if (search) q.set("search", search);
  if (cursor) q.set("cursor", cursor);
  const res = await fetch(`${API3}/toolkits?${q}`, { headers: headers(key2) });
  if (!res.ok) throw new Error(await responseError(res));
  const j = await res.json();
  return {
    items: (j.items ?? []).map((t) => ({ slug: t.slug, name: t.name, logo: t.meta?.logo, description: t.meta?.description, categories: (t.meta?.categories ?? []).map((c) => c.name ?? c) })),
    nextCursor: j.next_cursor ?? null
  };
}
async function listConnections() {
  const key2 = getSecret("composio");
  const userId = settings().composio.userId;
  if (!key2 || !userId) return [];
  const res = await fetch(`${API3}/connected_accounts?user_ids=${encodeURIComponent(userId)}&limit=100`, { headers: headers(key2) });
  if (!res.ok) throw new Error(await responseError(res));
  const j = await res.json();
  return (j.items ?? []).map((a) => ({ id: a.id, toolkit: a.toolkit?.slug, status: a.status, alias: a.alias ?? a.data?.alias ?? null, createdAt: a.created_at }));
}
async function linkToolkit(toolkit, alias) {
  const key2 = getSecret("composio");
  const st = settings().composio;
  if (!key2 || !st.sessionId) throw new Error("Add your Composio project key first.");
  const res = await fetch(`${API3}/tool_router/session/${encodeURIComponent(st.sessionId)}/link`, {
    method: "POST",
    headers: headers(key2, true),
    body: JSON.stringify({ toolkit, ...alias ? { alias } : {} })
  });
  if (!res.ok) throw new Error(await responseError(res));
  const j = await res.json();
  const url = j.redirect_url ?? j.link ?? j.url;
  if (!url) throw new Error("Composio did not return a sign-in link.");
  return { url };
}
async function removeConnection(id2) {
  const key2 = getSecret("composio");
  if (!key2) throw new Error("Composio is not connected.");
  const res = await fetch(`${API3}/connected_accounts/${encodeURIComponent(id2)}?revoke_on_delete=true`, { method: "DELETE", headers: headers(key2) });
  if (!res.ok) throw new Error(await responseError(res));
  tools = null;
}
var import_node_crypto4, API3, client, tools, headers;
var init_composio = __esm({
  "src/composio.ts"() {
    "use strict";
    import_node_crypto4 = require("node:crypto");
    init_mcp();
    init_secrets();
    init_settings();
    API3 = "https://backend.composio.dev/api/v3";
    client = null;
    tools = null;
    headers = (key2, json2 = false) => ({
      "x-api-key": key2,
      ...json2 ? { "content-type": "application/json" } : {}
    });
  }
});

// src/tools/index.ts
function browserNeeded() {
  if (!bridgeAvailable()) throw new Error("The background browser needs the Android app.");
}
async function toolsFor(bot) {
  const list = builtins.filter((t) => t.group === "core" || bot.tools[t.group]);
  if (bot.tools.apps) {
    try {
      for (const spec of await composioTools())
        list.push({
          group: "apps",
          spec,
          risk: (i) => {
            const n = spec.name.toUpperCase();
            if (n.includes("SEARCH_TOOLS") || n.includes("GET_TOOL_SCHEMAS") || n.includes("MANAGE_CONNECTIONS")) return null;
            if (n.includes("WORKBENCH") || n.includes("BASH")) return "Run code in Composio's cloud workbench";
            const slugs = (i?.tools ?? []).map((t) => String(t.tool_slug ?? ""));
            const writes = slugs.filter((s) => WRITE_WORDS.test(s));
            return writes.length ? `Use connected apps: ${writes.join(", ")}` : null;
          },
          run: async (_c, input) => callComposio(spec.name, input)
        });
    } catch {
    }
  }
  return list;
}
function describeSkills(names) {
  const skills = listSkills().filter((s) => !names.length || names.includes(s.name));
  if (!skills.length) return "";
  return `

# Skills
Open a skill with skill_read before a task it covers:
${skills.map((s) => `- ${s.name}: ${s.description}`).join("\n")}`;
}
function memoryContext(botId) {
  const me = readMemory("about-me").slice(-6e3);
  const mine = readMemory(botId).slice(-4e3);
  return `${me ? `

# What you know about the person
${me}` : ""}${mine ? `

# Your own notes
${mine}` : ""}`;
}
var obj, str, WRITE_WORDS, builtins;
var init_tools = __esm({
  "src/tools/index.ts"() {
    "use strict";
    init_bridge();
    init_web();
    init_notify();
    init_approvals();
    init_memory();
    init_routines();
    init_skills();
    init_composio();
    obj = (props, required = []) => ({ type: "object", properties: props, required });
    str = (description) => ({ type: "string", description });
    WRITE_WORDS = /(SEND|CREATE|DELETE|REMOVE|UPDATE|POST|REPLY|INSERT|ADD|MOVE|PATCH|PUT|UPLOAD|SHARE|INVITE|PAY|PURCHASE|BUY|ARCHIVE|TRASH|MODIFY|SET_|EXECUTE|RUN|SUBMIT|ACCEPT|DECLINE|CANCEL|TRANSFER|FORWARD)/i;
    builtins = [
      {
        group: "web",
        spec: { name: "web_search", description: "Search the web. Returns titles, links and snippets.", inputSchema: obj({ query: str("What to search for") }, ["query"]) },
        run: (_c, i) => webSearch(i.query)
      },
      {
        group: "web",
        spec: { name: "web_fetch", description: "Download a web page or API URL and return its readable text. Fast, but no login and no JavaScript; use the browser tools for those.", inputSchema: obj({ url: str("http(s) URL") }, ["url"]) },
        run: (_c, i) => webFetch(i.url)
      },
      {
        group: "browser",
        spec: {
          name: "browser_open",
          description: "Open a page in the phone's background browser (keeps your logins, runs JavaScript, works while the screen is off). Returns a tab id and the page text.",
          inputSchema: obj({ url: str("URL to open"), tab: str("Existing tab id to reuse (optional)") }, ["url"])
        },
        run: async (_c, i) => {
          browserNeeded();
          const r = await bridge("/browser/open", i, 9e4);
          return `tab=${r.tab}
title=${r.title}
url=${r.url}

${r.text ?? ""}`;
        }
      },
      {
        group: "browser",
        spec: { name: "browser_read", description: "Read the current page of a tab: mode 'text' (default), 'links', or 'forms' (inputs and buttons with selectors).", inputSchema: obj({ tab: str("Tab id"), mode: { type: "string", enum: ["text", "links", "forms"] } }, ["tab"]) },
        run: async (_c, i) => {
          browserNeeded();
          return (await bridge("/browser/read", i)).text;
        }
      },
      {
        group: "browser",
        spec: { name: "browser_click", description: "Click an element by CSS selector, or by its visible text.", inputSchema: obj({ tab: str("Tab id"), selector: str("CSS selector"), text: str("Visible text of the element") }, ["tab"]) },
        risk: (i) => `Click ${i.text ? `"${i.text}"` : i.selector} in the background browser`,
        run: async (_c, i) => {
          browserNeeded();
          const r = await bridge("/browser/click", i, 6e4);
          return `${r.result}
url=${r.url}

${r.text ?? ""}`;
        }
      },
      {
        group: "browser",
        spec: { name: "browser_type", description: "Type into an input (CSS selector). submit=true presses Enter / submits the form.", inputSchema: obj({ tab: str("Tab id"), selector: str("CSS selector of the input"), text: str("Text to type"), submit: { type: "boolean" } }, ["tab", "selector", "text"]) },
        risk: (i) => i.submit ? `Type and submit "${String(i.text).slice(0, 80)}"` : null,
        run: async (_c, i) => {
          browserNeeded();
          const r = await bridge("/browser/type", i, 6e4);
          return `${r.result}
url=${r.url}

${r.text ?? ""}`;
        }
      },
      {
        group: "browser",
        spec: { name: "browser_screenshot", description: "See what a tab looks like (image).", inputSchema: obj({ tab: str("Tab id") }, ["tab"]) },
        run: async (_c, i) => {
          browserNeeded();
          const r = await bridge("/browser/screenshot", i, 6e4);
          return { text: `Screenshot of ${r.url}`, images: [{ mediaType: "image/jpeg", data: r.jpeg }] };
        }
      },
      {
        group: "browser",
        spec: { name: "browser_scroll", description: "Scroll a tab down or up one screen, returns the newly visible text.", inputSchema: obj({ tab: str("Tab id"), direction: { type: "string", enum: ["down", "up"] } }, ["tab"]) },
        run: async (_c, i) => {
          browserNeeded();
          return (await bridge("/browser/scroll", i)).text;
        }
      },
      {
        group: "browser",
        spec: { name: "browser_tabs", description: "List open background browser tabs, or close one (close=tab id).", inputSchema: obj({ close: str("Tab id to close (optional)") }) },
        run: async (_c, i) => {
          browserNeeded();
          if (i.close) await bridge("/browser/close", { tab: i.close });
          return JSON.stringify((await bridge("/browser/tabs")).tabs, null, 1);
        }
      },
      {
        group: "browser",
        spec: { name: "browser_ask_login", description: "When a site needs you (the person) to sign in, show them the page so they can log in themselves. Their login is then remembered for the background browser.", inputSchema: obj({ url: str("Sign-in page"), reason: str("Why") }, ["url"]) },
        run: async (c, i) => {
          browserNeeded();
          await bridge("/login/show", { url: i.url, reason: i.reason, bot: c.bot.name });
          return "The sign-in page is now showing for the person. Ask them to tell you when they've finished, then continue.";
        }
      },
      {
        group: "core",
        spec: { name: "notify_user", description: "Send the person a phone notification (smart alert). Use for things that matter; be brief. priority: low (silent), normal, high (breaks quiet hours).", inputSchema: obj({ title: str("Short title"), body: str("One or two sentences"), priority: { type: "string", enum: ["low", "normal", "high"] } }, ["title", "body"]) },
        run: async (c, i) => {
          await notifyUser({ title: `${c.bot.emoji} ${i.title}`, body: i.body, botId: c.bot.id, priority: i.priority });
          return "Notification sent.";
        }
      },
      {
        group: "core",
        spec: { name: "ask_user", description: "Ask the person a question and wait for the answer. Give options when there are clear choices.", inputSchema: obj({ question: str("The question"), options: { type: "array", items: { type: "string" } } }, ["question"]) },
        run: async (c, i) => {
          const r = await askQuestion(c.bot.id, i.question, i.options, c.signal);
          return r.answer ? `The person answered: ${r.answer}` : "The person did not answer.";
        }
      },
      {
        group: "core",
        spec: { name: "memory_save", description: "Remember a lasting fact or preference. scope 'me' = about the person (shared by all bots), 'bot' = only you.", inputSchema: obj({ note: str("What to remember"), scope: { type: "string", enum: ["me", "bot"] } }, ["note"]) },
        run: async (c, i) => {
          appendMemory(i.scope === "bot" ? c.bot.id : "about-me", i.note);
          return "Saved.";
        }
      },
      {
        group: "core",
        spec: {
          name: "routine_create",
          description: "Repeat a task on a schedule, e.g. a morning briefing, or a watcher that only alerts when a condition is met. Write the prompt as instructions to yourself, including when to call notify_user.",
          inputSchema: obj(
            {
              title: str("Short name"),
              prompt: str("What to do each time"),
              kind: { type: "string", enum: ["once", "interval", "daily", "weekly"] },
              at: str("once: ISO date-time"),
              minutes: { type: "number", description: "interval: minutes between runs (min 15)" },
              time: str("daily/weekly: local time HH:MM"),
              days: { type: "array", items: { type: "number" }, description: "weekly: 0=Sun..6=Sat" }
            },
            ["title", "prompt", "kind"]
          )
        },
        run: async (c, i) => {
          const schedule = { kind: i.kind, at: i.at, minutes: i.minutes, time: i.time, days: i.days };
          const r = createRoutine({ botId: c.bot.id, title: i.title, prompt: i.prompt, schedule });
          return `Routine "${r.title}" created (id ${r.id}). Next run: ${r.nextRunAt ?? "never \u2014 check the schedule"}.`;
        }
      },
      {
        group: "core",
        spec: { name: "routine_list", description: "List your routines, or delete one (delete=id).", inputSchema: obj({ delete: str("Routine id to delete (optional)") }) },
        run: async (c, i) => {
          if (i.delete) deleteRoutine(i.delete);
          return JSON.stringify(listRoutines(c.bot.id).map((r) => ({ id: r.id, title: r.title, schedule: r.schedule, next: r.nextRunAt, enabled: r.enabled })), null, 1);
        }
      },
      {
        group: "core",
        spec: { name: "skill_read", description: "Open an installed skill's instructions (or one of its files) before doing a task it covers.", inputSchema: obj({ name: str("Skill name"), file: str("Optional file inside the skill") }, ["name"]) },
        run: async (_c, i) => i.file ? readSkillFile(i.name, i.file) : readSkill(i.name)
      },
      {
        group: "web",
        spec: { name: "tailnet_fetch", description: "Call a service on the person's private Tailscale network (e.g. their PC at http://my-pc:11434). Works without opening the Tailscale app.", inputSchema: obj({ url: str("URL on the tailnet"), method: str("GET (default), POST\u2026"), body: str("Request body"), content_type: str("Body type") }, ["url"]) },
        risk: (i) => i.method && i.method.toUpperCase() !== "GET" ? `${i.method} ${i.url} on your tailnet` : null,
        run: async (_c, i) => tailnetFetch(i.url, (i.method ?? "GET").toUpperCase(), i.body, i.content_type ? { "content-type": i.content_type } : {})
      }
    ];
  }
});

// src/mcp-server.ts
var mcp_server_exports = {};
__export(mcp_server_exports, {
  handleMcp: () => handleMcp,
  initMcpServer: () => initMcpServer,
  mcpTokenFor: () => mcpTokenFor
});
async function initMcpServer() {
  key = getSecret("mcp:key");
  if (!key) {
    key = (0, import_node_crypto5.randomBytes)(32).toString("hex");
    await setSecret("mcp:key", key);
  }
}
function mcpTokenFor(botId) {
  return (0, import_node_crypto5.createHmac)("sha256", key ?? "unset").update(`mcp:${botId}`).digest("hex");
}
function validToken(botId, header) {
  const got = Buffer.from((header ?? "").replace(/^Bearer /i, ""));
  const want = Buffer.from(mcpTokenFor(botId));
  return got.length === want.length && (0, import_node_crypto5.timingSafeEqual)(got, want);
}
async function handleMcp(botId, req, res, body) {
  const send = (status2, obj2) => {
    res.writeHead(status2, { "content-type": "application/json" });
    res.end(JSON.stringify(obj2));
  };
  if (!validToken(botId, req.headers.authorization)) return send(401, { error: "bad token" });
  const bot = getBot(botId);
  if (!bot) return send(404, { error: "no bot" });
  if (req.method !== "POST") return send(405, { error: "POST only" });
  const reply = (result) => send(200, { jsonrpc: "2.0", id: body.id, result });
  const fail = (message) => send(200, { jsonrpc: "2.0", id: body.id, error: { code: -32e3, message } });
  switch (body.method) {
    case "initialize":
      return reply({ protocolVersion: body.params?.protocolVersion ?? "2025-06-18", capabilities: { tools: {} }, serverInfo: { name: "mausdroid", version: "0.1" } });
    case "notifications/initialized":
    case "notifications/cancelled":
      res.writeHead(202).end();
      return;
    case "ping":
      return reply({});
    case "tools/list": {
      const tools2 = await toolsFor(bot);
      return reply({ tools: [approvalTool, ...tools2.map((t) => t.spec)].map((t) => ({ name: t.name, description: t.description, inputSchema: t.inputSchema })) });
    }
    case "tools/call": {
      const { name, arguments: args } = body.params ?? {};
      if (name === "approval_prompt") {
        const r = await requestApproval(bot.id, String(args?.tool_name), `Computer: ${args?.tool_name}`, clip(JSON.stringify(args?.input ?? {}, null, 1), 1200));
        const decision = r.allow ? { behavior: "allow", updatedInput: args?.input ?? {} } : { behavior: "deny", message: "The person declined." };
        return reply({ content: [{ type: "text", text: JSON.stringify(decision) }] });
      }
      const tool = (await toolsFor(bot)).find((t) => t.spec.name === name);
      if (!tool) return fail(`No tool ${name}`);
      const reason = tool.risk?.(args) ?? null;
      if (bot.approvalMode === "ask-all" || bot.approvalMode === "ask-risky" && reason) {
        const r = await requestApproval(bot.id, name, reason ?? `Use ${name}`, clip(JSON.stringify(args, null, 1), 1200));
        if (!r.allow) return reply({ content: [{ type: "text", text: "The person declined this action." }], isError: true });
      }
      try {
        const out = await tool.run({ bot, signal: AbortSignal.timeout(6e5) }, args ?? {});
        const r = typeof out === "string" ? { text: out } : out;
        return reply({
          content: [{ type: "text", text: clip(r.text) }, ...(r.images ?? []).map((i) => ({ type: "image", mimeType: i.mediaType, data: i.data }))],
          isError: Boolean(r.isError)
        });
      } catch (e) {
        const m = addMessage(bot.id, { role: "tool", text: "", tool: { name, input: args, result: errorText(e), isError: true, status: "done" } });
        emit("message", { botId: bot.id, message: m });
        return reply({ content: [{ type: "text", text: errorText(e) }], isError: true });
      }
    }
    default:
      return fail(`Unsupported method ${body.method}`);
  }
}
var import_node_crypto5, key, approvalTool;
var init_mcp_server = __esm({
  "src/mcp-server.ts"() {
    "use strict";
    import_node_crypto5 = require("node:crypto");
    init_bots();
    init_secrets();
    init_tools();
    init_approvals();
    init_bots();
    init_events();
    init_util();
    approvalTool = {
      name: "approval_prompt",
      description: "Asks the person on their phone to allow or deny a tool call.",
      inputSchema: { type: "object", properties: { tool_name: { type: "string" }, input: { type: "object" } }, required: ["tool_name"] }
    };
  }
});

// src/agent.ts
function tellShellBusy() {
  if (bridgeAvailable()) void bridge("/busy", { busy: running.size > 0 }).catch(() => {
  });
}
function stopBot(botId) {
  running.get(botId)?.abort();
  queues.delete(botId);
}
function resolveProvider(bot) {
  const s = settings();
  const id2 = renamedProvider(bot.providerId) ?? s.defaultProvider ?? s.providers.find((p2) => p2.enabled)?.id;
  const p = id2 ? provider(id2) : void 0;
  if (!p || !p.enabled) throw new Error("No AI is set up for this bot yet. Open Settings \u2192 AI and sign in to Claude, ChatGPT or Gemini (Gemini is free with a Google account).");
  return p;
}
function systemPrompt(bot, extra = "") {
  const s = settings();
  const when = fmtLong(/* @__PURE__ */ new Date());
  return [
    bot.persona || `You are ${bot.name}, a helpful assistant.`,
    `

You are ${bot.name}, one of the person's bots in MausDroid, an agent app running on their Android phone. It is ${when} (${s.timeZone}).`,
    "Work step by step with your tools. Prefer the quickest reliable tool (web_fetch before the browser; connected apps before the browser).",
    "Anything that sends, buys, posts, deletes or changes things for the person is paused for their approval automatically; just call the tool.",
    "Never type passwords, card numbers or one-time codes yourself: if a site needs a login use browser_ask_login.",
    "For Facebook, Messenger and WhatsApp never drive the person's account in the browser (it can get them banned); draft text for them to send instead.",
    "Reply in plain, friendly language. Keep answers short unless asked for detail.",
    describeSkills(bot.skills),
    memoryContext(bot.id),
    extra
  ].join(" ");
}
function trimHistory(h, maxChars = 4e5) {
  const size = (m) => JSON.stringify(m).length;
  let total = h.reduce((a, m) => a + size(m), 0);
  let start = 0;
  while (total > maxChars && start < h.length - 2) {
    total -= size(h[start]);
    start++;
    while (start < h.length && !(h[start].role === "user" && h[start].content.some((b) => b.type === "text"))) {
      total -= size(h[start]);
      start++;
    }
  }
  return h.slice(start);
}
async function modelTurn(p, model, system, msgs2, tools2, signal, onText) {
  const req = { model, system, messages: msgs2, tools: tools2.map((t) => t.spec), signal, onText };
  const key2 = getSecret(`provider:${p.id}`);
  if (p.needsKey && !key2) throw new Error(`${p.label} needs an API key (Settings \u2192 AI).`);
  if (p.kind === "anthropic") return anthropicTurn(req, key2);
  return openaiTurn(req, p.baseUrl, key2);
}
function sendToBot(botId, text, source = "you", images) {
  const bot = getBot(botId);
  if (!bot) throw new Error("No such bot");
  const msg = addMessage(botId, { role: "user", text, source, status: "done" });
  updateBot(botId, { lastMessageAt: msg.at });
  emit("message", { botId, message: msg });
  const q = queues.get(botId) ?? [];
  q.push({ text: source === "you" ? text : `[${source}] ${text}`, source, images });
  queues.set(botId, q);
  if (!running.has(botId)) void drain(botId);
  return msg;
}
async function drain(botId) {
  const ctl = new AbortController();
  running.set(botId, ctl);
  emit("bot.busy", { botId, busy: true });
  tellShellBusy();
  try {
    while ((queues.get(botId) ?? []).length && !ctl.signal.aborted) {
      const batch = queues.get(botId).splice(0);
      const bot = getBot(botId);
      if (!bot) break;
      lastReply.delete(botId);
      try {
        const p = resolveProvider(bot);
        if (p.kind === "subscription") await runCliTurn(bot, p, batch.map((b) => b.text).join("\n\n"), ctl.signal);
        else await runApiTurn(bot, p, batch, ctl.signal);
      } catch (e) {
        if (ctl.signal.aborted) break;
        const m = addMessage(botId, { role: "assistant", text: `\u26A0\uFE0F ${errorText(e)}`, status: "error" });
        emit("message", { botId, message: m });
        lastReply.set(botId, errorText(e));
      }
      const reply = lastReply.get(botId) ?? "";
      for (const l of turnEndListeners) {
        try {
          l(botId, reply);
        } catch {
        }
      }
    }
  } finally {
    running.delete(botId);
    emit("bot.busy", { botId, busy: false });
    tellShellBusy();
    if (ctl.signal.aborted) {
      const m = addMessage(botId, { role: "note", text: "Stopped.", status: "stopped" });
      emit("message", { botId, message: m });
    }
  }
}
async function runApiTurn(bot, p, batch, signal) {
  const h = history(bot.id);
  const content = [];
  for (const b2 of batch) {
    content.push({ type: "text", text: b2.text });
    for (const img of b2.images ?? []) content.push({ type: "image", ...img });
  }
  h.push({ role: "user", content });
  const tools2 = await toolsFor(bot);
  const model = bot.model ?? p.defaultModel;
  for (let step2 = 0; step2 < MAX_STEPS; step2++) {
    if (signal.aborted) break;
    const reply = addMessage(bot.id, { role: "assistant", text: "", status: "streaming" });
    emit("message", { botId: bot.id, message: reply });
    let text = "";
    let turn;
    try {
      turn = await modelTurn(p, model, systemPrompt(bot), trimHistory(h), tools2, signal, (d) => {
        text += d;
        emit("message.delta", { botId: bot.id, messageId: reply.id, delta: d });
      });
    } catch (e) {
      patchMessage(bot.id, reply.id, { text: text || `\u26A0\uFE0F ${errorText(e)}`, status: signal.aborted ? "stopped" : "error" });
      emit("message.updated", { botId: bot.id, messageId: reply.id });
      setHistory(bot.id, h);
      if (signal.aborted) return;
      throw e;
    }
    const finalText = turn.blocks.filter((b2) => b2.type === "text").map((b2) => b2.text).join("");
    patchMessage(bot.id, reply.id, { text: finalText, status: "done" });
    if (finalText.trim()) lastReply.set(bot.id, finalText);
    emit("message.updated", { botId: bot.id, messageId: reply.id, text: finalText, status: finalText ? "done" : "empty" });
    h.push({ role: "assistant", content: turn.blocks });
    const calls = turn.blocks.filter((b2) => b2.type === "tool_use");
    if (!calls.length) break;
    const results = [];
    for (const call of calls) results.push(await runTool(bot, tools2, call, signal));
    h.push({ role: "user", content: results });
    setHistory(bot.id, h);
  }
  setHistory(bot.id, h);
  const b = getBot(bot.id);
  if (b) updateBot(bot.id, { unread: b.unread + 1, lastMessageAt: (/* @__PURE__ */ new Date()).toISOString() });
}
async function runTool(bot, tools2, call, signal) {
  const tool = tools2.find((t) => t.spec.name === call.name);
  const card = addMessage(bot.id, { role: "tool", text: "", tool: { name: call.name, input: call.input, status: "running" } });
  emit("message", { botId: bot.id, message: card });
  const finish = (result, isError, status2) => {
    patchMessage(bot.id, card.id, { tool: { name: call.name, input: call.input, result: clip(result, 4e3), isError, status: status2 } });
    emit("message.updated", { botId: bot.id, messageId: card.id });
  };
  if (!tool) {
    finish("Unknown tool", true, "done");
    return { type: "tool_result", toolUseId: call.id, content: `There is no tool called ${call.name}.`, isError: true };
  }
  const reason = tool.risk?.(call.input) ?? null;
  const mustAsk = bot.approvalMode === "ask-all" ? true : bot.approvalMode === "ask-risky" ? Boolean(reason) : false;
  if (mustAsk) {
    const r = await requestApproval(bot.id, call.name, reason ?? `Use ${call.name}`, clip(JSON.stringify(call.input, null, 1), 1200), signal);
    if (!r.allow) {
      finish("You said no.", true, "denied");
      return { type: "tool_result", toolUseId: call.id, content: "The person declined this action. Do not retry it; ask what they would like instead.", isError: true };
    }
  }
  try {
    const out = await tool.run({ bot, signal }, call.input);
    const res = typeof out === "string" ? { text: out } : out;
    finish(res.text, Boolean(res.isError), "done");
    return { type: "tool_result", toolUseId: call.id, content: clip(res.text), isError: res.isError, images: res.images };
  } catch (e) {
    finish(errorText(e), true, "done");
    return { type: "tool_result", toolUseId: call.id, content: errorText(e), isError: true };
  }
}
async function runCliTurn(bot, p, text, signal) {
  const onPhone = p.runOn !== "computer" && isSignedIn(p.subId);
  const mcpBase = onPhone || !settings().tailscale.enabled ? `http://127.0.0.1:${config.port}` : `http://${settings().tailscale.hostname}`;
  const run = {
    prompt: text,
    model: bot.model ?? p.defaultModel,
    resume: bot.cliSession,
    mcpUrl: `${mcpBase}/mcp/${bot.id}`,
    mcpToken: mcpTokenFor(bot.id),
    systemPrompt: systemPrompt(bot, "\n\nMausDroid's tools (browser on the phone, connected apps, alerts, memory, routines, skills) are available through the mausdroid MCP server.")
  };
  let current = null;
  for await (const ev of runCli(p, run, signal)) {
    if (ev.kind === "session" && ev.sessionId) updateBot(bot.id, { cliSession: ev.sessionId });
    else if (ev.kind === "text" && ev.text) {
      current = addMessage(bot.id, { role: "assistant", text: ev.text, status: "done" });
      lastReply.set(bot.id, ev.text);
      emit("message", { botId: bot.id, message: current });
    } else if (ev.kind === "tool") {
      const m = addMessage(bot.id, { role: "tool", text: "", tool: { name: ev.name ?? "tool", input: ev.input, status: "done" } });
      emit("message", { botId: bot.id, message: m });
    } else if (ev.kind === "error") throw new Error(ev.text);
  }
  const b = getBot(bot.id);
  if (b) updateBot(bot.id, { unread: b.unread + 1, lastMessageAt: (/* @__PURE__ */ new Date()).toISOString() });
}
var MAX_STEPS, running, queues, turnEndListeners, onTurnEnd, lastReply, busyBots;
var init_agent = __esm({
  "src/agent.ts"() {
    "use strict";
    init_bots();
    init_events();
    init_settings();
    init_secrets();
    init_anthropic();
    init_openai();
    init_cli();
    init_subscriptions();
    init_tools();
    init_approvals();
    init_util();
    init_config();
    init_time();
    init_mcp_server();
    init_bridge();
    MAX_STEPS = 40;
    running = /* @__PURE__ */ new Map();
    queues = /* @__PURE__ */ new Map();
    turnEndListeners = /* @__PURE__ */ new Set();
    onTurnEnd = (fn) => {
      turnEndListeners.add(fn);
      return () => turnEndListeners.delete(fn);
    };
    lastReply = /* @__PURE__ */ new Map();
    busyBots = () => [...running.keys()];
  }
});

// src/pairing.ts
function createPairingCode() {
  const code = (0, import_node_crypto6.randomBytes)(16).toString("base64url");
  const exp = Date.now() + 10 * 6e4;
  codes.set(code, exp);
  return { code, expiresAt: new Date(exp).toISOString() };
}
function pairingLink(code, base) {
  return `${base.replace(/\/$/, "")}/#pair=${code}`;
}
function redeemPairingCode(code, name) {
  const exp = codes.get(code);
  if (!exp || exp < Date.now()) throw new Error("This QR code has expired. Show a new one on the phone.");
  codes.delete(code);
  const token = (0, import_node_crypto6.randomBytes)(32).toString("base64url");
  devices.update((d) => void d.push({ id: hash(token).slice(0, 12), name: name.slice(0, 60) || "Device", tokenHash: hash(token), createdAt: (/* @__PURE__ */ new Date()).toISOString() }));
  return token;
}
function deviceForToken(token) {
  if (!token) return void 0;
  const h = hash(token);
  const d = devices.get().find((x) => x.tokenHash === h);
  if (d) d.lastSeenAt = (/* @__PURE__ */ new Date()).toISOString();
  return d;
}
function revokeDevice(id2) {
  devices.update((l) => {
    const i = l.findIndex((x) => x.id === id2);
    if (i >= 0) l.splice(i, 1);
  });
}
async function setWebsitePassword(pw) {
  if (pw.length < 8) throw new Error("Use at least 8 characters.");
  const salt = (0, import_node_crypto6.randomBytes)(16).toString("hex");
  await setSecret("website:password", `${salt}:${(0, import_node_crypto6.scryptSync)(pw, salt, 32).toString("hex")}`);
}
function checkWebsitePassword(pw) {
  const stored = getSecret("website:password");
  if (!stored) return false;
  const [salt, want] = stored.split(":");
  const got = (0, import_node_crypto6.scryptSync)(pw, salt, 32);
  return (0, import_node_crypto6.timingSafeEqual)(got, Buffer.from(want, "hex"));
}
function websiteBase() {
  const w = settings().website;
  if (w.enabled && w.relayUrl && w.deviceId) return `${w.relayUrl.replace(/\/$/, "")}/d/${w.deviceId}`;
  if (settings().tailscale.enabled) return `http://${settings().tailscale.hostname}`;
  return null;
}
function configureWebsite(relayUrl, enabled) {
  updateSettings((s) => {
    s.website.relayUrl = relayUrl.trim().replace(/\/$/, "");
    s.website.enabled = enabled;
    s.website.deviceId ??= (0, import_node_crypto6.randomBytes)(9).toString("base64url");
  });
}
var import_node_crypto6, devices, codes, hash, listDevices;
var init_pairing = __esm({
  "src/pairing.ts"() {
    "use strict";
    import_node_crypto6 = require("node:crypto");
    init_store();
    init_secrets();
    init_settings();
    devices = collection("devices", []);
    codes = /* @__PURE__ */ new Map();
    hash = (t) => (0, import_node_crypto6.createHash)("sha256").update(t).digest("hex");
    listDevices = () => devices.get().map(({ tokenHash, ...d }) => d);
  }
});

// src/scheduler.ts
var scheduler_exports = {};
__export(scheduler_exports, {
  runRoutineNow: () => runRoutineNow,
  startScheduler: () => startScheduler,
  tick: () => tick
});
function fire(r) {
  if (!getBot(r.botId)) return;
  sendToBot(
    r.botId,
    `${r.prompt}

(This is your scheduled routine "${r.title}". The person is probably not watching: if there's something they should know, use notify_user; otherwise just reply briefly with what you found.)`,
    `routine: ${r.title}`
  );
}
function runRoutineNow(id2) {
  const r = listRoutines().find((x) => x.id === id2);
  if (!r) throw new Error("No such routine");
  fire(r);
}
function tick() {
  for (const r of dueRoutines()) fire(r);
}
function startScheduler() {
  setInterval(tick, 3e4);
  tick();
}
var init_scheduler = __esm({
  "src/scheduler.ts"() {
    "use strict";
    init_routines();
    init_agent();
    init_bots();
  }
});

// src/voice.ts
function speakable(text) {
  return text.replace(/```[\s\S]*?```/g, " (code) ").replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/https?:\/\/\S+/g, "a link").replace(/[*_#>`|]/g, "").replace(/^\s*[-•]\s+/gm, "").replace(/\n{2,}/g, ". ").replace(/\s+/g, " ").trim().slice(0, 3e3);
}
async function speak(text) {
  if (!bridgeAvailable() || !text.trim()) return;
  await bridge("/voice/speak", { text: speakable(text), rate: settings().voice.rate }).catch(() => {
  });
}
function sendByVoice(botId, text) {
  spokenTo.add(botId);
  return sendToBot(botId, text, "voice");
}
function assistantBot() {
  const id2 = settings().assistant.botId;
  const bots = listBots().filter((b) => !b.hidden);
  return id2 && getBot(id2) || bots.find((b) => b.pinned) || bots[0];
}
function askAssistant(text, waitMs = 75e3) {
  const bot = assistantBot();
  if (!bot) throw new Error("Create a bot first.");
  return new Promise((resolve) => {
    let done = false;
    const off = onTurnEnd((botId, reply) => {
      if (botId !== bot.id || done) return;
      done = true;
      off();
      clearTimeout(t);
      resolve({ botId: bot.id, botName: bot.name, reply });
    });
    const t = setTimeout(() => {
      if (done) return;
      done = true;
      off();
      resolve({ botId: bot.id, botName: bot.name, reply: null });
      const later = onTurnEnd((botId, reply) => {
        if (botId !== bot.id) return;
        later();
        void notifyUser({ title: `${bot.emoji} ${bot.name}`, body: reply.slice(0, 400) || "Finished.", botId: bot.id, priority: "high" });
      });
    }, waitMs);
    sendToBot(bot.id, text, "assistant");
  });
}
var spokenTo;
var init_voice = __esm({
  "src/voice.ts"() {
    "use strict";
    init_bridge();
    init_agent();
    init_bots();
    init_settings();
    init_notify();
    spokenTo = /* @__PURE__ */ new Set();
    onTurnEnd((botId, reply) => {
      const mode = settings().voice.readReplies;
      const asked = spokenTo.delete(botId);
      if (mode === "always" || mode === "voice" && asked) void speak(reply);
    });
  }
});

// src/server.ts
var server_exports = {};
__export(server_exports, {
  handle: () => handle,
  startServer: () => startServer
});
function cookies(h) {
  const out = {};
  for (const part of (h.cookie ?? "").split(";")) {
    const i = part.indexOf("=");
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function cookie(name, value, req, maxAge) {
  const secure = req.via === "relay" ? "; Secure" : "";
  return `${name}=${encodeURIComponent(value)}; Path=${req.prefix || "/"}; Max-Age=${maxAge}; HttpOnly; SameSite=Strict${secure}`;
}
function auth(req) {
  const c = cookies(req.headers);
  const bearer = (req.headers.authorization ?? "").replace(/^Bearer /i, "");
  if (req.via === "local" && (bearer === config.localToken || c.md_t === config.localToken)) return "owner";
  const dev = deviceForToken(c.md_dev);
  if (!dev) return null;
  const s = sessions2.get()[c.md_sess ?? ""];
  if (s && s.device === dev.id && s.expires > Date.now()) return "owner";
  return "paired";
}
function serveStatic(p) {
  const rel = p === "/" ? "index.html" : p.replace(/^\/+/, "");
  const file4 = import_node_path6.default.resolve(config.uiDir, rel);
  if (!file4.startsWith(import_node_path6.default.resolve(config.uiDir)) || !import_node_fs7.default.existsSync(file4) || import_node_fs7.default.statSync(file4).isDirectory()) {
    return serveStatic("/");
  }
  return {
    status: 200,
    headers: {
      "content-type": TYPES[import_node_path6.default.extname(file4)] ?? "application/octet-stream",
      "cache-control": rel === "index.html" ? "no-cache" : "public, max-age=300",
      "content-security-policy": "default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'",
      "x-content-type-options": "nosniff"
    },
    body: import_node_fs7.default.readFileSync(file4)
  };
}
function state() {
  return {
    version: { engine: config.version, apk: config.apkVersion, platform: config.platform },
    bots: listBots().map((b) => ({ ...b, last: lastMessage(b.id) ?? null, busy: busyBots().includes(b.id) })),
    cards: pendingCards(),
    seq: currentSeq(),
    unreadAlerts: listAlerts().filter((a) => !a.read).length,
    onboardingDone: settings().onboardingDone,
    nativeBridge: bridgeAvailable()
  };
}
async function handle(req) {
  try {
    if (!req.path.startsWith("/api/")) return serveStatic(req.path);
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = req.path.match(r.re);
      if (!m) continue;
      if (!r.open) {
        const who = auth(req);
        if (who !== "owner") throw new HttpError(401, who === "paired" ? "Enter your password." : "Not signed in.");
      }
      return await r.h(req, m.slice(1));
    }
    return json({ error: "Not found" }, 404);
  } catch (e) {
    const status2 = e instanceof HttpError ? e.status : 500;
    return json({ error: errorText(e) }, status2);
  }
}
function startServer() {
  const server = import_node_http3.default.createServer(async (inc, out) => {
    const url = new URL(inc.url ?? "/", "http://x");
    const via = inc.headers["x-mausdroid-via"] === "tailnet" ? "tailnet" : "local";
    if (via === "local" && url.searchParams.get("t") === config.localToken) {
      out.writeHead(302, { location: "/", "set-cookie": `md_t=${config.localToken}; Path=/; HttpOnly; SameSite=Strict` });
      return out.end();
    }
    const chunks = [];
    let size = 0;
    for await (const c of inc) {
      size += c.length;
      if (size > 25 * 1024 * 1024) return out.writeHead(413).end();
      chunks.push(c);
    }
    const raw = Buffer.concat(chunks).toString("utf8");
    let body = void 0;
    try {
      body = raw ? JSON.parse(raw) : void 0;
    } catch {
      body = raw;
    }
    const headers2 = Object.fromEntries(Object.entries(inc.headers).map(([k, v]) => [k, Array.isArray(v) ? v.join(", ") : v]));
    const req = { method: inc.method ?? "GET", path: url.pathname, query: url.searchParams, headers: headers2, body, via, prefix: "/" };
    const mcp2 = url.pathname.match(/^\/mcp\/([^/]+)$/);
    if (mcp2) return void handleMcp(mcp2[1], inc, out, body).catch((e) => out.writeHead(500).end(errorText(e)));
    if (req.path === "/api/events" && req.method === "GET") {
      if (auth(req) !== "owner") return out.writeHead(401).end();
      out.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-store", connection: "keep-alive" });
      out.write(`event: hello
data: ${JSON.stringify({ seq: currentSeq() })}

`);
      const off = subscribe((e) => out.write(`data: ${JSON.stringify(e)}

`));
      const ping = setInterval(() => out.write(": ping\n\n"), 2e4);
      inc.on("close", () => {
        off();
        clearInterval(ping);
      });
      return;
    }
    const res = await handle(req);
    out.writeHead(res.status, res.headers ?? {});
    out.end(res.body);
  });
  server.listen(config.port, "127.0.0.1");
  return server;
}
var import_node_fs7, import_node_path6, import_node_http3, import_node_crypto7, HttpError, json, sessions2, attempts, TYPES, routes, route, subId;
var init_server = __esm({
  "src/server.ts"() {
    "use strict";
    import_node_fs7 = __toESM(require("node:fs"), 1);
    import_node_path6 = __toESM(require("node:path"), 1);
    import_node_http3 = __toESM(require("node:http"), 1);
    import_node_crypto7 = require("node:crypto");
    init_config();
    init_bots();
    init_agent();
    init_events();
    init_approvals();
    init_notify();
    init_settings();
    init_secrets();
    init_anthropic();
    init_openai();
    init_secrets();
    init_composio();
    init_skills();
    init_routines();
    init_pairing();
    init_memory();
    init_bridge();
    init_mcp_server();
    init_store();
    init_util();
    init_scheduler();
    init_subscriptions();
    init_voice();
    HttpError = class extends Error {
      constructor(status2, msg) {
        super(msg);
        this.status = status2;
      }
    };
    json = (data, status2 = 200, headers2 = {}) => ({
      status: status2,
      headers: { "content-type": "application/json", "cache-control": "no-store", ...headers2 },
      body: JSON.stringify(data)
    });
    sessions2 = collection("web-sessions", {});
    attempts = [];
    TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".png": "image/png", ".json": "application/json", ".webmanifest": "application/manifest+json", ".ico": "image/x-icon" };
    routes = [];
    route = (method, pattern, h, open2 = false) => routes.push({ method, re: new RegExp(`^${pattern.replace(/:([a-zA-Z]+)/g, "([^/]+)")}$`), h, open: open2 });
    route("POST", "/api/pair/redeem", (req) => {
      const token = redeemPairingCode(String(req.body?.code ?? ""), String(req.body?.name ?? "Device"));
      return json({ ok: true, needsPassword: true }, 200, { "set-cookie": cookie("md_dev", token, req, 400 * 86400) });
    }, true);
    route("POST", "/api/login", (req) => {
      const c = cookies(req.headers);
      const dev = deviceForToken(c.md_dev);
      if (!dev) throw new HttpError(401, "This device isn't paired. Scan the QR code on the phone first.");
      const recent = attempts.filter((t) => t > Date.now() - 15 * 6e4);
      attempts.splice(0, attempts.length, ...recent);
      if (recent.length >= 8) throw new HttpError(429, "Too many tries. Wait 15 minutes.");
      attempts.push(Date.now());
      if (!checkWebsitePassword(String(req.body?.password ?? ""))) throw new HttpError(401, "Wrong password.");
      const sid = (0, import_node_crypto7.randomBytes)(24).toString("base64url");
      sessions2.update((s) => {
        for (const [k, v] of Object.entries(s)) if (v.expires < Date.now()) delete s[k];
        s[sid] = { device: dev.id, expires: Date.now() + 30 * 864e5 };
      });
      return json({ ok: true }, 200, { "set-cookie": cookie("md_sess", sid, req, 30 * 86400) });
    }, true);
    route("GET", "/api/whoami", (req) => json({ auth: auth(req), via: req.via, passwordSet: publicSettings().website.passwordSet }), true);
    route("POST", "/api/logout", (req) => {
      const c = cookies(req.headers);
      sessions2.update((s) => void delete s[c.md_sess ?? ""]);
      return json({ ok: true }, 200, { "set-cookie": cookie("md_sess", "", req, 0) });
    });
    route("GET", "/api/state", () => json(state()));
    route("POST", "/api/bots", (req) => json(createBot(req.body ?? {})));
    route("PATCH", "/api/bots/:id", (req, [id2]) => {
      const { id: _i, createdAt: _c, ...patch } = req.body ?? {};
      return json(updateBot(id2, patch));
    });
    route("DELETE", "/api/bots/:id", (_r, [id2]) => {
      stopBot(id2);
      deleteBot(id2);
      return json({ ok: true });
    });
    route("GET", "/api/bots/:id/messages", (req, [id2]) => json(messages(id2, req.query.get("before") ?? void 0)));
    route("POST", "/api/bots/:id/messages", (req, [id2]) => json(sendToBot(id2, String(req.body?.text ?? ""), "you", req.body?.images)));
    route("POST", "/api/bots/:id/stop", (_r, [id2]) => (stopBot(id2), json({ ok: true })));
    route("POST", "/api/bots/:id/clear", (_r, [id2]) => (clearChat(id2), json({ ok: true })));
    route("POST", "/api/bots/:id/read", (_r, [id2]) => json(updateBot(id2, { unread: 0 })));
    route("GET", "/api/events/poll", async (req) => json({ events: await waitForEvents(Number(req.query.get("since") ?? 0), 25e3), seq: currentSeq() }));
    route("GET", "/api/cards", () => json(pendingCards()));
    route("POST", "/api/cards/:id", (req, [id2]) => json({ ok: settle(id2, { allow: Boolean(req.body?.allow), answer: req.body?.answer, always: Boolean(req.body?.always) }) }));
    route("GET", "/api/alerts", () => json(listAlerts()));
    route("POST", "/api/alerts/read", () => (markAlertsRead(), json({ ok: true })));
    route("GET", "/api/settings", () => json(publicSettings()));
    route("PUT", "/api/settings/general", (req) => {
      const b = req.body ?? {};
      updateSettings((s) => {
        if ("defaultProvider" in b) s.defaultProvider = b.defaultProvider;
        if (b.timeZone) s.timeZone = b.timeZone;
        if ("quietHours" in b) s.quietHours = b.quietHours;
        if ("onboardingDone" in b) s.onboardingDone = Boolean(b.onboardingDone);
      });
      emit("settings.changed");
      return json(publicSettings());
    });
    route("PUT", "/api/settings/providers/:id", async (req, [id2]) => {
      const b = req.body ?? {};
      if (!provider(id2) && b.kind) {
        updateSettings((s) => void s.providers.push({ id: id2, label: b.label ?? id2, kind: b.kind, baseUrl: b.baseUrl, defaultModel: b.defaultModel ?? "", models: [], enabled: false, needsKey: Boolean(b.needsKey) }));
      }
      if (!provider(id2)) throw new HttpError(404, "No such AI provider");
      if (typeof b.key === "string") await setSecret(`provider:${id2}`, b.key.trim() || null);
      if (typeof b.computerToken === "string") await setSecret(`computer:${id2}`, b.computerToken.trim() || null);
      updateSettings((s) => {
        const p = s.providers.find((x) => x.id === id2);
        for (const k of ["enabled", "baseUrl", "defaultModel", "models", "runOn", "computerUrl", "label", "needsKey"]) if (k in b) p[k] = b[k];
        if (p.enabled && !s.defaultProvider) s.defaultProvider = p.id;
      });
      emit("settings.changed");
      return json(publicSettings());
    });
    route("POST", "/api/settings/providers/:id/models", async (_r, [id2]) => {
      const p = provider(id2);
      if (!p) throw new HttpError(404, "No such AI provider");
      const key2 = getSecret(`provider:${id2}`);
      const models = p.kind === "anthropic" ? await anthropicModels(key2 ?? "") : p.kind === "openai" ? await openaiModels(p.baseUrl, key2) : p.models;
      updateSettings((s) => void (s.providers.find((x) => x.id === id2).models = models));
      return json({ models });
    });
    route("PUT", "/api/settings/github", async (req) => {
      await setSecret("github", String(req.body?.token ?? "").trim() || null);
      return json(publicSettings());
    });
    subId = (id2) => {
      if (!(id2 in SUBS)) throw new HttpError(404, "Unknown subscription");
      return id2;
    };
    route("GET", "/api/subs", () => json(allSubs()));
    onSignedIn((sid) => {
      updateSettings((st) => {
        const p = st.providers.find((x) => x.id === sid);
        if (p) p.enabled = true;
        st.defaultProvider ??= sid;
      });
      emit("settings.changed");
    });
    route("POST", "/api/subs/:id/signin", (req, [id2]) => {
      const sid = subId(id2);
      const opener = async (url) => {
        if (req.via === "local" && bridgeAvailable()) await bridge("/open-url", { url });
      };
      void signIn(sid, opener);
      return json(subStatus(sid));
    });
    route("POST", "/api/subs/:id/code", (req, [id2]) => (sendCode(subId(id2), String(req.body?.code ?? "")), json(subStatus(subId(id2)))));
    route("POST", "/api/subs/:id/cancel", (_r, [id2]) => (cancelSignIn(subId(id2)), json(subStatus(subId(id2)))));
    route("POST", "/api/subs/:id/signout", async (_r, [id2]) => {
      await signOut(subId(id2));
      return json(subStatus(subId(id2)));
    });
    route("POST", "/api/subs/:id/uninstall", async (_r, [id2]) => {
      await uninstall(subId(id2));
      return json(subStatus(subId(id2)));
    });
    route("PUT", "/api/settings/voice", (req) => {
      const b = req.body ?? {};
      updateSettings((st) => {
        if (b.readReplies) st.voice.readReplies = b.readReplies;
        if (typeof b.rate === "number") st.voice.rate = Math.min(2, Math.max(0.5, b.rate));
        if ("assistantBotId" in b) st.assistant.botId = b.assistantBotId || null;
        if ("assistantSpeak" in b) st.assistant.speak = Boolean(b.assistantSpeak);
      });
      emit("settings.changed");
      return json(publicSettings());
    });
    route("POST", "/api/voice/listen", async () => json(await bridge("/voice/listen", {}, 6e4)));
    route("POST", "/api/voice/speak", async (req) => (await speak(String(req.body?.text ?? "")), json({ ok: true })));
    route("POST", "/api/voice/stop", async () => json(await bridge("/voice/stop", {}).catch(() => ({}))));
    route("POST", "/api/bots/:id/voice", (req, [id2]) => json(sendByVoice(id2, String(req.body?.text ?? ""))));
    route("GET", "/api/assistant", () => {
      const b = assistantBot();
      return json({ botId: b?.id ?? null, botName: b?.name ?? null, emoji: b?.emoji ?? null, color: b?.color ?? null, speak: settings().assistant.speak });
    });
    route("POST", "/api/assistant/ask", async (req) => json(await askAssistant(String(req.body?.text ?? ""))));
    route("POST", "/api/composio/key", async (req) => (await connectComposio(String(req.body?.key ?? "")), json(publicSettings())));
    route("DELETE", "/api/composio/key", async () => (await disconnectComposio(), json(publicSettings())));
    route("GET", "/api/composio/toolkits", async (req) => json(await listToolkits(req.query.get("search") ?? "", req.query.get("cursor") ?? void 0)));
    route("GET", "/api/composio/connections", async () => json(await listConnections()));
    route("POST", "/api/composio/link", async (req) => {
      const { url } = await linkToolkit(String(req.body?.toolkit), req.body?.alias);
      if (req.via === "local" && bridgeAvailable()) await bridge("/open-url", { url }).catch(() => {
      });
      return json({ url });
    });
    route("DELETE", "/api/composio/connections/:id", async (_r, [id2]) => (await removeConnection(id2), json({ ok: true })));
    route("GET", "/api/skills", () => json(listSkills().map(({ dir, ...s }) => s)));
    route("POST", "/api/skills", (req) => json({ name: saveSkill(String(req.body?.name), String(req.body?.md)) }));
    route("DELETE", "/api/skills/:name", (_r, [name]) => (removeSkill(decodeURIComponent(name)), json({ ok: true })));
    route("GET", "/api/skills/market", async (req) => json(await searchMarketplace(req.query.get("q") ?? "")));
    route("GET", "/api/skills/repo", async (req) => {
      const r = await listRepoSkills(req.query.get("ref") ?? "");
      return json({ repo: `${r.owner}/${r.repo}`, branch: r.branch, skills: r.dirs });
    });
    route("POST", "/api/skills/install", async (req) => json({ installed: await installFromGitHub(String(req.body?.ref), req.body?.only) }));
    route("GET", "/api/routines", (req) => json(listRoutines(req.query.get("bot") ?? void 0)));
    route("POST", "/api/routines", (req) => json(createRoutine(req.body)));
    route("PATCH", "/api/routines/:id", (req, [id2]) => (updateRoutine(id2, req.body ?? {}), json({ ok: true })));
    route("DELETE", "/api/routines/:id", (_r, [id2]) => (deleteRoutine(id2), json({ ok: true })));
    route("POST", "/api/routines/:id/run", (_r, [id2]) => (runRoutineNow(id2), json({ ok: true })));
    route("GET", "/api/memory/:scope", (_r, [scope]) => json({ text: readMemory(scope) }));
    route("PUT", "/api/memory/:scope", (req, [scope]) => (writeMemory(scope, String(req.body?.text ?? "")), json({ ok: true })));
    route("GET", "/api/devices", () => json(listDevices()));
    route("DELETE", "/api/devices/:id", (_r, [id2]) => (revokeDevice(id2), json({ ok: true })));
    route("POST", "/api/pair/create", () => {
      const base = websiteBase();
      if (!base) throw new HttpError(400, "Turn on the website (or Tailscale) first so other devices have an address to open.");
      const c = createPairingCode();
      return json({ ...c, link: pairingLink(c.code, base) });
    });
    route("PUT", "/api/website", async (req) => {
      const b = req.body ?? {};
      if (b.password) await setWebsitePassword(String(b.password));
      if ("relayUrl" in b || "enabled" in b) configureWebsite(String(b.relayUrl ?? settings().website.relayUrl ?? ""), Boolean(b.enabled));
      emit("settings.changed");
      return json(publicSettings());
    });
    route("GET", "/api/tailscale", async () => json(bridgeAvailable() ? await bridge("/tailscale/status") : { state: "Unavailable" }));
    route("PUT", "/api/tailscale", async (req) => {
      const b = req.body ?? {};
      if (typeof b.authKey === "string") await setSecret("tailscale:authkey", b.authKey.trim() || null);
      updateSettings((s2) => {
        if ("enabled" in b) s2.tailscale.enabled = Boolean(b.enabled);
        if (b.hostname) s2.tailscale.hostname = String(b.hostname).toLowerCase().replace(/[^a-z0-9-]/g, "-");
      });
      const s = settings().tailscale;
      if (bridgeAvailable()) await bridge(s.enabled ? "/tailscale/start" : "/tailscale/stop", { hostname: s.hostname, authKey: getSecret("tailscale:authkey") ?? "" });
      return json(publicSettings());
    });
    route("GET", "/api/update", async () => json(bridgeAvailable() ? await bridge("/update/status") : { state: "dev" }));
    route("POST", "/api/update/check", async () => json(await bridge("/update/check", {}, 12e4)));
    route("POST", "/api/update/apply", async () => json(await bridge("/update/apply", {}, 3e5)));
    route("GET", "/api/system", async () => json({ ...bridgeAvailable() ? await bridge("/device/info").catch(() => ({})) : {}, engine: config.version }));
    route("POST", "/api/system/:action", async (req, [action]) => json(await bridge(`/device/${action}`, req.body ?? {})));
    route("POST", "/api/browser/login", async (req) => json(await bridge("/login/show", { url: req.body?.url })));
  }
});

// src/relay-client.ts
var relay_client_exports = {};
__export(relay_client_exports, {
  relayStatus: () => relayStatus,
  startRelayClient: () => startRelayClient
});
async function relaySecret() {
  let s = getSecret("website:relay");
  if (!s) {
    s = (0, import_node_crypto9.randomBytes)(32).toString("base64url");
    await setSecret("website:relay", s);
  }
  return s;
}
function startRelayClient() {
  if (running2) return;
  running2 = true;
  void loop();
}
async function loop() {
  let backoff = 1e3;
  while (true) {
    const w = settings().website;
    if (!w.enabled || !w.relayUrl || !w.deviceId) {
      relayStatus.connected = false;
      await sleep(5e3);
      continue;
    }
    const base = `${w.relayUrl.replace(/\/$/, "")}/d/${w.deviceId}`;
    try {
      const secret = await relaySecret();
      const ts = String(Date.now());
      const sig = (0, import_node_crypto8.createHmac)("sha256", secret).update(`${w.deviceId}:${ts}`).digest("hex");
      phoneKey = (0, import_node_crypto8.createHmac)("sha256", secret).update("register").digest("hex");
      const res = await fetch(`${base}/_phone/poll`, {
        headers: { "x-phone-ts": ts, "x-phone-sig": sig, "x-phone-key": phoneKey },
        signal: AbortSignal.timeout(4e4)
      });
      if (!res.ok) throw new Error(`website relay: HTTP ${res.status} ${await res.text()}`);
      relayStatus.connected = true;
      relayStatus.lastSeen = (/* @__PURE__ */ new Date()).toISOString();
      relayStatus.lastError = "";
      backoff = 1e3;
      const jobs = await res.json();
      for (const job of jobs) void answer(base, sig, ts, job);
    } catch (e) {
      relayStatus.connected = false;
      relayStatus.lastError = e instanceof Error ? e.message : String(e);
      await sleep(backoff);
      backoff = Math.min(backoff * 2, 6e4);
    }
  }
}
async function answer(base, sig, ts, job) {
  let body;
  try {
    body = job.body ? JSON.parse(job.body) : void 0;
  } catch {
    body = job.body;
  }
  const prefix = new URL(base).pathname + "/";
  const r = await handle({ method: job.method, path: job.path, query: new URLSearchParams(job.query), headers: job.headers, body, via: "relay", prefix });
  const payload = typeof r.body === "string" ? Buffer.from(r.body) : r.body ?? Buffer.alloc(0);
  await fetch(`${base}/_phone/reply`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-phone-ts": ts, "x-phone-sig": sig, "x-phone-key": phoneKey },
    body: JSON.stringify({ rid: job.rid, status: r.status, headers: r.headers ?? {}, body: payload.toString("base64") })
  }).catch(() => {
  });
}
var import_node_crypto8, import_node_crypto9, running2, relayStatus, phoneKey;
var init_relay_client = __esm({
  "src/relay-client.ts"() {
    "use strict";
    import_node_crypto8 = require("node:crypto");
    init_server();
    init_settings();
    init_secrets();
    import_node_crypto9 = require("node:crypto");
    init_util();
    running2 = false;
    relayStatus = { connected: false, lastError: "", lastSeen: "" };
    phoneKey = "";
  }
});

// src/proxy.ts
var proxy_exports = {};
__export(proxy_exports, {
  startEgressProxy: () => startEgressProxy
});
function startEgressProxy(port) {
  const server = import_node_http4.default.createServer((req, res) => {
    try {
      const u = new URL(req.url ?? "");
      const up = import_node_http4.default.request({ host: u.hostname, port: u.port || 80, path: u.pathname + u.search, method: req.method, headers: req.headers }, (r) => {
        res.writeHead(r.statusCode ?? 502, r.headers);
        r.pipe(res);
      });
      up.on("error", () => res.writeHead(502).end());
      req.pipe(up);
    } catch {
      res.writeHead(400).end();
    }
  });
  server.on("connect", (req, client2, head) => {
    const [host, port2] = (req.url ?? "").split(":");
    const up = import_node_net.default.connect(Number(port2) || 443, host, () => {
      client2.write("HTTP/1.1 200 Connection Established\r\n\r\n");
      if (head.length) up.write(head);
      up.pipe(client2);
      client2.pipe(up);
    });
    up.on("error", () => client2.destroy());
    client2.on("error", () => up.destroy());
  });
  server.listen(port, "127.0.0.1");
  return server;
}
var import_node_http4, import_node_net;
var init_proxy = __esm({
  "src/proxy.ts"() {
    "use strict";
    import_node_http4 = __toESM(require("node:http"), 1);
    import_node_net = __toESM(require("node:net"), 1);
  }
});

// src/main.ts
var import_node_fs8 = __toESM(require("node:fs"), 1);
var import_node_path7 = __toESM(require("node:path"), 1);

// src/net-fetch.ts
var import_node_http = __toESM(require("node:http"), 1);
var import_node_https = __toESM(require("node:https"), 1);
var import_node_zlib = __toESM(require("node:zlib"), 1);
function nodeFetch(input, init = {}) {
  return new Promise((resolve, reject) => {
    let redirects = 0;
    const go = (urlStr, method, body) => {
      const u = new URL(urlStr);
      const lib2 = u.protocol === "https:" ? import_node_https.default : u.protocol === "http:" ? import_node_http.default : null;
      if (!lib2) return reject(new TypeError(`Unsupported URL ${urlStr}`));
      const headers2 = {};
      const h = init.headers;
      if (h) {
        if (typeof h.forEach === "function" && !Array.isArray(h)) h.forEach((v, k) => headers2[k.toLowerCase()] = v);
        else for (const [k, v] of Array.isArray(h) ? h : Object.entries(h)) if (v !== void 0) headers2[String(k).toLowerCase()] = String(v);
      }
      headers2["accept-encoding"] ??= "gzip, deflate, br";
      let payload;
      if (body !== void 0 && body !== null) {
        payload = Buffer.isBuffer(body) ? body : body instanceof Uint8Array ? Buffer.from(body) : Buffer.from(String(body));
        headers2["content-length"] = String(payload.length);
      }
      const req = lib2.request(u, { method, headers: headers2 }, (res) => {
        const status2 = res.statusCode ?? 0;
        const loc = res.headers.location;
        if ([301, 302, 303, 307, 308].includes(status2) && loc && init.redirect !== "manual" && redirects++ < 10) {
          res.resume();
          const next = new URL(loc, u).toString();
          const keep = status2 === 307 || status2 === 308;
          return go(next, keep ? method : method === "HEAD" ? "HEAD" : "GET", keep ? body : void 0);
        }
        let stream = res;
        const enc = String(res.headers["content-encoding"] ?? "").toLowerCase();
        if (enc === "gzip") stream = res.pipe(import_node_zlib.default.createGunzip());
        else if (enc === "deflate") stream = res.pipe(import_node_zlib.default.createInflate());
        else if (enc === "br") stream = res.pipe(import_node_zlib.default.createBrotliDecompress());
        const noBody = method === "HEAD" || status2 === 204 || status2 === 304 || status2 < 200;
        if (noBody) res.resume();
        resolve(makeResponse(urlStr, status2, res.statusMessage ?? "", res.headers, noBody ? null : stream));
      });
      req.on("error", reject);
      const signal = init.signal;
      if (signal) {
        if (signal.aborted) return req.destroy(signal.reason ?? new Error("aborted"));
        signal.addEventListener("abort", () => req.destroy(signal.reason ?? new Error("The operation was aborted")), { once: true });
      }
      if (payload) req.write(payload);
      req.end();
    };
    const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
    go(url, (init.method ?? "GET").toUpperCase(), init.body);
  });
}
var SimpleHeaders = class {
  m = /* @__PURE__ */ new Map();
  constructor(raw) {
    for (const [k, v] of Object.entries(raw)) {
      if (v === void 0 || k === "content-encoding" || k === "content-length") continue;
      this.m.set(k.toLowerCase(), Array.isArray(v) ? v.join(", ") : String(v));
    }
  }
  get(k) {
    return this.m.get(k.toLowerCase()) ?? null;
  }
  has(k) {
    return this.m.has(k.toLowerCase());
  }
  forEach(fn) {
    this.m.forEach(fn);
  }
  entries() {
    return this.m.entries();
  }
  [Symbol.iterator]() {
    return this.m.entries();
  }
};
function makeResponse(url, status2, statusText, raw, stream) {
  let used = false;
  const all = async () => {
    if (used) throw new TypeError("Body already read");
    used = true;
    if (!stream) return Buffer.alloc(0);
    const chunks = [];
    for await (const c of stream) chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c));
    return Buffer.concat(chunks);
  };
  const body = stream ? {
    getReader() {
      used = true;
      const it = stream[Symbol.asyncIterator]();
      return {
        async read() {
          const r = await it.next();
          return r.done ? { done: true } : { done: false, value: new Uint8Array(Buffer.isBuffer(r.value) ? r.value : Buffer.from(r.value)) };
        },
        async cancel() {
          stream.destroy();
        },
        releaseLock() {
        }
      };
    },
    async cancel() {
      stream.destroy();
    }
  } : null;
  return {
    url,
    status: status2,
    statusText,
    ok: status2 >= 200 && status2 < 300,
    redirected: false,
    headers: new SimpleHeaders(raw),
    body,
    get bodyUsed() {
      return used;
    },
    text: async () => (await all()).toString("utf8"),
    json: async () => JSON.parse((await all()).toString("utf8")),
    arrayBuffer: async () => {
      const b = await all();
      return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);
    }
  };
}
function installNodeFetch() {
  globalThis.fetch = nodeFetch;
}

// src/main.ts
init_config();
if (config.platform === "android" || process.env.MAUSDROID_NODE_FETCH === "1" || typeof globalThis.WebAssembly === "undefined") installNodeFetch();
var statusFile = () => import_node_path7.default.join(config.dataDir, "engine-status.json");
var steps = [];
function record(step2, error) {
  steps.push({ step: step2, ok: !error, error: error ? error instanceof Error ? `${error.message}
${error.stack ?? ""}` : String(error) : void 0, at: (/* @__PURE__ */ new Date()).toISOString() });
  try {
    import_node_fs8.default.writeFileSync(statusFile(), JSON.stringify({ version: config.version, steps }, null, 1));
  } catch {
  }
  if (error) console.error(`[startup] ${step2} failed:`, error);
  else console.log(`[startup] ${step2} ok`);
}
async function step(name, fn) {
  try {
    await fn();
    record(name);
  } catch (e) {
    record(name, e);
  }
}
async function main() {
  import_node_fs8.default.mkdirSync(config.dataDir, { recursive: true });
  record("begin");
  const { initSecrets: initSecrets2 } = await Promise.resolve().then(() => (init_secrets(), secrets_exports));
  const { ensureDefaultBots: ensureDefaultBots2 } = await Promise.resolve().then(() => (init_bots(), bots_exports));
  const { startServer: startServer2 } = await Promise.resolve().then(() => (init_server(), server_exports));
  const { startScheduler: startScheduler2 } = await Promise.resolve().then(() => (init_scheduler(), scheduler_exports));
  const { startRelayClient: startRelayClient2 } = await Promise.resolve().then(() => (init_relay_client(), relay_client_exports));
  const { startEgressProxy: startEgressProxy2 } = await Promise.resolve().then(() => (init_proxy(), proxy_exports));
  const { initMcpServer: initMcpServer2 } = await Promise.resolve().then(() => (init_mcp_server(), mcp_server_exports));
  const { flushAll: flushAll2 } = await Promise.resolve().then(() => (init_store(), store_exports));
  const { bridge: bridge2, bridgeAvailable: bridgeAvailable2 } = await Promise.resolve().then(() => (init_bridge(), bridge_exports));
  const { settings: settings2 } = await Promise.resolve().then(() => (init_settings(), settings_exports));
  const { getSecret: getSecret2 } = await Promise.resolve().then(() => (init_secrets(), secrets_exports));
  for (const sig of ["SIGTERM", "SIGINT"])
    process.on(sig, () => {
      flushAll2();
      process.exit(0);
    });
  process.on("exit", flushAll2);
  await step("server", () => startServer2());
  await step("secrets", () => initSecrets2());
  await step("bots", () => ensureDefaultBots2());
  await step("mcp", () => initMcpServer2());
  await step("proxy", () => startEgressProxy2(config.port + 3));
  await step("scheduler", () => startScheduler2());
  await step("website", () => startRelayClient2());
  const ts = settings2().tailscale;
  if (bridgeAvailable2() && ts.enabled) await step("tailscale", () => bridge2("/tailscale/start", { hostname: ts.hostname, authKey: getSecret2("tailscale:authkey") ?? "" }));
  if (bridgeAvailable2()) await step("ready", () => bridge2("/engine/ready", { version: config.version, port: config.port }));
  console.log(`MausDroid engine ${config.version} on http://127.0.0.1:${config.port}/?t=${config.platform === "desktop-dev" ? config.localToken : "\u2026"}`);
}
process.on("uncaughtException", (e) => record("uncaught", e));
process.on("unhandledRejection", (e) => record("unhandled", e));
main().catch((e) => record("main", e));
